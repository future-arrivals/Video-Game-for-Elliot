import math
def cr_sample(P, closed=False, per=12):
    "sample a Catmull-Rom curve through points (same curve kit.path draws)"
    n=len(P); out=[]
    get=(lambda i:P[i%n]) if closed else (lambda i:P[max(0,min(n-1,i))])
    for i in range(n if closed else n-1):
        p0,p1,p2,p3=get(i-1),get(i),get(i+1),get(i+2)
        c1=(p1[0]+(p2[0]-p0[0])/6,p1[1]+(p2[1]-p0[1])/6); c2=(p2[0]-(p3[0]-p1[0])/6,p2[1]-(p3[1]-p1[1])/6)
        for k in range(per):
            t=k/per; a=(1-t)**3; b=3*(1-t)**2*t; c=3*(1-t)*t*t; d=t**3
            out.append((a*p1[0]+b*c1[0]+c*c2[0]+d*p2[0], a*p1[1]+b*c1[1]+c*c2[1]+d*p2[1]))
    if not closed: out.append(tuple(P[-1][:2]))
    return out
def resample(S, m):
    L=[0]
    for i in range(1,len(S)): L.append(L[-1]+math.dist(S[i-1],S[i]))
    out=[]; j=0
    for k in range(m+1):
        s=L[-1]*k/m
        while j<len(L)-2 and L[j+1]<s: j+=1
        t=(s-L[j])/max(1e-9,L[j+1]-L[j]); out.append((S[j][0]+(S[j+1][0]-S[j][0])*t, S[j][1]+(S[j+1][1]-S[j][1])*t))
    return out
def spiky(curve, nsp, base, tip, outward=1, lean=0.0):
    """Spiky band outside an open curve: returns list of points (valleys at base offset, tips at tip(s) offset).
    tip: function of s in 0..1 -> spike length. lean shifts tips along the curve (fraction of spike spacing)."""
    S=resample(cr_sample(curve,per=20),nsp*2*8)
    def at(s):
        i=min(len(S)-2,int(s*(len(S)-1))); a,b=S[i],S[i+1]
        L=math.dist(a,b) or 1; nx,ny=(b[1]-a[1])/L*outward,-(b[0]-a[0])/L*outward
        return a,(nx,ny)
    out=[]
    for k in range(2*nsp+1):
        s=k/(2*nsp)
        if k%2: s=min(1,max(0,s+lean/(2*nsp)))
        p,(nx,ny)=at(s); d=tip(s) if k%2 else base
        out.append((round(p[0]+nx*d,1),round(p[1]+ny*d,1),'c'))
    return out
