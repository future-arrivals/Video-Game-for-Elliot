import sys, json; sys.path.insert(0,'/home/claude/game/tools/monster2')
from kit import *
from geom import spiky
import foods
HEAD='#f7c33c'; FRINGE='#ef6d27'; NAVY='#202c5e'; BLUE='#bfe7ef'; SCRIB='#8fd0e2'; WHITE='#fbfaf6'; BLACK='#1a1a1a'
HINGE_TOP=132.0; HINGE_BOT=440.0; DY=HINGE_TOP-HINGE_BOT   # translate that closes the mouth
ID=lambda p:p
def arm(id_, pts, fingers, sw=9, fw=6):
    s=line(pts,sw)
    j=pts[-1]
    for f_ in fingers: s+=line([f_,j],fw)
    return g(id_,s)
# ---------------------------------------------------------------- TOP
DOME=[(118,132),(120,113),(127,94),(139,74),(157,57),(178,47),(199,45),(219,52),(237,67),(252,87),(262,107),(267,121),(268,132)]
def tipfun(s):
    if s<0.1: return 15
    if s<0.30: return 16+6*(s-0.1)/0.2
    if s<0.75: return 23
    if s<0.9: return 20
    return 16
FR=spiky([(110,138)]+DOME[1:-1]+[(276,138)],19,10,tipfun,lean=0.3)
fringe_pts=[(112,140,'c')]+FR+[(274,140,'c'),(190,140,'c')]
top=''
top+=arm('arm-top-l1',[(127,76),(116,59),(105,43)],[(91,26),(99,23),(109,27)])
top+=arm('arm-top-l2',[(116,110),(102,88),(89,66)],[(76,47),(72,59),(87,47)])
top+=arm('arm-top-l3',[(114,126),(96,112),(80,99)],[(70,80),(83,84),(63,91)])
top+=arm('arm-top-r1',[(260,100),(276,90),(289,76),(298,62)],[(303,43),(313,49),(292,47)])
top+=arm('arm-top-r2',[(265,117),(284,99),(301,82)],[(309,66),(322,72),(298,68)])
top+=arm('arm-top-r3',[(272,131),(290,114),(306,98)],[(322,88),(313,82),(300,86)])
top+=g('pin-left',line([(166,50),(161,34),(157,21)],9)+shape([(150,13,'c'),(162,15,'c'),(157,25,'c')],BLACK,6))
top+=g('pin-right',line([(205,50),(211,35),(216,23)],9)+shape([(209,18,'c'),(226,20,'c'),(217,27,'c')],BLACK,6))
top+=g('boot-toe',shape([(351,113),(357,106.5),(368,103),(380,104),(386,113),(386.5,134,'c'),(362,134.5,'c'),(357,123)],BLACK,9)+line([(353,108),(349,115),(349.5,123)],9))
top+=g('fringe-top',shape(fringe_pts,FRINGE,9))
head=shape([(118,132,'c')]+DOME[1:-1]+[(268,132,'c')],HEAD,9)
# eyes: left is a teardrop with a point to lower right, right is round
eyeL=shape([(146,92),(153.5,96),(156,106),(154.5,114),(153.5,121,'c'),(148,116.5),(139.5,114),(136,104),(139.5,95)],NAVY,6)
eyeL+=ellipse(142.6,98.5,3.6,3.2,WHITE,0,-20,stroke=None)
eyeR=ellipse(227,94.5,10.4,10.0,NAVY,6,0)+ellipse(231.5,97.5,3.6,3.6,WHITE,0,stroke=None)
brows=line([(141,78),(146,85),(151,91.5)],9)+line([(237,69.5),(227,74.5),(216.5,80)],9)
top+=g('head-top',head+g('eye-left',eyeL)+g('eye-right',eyeR)+brows)
TOP=g('part-top',top)
# ---------------------------------------------------------------- INSIDE (unfolded only)
def xL(y):
    T=[(135,107),(160,100.5),(200,96),(250,93),(300,91),(350,91),(400,93),(425,98),(445,112)]
    return interp(T,y)
def xR(y):
    T=[(135,276),(180,284),(250,292.5),(300,298),(350,302),(400,303),(425,298),(445,284)]
    return interp(T,y)
def interp(T,y):
    for (a,xa),(b,xb) in zip(T,T[1:]):
        if a<=y<=b: return xa+(xb-xa)*(y-a)/(b-a)
    return T[0][1] if y<T[0][0] else T[-1][1]
ins=''
ins+=arm('arm-mid-left',[(90,238),(67,220),(56,205),(48,191)],[(40,161),(33,172),(56,164)])
ins+=arm('arm-low-left',[(93,412),(65,389),(38,366)],[(6,345),(17,335),(35,330)])
ins+=g('boot-shaft',shape([(363,133,'c'),(385,133,'c'),(392,175),(402,215),(413,260),(424,309,'c'),(407,322,'c'),(383,307),(370,294),(367,250),(366,190)],WHITE,9))
ins+=arm('arm-mid-right',[(296,250),(318,219),(337,191),(351,170)],[(346,148),(366,140),(376,157)])
ins+=arm('arm-low-right',[(302,392),(330,362),(358,333)],[(349,309),(362,306),(375,317)])
face=shape([(359,433,'c'),(358,386),(359.5,371),(366,363),(374.5,360),(383,363),(388,372),(390,395),(391,433,'c')],WHITE,9)
face+=ellipse(366,376.5,2.3,2.6,BLACK,0,stroke=None)+ellipse(377,374,2.3,2.6,BLACK,0,stroke=None)
face+=line([(361.5,370.5),(368,373.5)],6)+line([(382,368),(375.5,371)],6)
face+=zig([(360,384),(388,383)],6)+zig([(361,384.5),(364,393),(368,384.5),(372,393),(376,384),(380,392.5),(384,384),(387,391)],6)
ins+=g('boot-face',face)
# mouth body
bodyP=[(108,135,'c')]+[(xL(y),y) for y in (165,200,250,300,350,400,425)]+[(112,444,'c'),(282,444,'c')]+[(xR(y),y) for y in (425,400,350,300,250,180)]+[(276,135,'c')]
ins+=shape(bodyP,BLUE,0,stroke=None)
# a few loose light-blue scribbles as texture
for P in [[(130,300),(150,268),(190,258),(240,270),(262,300),(250,335),(205,350),(160,340),(140,315)],
          [(118,215),(150,195),(200,205),(250,230),(270,262)],
          [(150,420),(185,395),(240,395),(275,412)],
          [(255,150),(258,195),(250,240)],[(205,150),(210,170)]]:
    ins+=line(P,3.5,SCRIB)
# teeth bands (white) with zigzag edges
def band(z, back):
    return shape([(x,y,'c') for x,y in z]+[(x,y,'c') for x,y in back],WHITE,0,stroke=None)+zig(z,6)
zt=zigline((110,138),(275,138),13,21)
ins+=band(zt,[(275,133),(110,133)])
zb=zigline((116,441),(283,441),10,-21)
ins+=band(zb,[(283,446),(116,446)])
def wallz(side,y0,y1,n,depth):
    P=[]
    for i in range(2*n+1):
        y=y0+(y1-y0)*i/(2*n)
        if side=='L': x=xL(y)+(depth if i%2 else 1)
        else: x=xR(y)-(depth if i%2 else 1)
        P.append((round(x,1),round(y,1)))
    return P
zl=wallz('L',150,255,4,25); ins+=band(zl,[(xL(255)-4,255),(xL(150)-4,150)])
zl2=wallz('L',385,432,2,20); ins+=band(zl2,[(xL(432)-4,432),(xL(385)-4,385)])
zr=wallz('R',158,432,9,27); ins+=band(zr,[(xR(432)+4,432),(xR(158)+4,158)])
# his loose interior zigzags
ins+=zig([(94,260),(113.5,261),(98.5,285),(117,283),(122.5,301)],6)
ins+=zig([(127.5,281),(136,296),(140,271),(149.5,289),(160,287)],6)
ins+=zig([(98,307),(110,301)],6)
ins+=line([(99,323),(110,327),(117,331.5),(122,325),(127.5,331.5),(134,323.5),(147,322),(168,322.5)],6)
ins+=zig([(214,272),(224,262),(222,275),(233,263),(237,277),(250,262)],6)
ins+=line([(160,357),(170,350),(176,345)],6)+line([(172,383),(160,393)],6)+line([(156,383),(147,389)],6)
# foods
ins+=g('food-round',foods.roundthing(ID,1.0))
ins+=g('food-sausage',foods.sausage(ID,1.0)+foods.roundthing_beak(ID,1.0))
ins+=g('food-fish-1',foods.fish1(ID,1.0))
ins+=g('food-fish-2',foods.fish2(ID,1.0))
ins+=g('food-triangle',foods.triangle(ID,1.0))
ins+=g('food-pizza',foods.pizza(ID,1.0))
ins+=g('food-fish-3',foods.fish3(ID,1.0))
ins+=shape(bodyP,'none',9)
INSIDE=g('part-inside',ins)
# ---------------------------------------------------------------- BOTTOM
BOWL=[(122,440,'c'),(276,440,'c'),(276.5,468),(270,487),(255,498),(225,503.5),(190,503),(160,495),(138,481),(127,463)]
def btip(s): return 13 if 0.15<s<0.85 else 11
BFR=spiky([(112,437),(119,463),(133,483),(158,498),(190,504),(225,504),(256,499),(271,488),(280,468),(283,437)],15,7,btip,outward=-1,lean=0.3)
bot=''
bot+=g('leg-right-long',shape([(285,446,'c'),(320,467),(346,478),(375,487.5,'c'),(366,488,'c'),(356,511,'c'),(352,496,'c'),(343,513,'c'),(335,498,'c'),(328,516,'c'),(320,500,'c'),(312,519,'c'),(304,500,'c'),(288,472,'c')],WHITE,9))
bot+=g('boot-foot',shape([(359,433,'c'),(391.5,433,'c'),(396,465),(402,497,'c'),(388,488.5),(372,481),(358,471,'c')],WHITE,9)
       +line([(366,438),(363.5,454)],6)+line([(378,437.5),(378,455)],6)+line([(364,454),(378,455.5)],6)
       +zig([(359.5,468),(367,458),(373,470),(378,460),(383,469),(388,459),(394.5,467)],6))
bot+=g('leg-right-short',shape([(280,462,'c'),(294,479),(310,501),(318.5,511.5,'c'),(323,524,'c'),(316,519,'c'),(312,527,'c'),(308,522,'c'),(290,526.5),(272,523),(261,516),(258.5,510,'c'),(270,498,'c')],WHITE,9)
       +line([(280,493),(294,511),(307,520)],6))
bot+=g('leg-left-1',shape([(150,480,'c'),(131,470,'c'),(96,515,'c'),(100,525,'c'),(104,515,'c'),(109,529,'c'),(112,518,'c'),(117,531,'c'),(119,521,'c'),(146,487,'c')],WHITE,9))
bot+=g('leg-left-2',shape([(170,494,'c'),(162,500,'c'),(134,531,'c'),(124,526,'c'),(130,540,'c'),(137,538),(150,543),(165,538),(175,527),(179.5,516,'c'),(176,505,'c')],WHITE,9))
bot+=g('fur-left',zig([(112,446),(100,452),(116,456),(103,463),(120,466)],6))
bot+=g('fur-right',zig([(284,436),(297,441),(283,449),(297,455),(285,462)],6))
bot+=g('fringe-bottom',shape([(112,434,'c')]+BFR+[(283,434,'c')],FRINGE,9))
bot+=g('jaw-bottom',shape(BOWL,HEAD,9)+zig(zigline((127,444),(271,444),11,16),6))
def BOTTOM(dy=0):
    return g('part-bottom',bot,tr_y(dy) if dy else '')
if __name__=='__main__':
    vu=finalize('monster_unfolded','\n'.join([INSIDE,BOTTOM(),TOP]),(0,0,440,560))
    vf=finalize('monster_folded','\n'.join([BOTTOM(DY),TOP]),(0,0,440,260))
    json.dump({'unfolded':vu,'folded':vf,'dy':DY,'hinge_top':HINGE_TOP,'hinge_bottom':HINGE_BOT},open('/home/claude/game/work/m2/monster_vb.json','w'))
    print(vu,vf)
