import sys, numpy as np
from PIL import Image
im=np.asarray(Image.open('/home/claude/game/work/m2/u_up.png').convert('RGB')).astype(float)
def px(u,v): return int(v/0.115+560), int(u/0.115+400)
pts={'head':[(190,80),(200,110),(170,120),(240,115)],'fringe':[(113,95),(262,110),(150,40),(268,125)],
'bowl':[(200,480),(230,470),(160,470)],'bfringe':[(150,500),(270,490)],'eye':[(145,108),(232,95)],
'blue':[(175,230),(240,280),(160,300),(130,240)],'sausage':[(200,225),(198,265),(205,190)],'pizza':[(120,345),(140,370),(160,345)],
'pep':[(132,357),(129,360)],'peps':[(175,345),(140,380)],'squig':[(140,207),(239,198)],'paper':[(330,250)]}
for k,L in pts.items():
    cs=[]
    for u,v in L:
        r,c=px(u,v); patch=im[r-6:r+6,c-6:c+6].reshape(-1,3); cs.append(np.median(patch,0))
    m=np.median(cs,0); print(k,'#%02x%02x%02x'%tuple(int(x) for x in m),[ '#%02x%02x%02x'%tuple(int(x) for x in c) for c in cs])
