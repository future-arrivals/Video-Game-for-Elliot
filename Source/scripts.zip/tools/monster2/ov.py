# ov.py key name ux0 uy0 ux1 uy1 ppu out : photo | redraw | 50% blend (in unit space)
import sys, subprocess, re
from PIL import Image
from uv import region, grid
from kit import S
key,name=sys.argv[1:3]; ux0,uy0,ux1,uy1=map(float,sys.argv[3:7]); ppu=float(sys.argv[7]); out=sys.argv[8]
cr=region(key,ux0,uy0,ux1,uy1,ppu); W,H=cr.size
s=open('/home/claude/game/work/m2/%s_ws.svg'%name).read()
s=re.sub(r'viewBox="[^"]*" width="[^"]*" height="[^"]*"','viewBox="%g %g %g %g" width="%d" height="%d"'%(ux0*S,uy0*S,(ux1-ux0)*S,(uy1-uy0)*S,W,H),s,count=1)
open('/tmp/m2_ov.svg','w').write(s)
subprocess.run(['rsvg-convert','-b','white','/tmp/m2_ov.svg','-o','/tmp/m2_ov.png'],check=True)
sv=Image.open('/tmp/m2_ov.png').convert('RGB')
bl=Image.blend(cr,sv,0.5)
o=Image.new('RGB',(W*3+20,H),'white'); o.paste(cr,(0,0)); o.paste(sv,(W+10,0)); o.paste(grid(bl,ux0,uy0,ux1,uy1,ppu),(2*W+20,0)); o.save(out)
