import json, re
A='/home/claude/game/assets'
S=1.15
def vb(n): return [float(v) for v in re.search(r'viewBox="([^"]+)"',open(f'{A}/svg/{n}.svg').read()).group(1).split()]
def ids(n): return re.findall(r'id="([^"]+)"',open(f'{A}/svg/{n}.svg').read())
items={'pizza':'pizza slice: ochre cheese, black olives, red pepperoni, big pink-red centre piece, black blob on the tip',
 'sausage':'red striped sausage with a smiling face (two links, lower one with crossing lines)',
 'fish_1':'heart-shaped fish-like face, angry eyes, yellow squiggle (top-left of mouth)',
 'fish_2':'heart-shaped fish-like face, angry eyes, yellow squiggle (top-right of mouth)',
 'fish_3':'small heart face with big round eyes, smile and one raised arm stroke (lower middle)',
 'round_thing':'circle with a "<" mark and a "3" squiggle on a knobbly bent stick; best guess a balloon on a knotted string or a lollipop',
 'triangle_thing':'uncoloured triangle with a dome fin and a thin pointed nose; unclear (maybe an uncoloured pizza slice or a shark/fish)'}
m={'spec':{'stroke':'#1a1a1a round caps/joins; 9 main outlines, 6 small details (items: 7 main, 6 details); 3.5 light-blue scribble texture strokes inside the mouth only',
  'units':'monster: photo-crop units x1.15 (folded long side ~422); items ~250 long side',
  'method':'hand-placed points joined by Catmull-Rom cubic beziers (tools/monster2); no tracing'},
 'sprites':{}}
for n,form in [('monster_unfolded','unfolded'),('monster_folded','folded')]:
    v=vb(n); m['sprites'][n]={'svg':f'svg/{n}.svg','png':f'png/{n}.png','character':'fuzzy orange monster (starter)','form':form,
      'viewBox':v,'size':v[2:],'part_ids':ids(n)}
m['sprites']['monster_unfolded']['hinge']={
  'top_hinge_line':[[118*S,132*S],[268*S,132*S]],'bottom_hinge_line':[[122*S,440*S],[276*S,440*S]],
  'close_mouth':'translate(0,%.1f) on #part-bottom, hide #part-inside'%((132-440)*S),'translate_y':round((132-440)*S,1),
  'how':'Unfolded = part-inside + part-bottom + part-top at rest. To close, slide part-bottom up by translate_y (bowl top line lands exactly on the head base line, lower teeth hang below it) and hide part-inside. monster_folded.svg is exactly that state.',
  'notes':'part-inside also holds the limbs drawn on the hidden middle panel (arm-mid-*, arm-low-*, boot-shaft, boot-face). The boot is split: boot-toe (part-top), boot-shaft + boot-face (part-inside), boot-foot (part-bottom); folded it is toe directly on foot.'}
m['sprites']['monster_folded']['hinge']={'part_bottom_transform':'translate(0,%.1f)'%((132-440)*S)}
for n,d in items.items():
    v=vb(n); m['sprites'][n]={'svg':f'svg/{n}.svg','png':f'png/{n}.png','character':n,'form':'item','what':d,'viewBox':v,'size':v[2:],'monster_group':'food-'+{'fish_1':'fish-1','fish_2':'fish-2','fish_3':'fish-3','round_thing':'round','triangle_thing':'triangle'}.get(n,n)}
json.dump(m,open(f'{A}/manifest_monster.json','w'),indent=1); print('ok')
