"""Foods the monster ate, authored in monster-unfolded unit coords.
Each function takes T (point transform) and stroke widths (main, detail) and returns SVG."""
from kit import shape, line, zig, ellipse, OUT
WHITE='#fbfaf6'; BLACK='#1a1a1a'
PIZZA='#e8a02a'; PEP='#cf3f45'; PEPC='#cc3a5c'; SAUS='#c4343a'; SQUIG='#cfa92e'
def M(T,P): return [T(p)+(('c',) if len(p)>2 else ()) for p in P]
def E(T,cx,cy,rx,ry,fill,sw,k,rot=0,stroke=OUT):
    x,y=T((cx,cy)); return ellipse(x,y,rx*k,ry*k,fill,sw,rot,stroke=stroke)
def topping(T,P,fill,k,ring):
    "flat-fill topping: black shape with a smaller coloured shape inset (ring = black rim width in source units)"
    import math
    cx=sum(p[0] for p in P)/len(P); cy=sum(p[1] for p in P)/len(P)
    Q=[]
    for p in P:
        dx,dy=p[0]-cx,p[1]-cy; d=math.hypot(dx,dy) or 1; s=max(0.2,(d-ring)/d)
        Q.append((cx+dx*s,cy+dy*s)+((p[2],) if len(p)>2 else ()))
    return shape(M(T,P),BLACK,0,stroke=None)+shape(M(T,Q),fill,0,stroke=None)

def pizza(T,k,sw=9,sd=6,ring=1.4):
    s=''
    tri=[(94,347,'c'),(136,339),(177,330,'c'),(155,361),(133,392,'c'),(113,370)]
    s+=shape(M(T,tri),PIZZA,sw)
    # crust edge drawn a touch heavier like his
    # toppings: olives (black) and pepperoni (red with outline)
    s+=E(T,120,345.5,4.6,3.9,BLACK,0,k,-10,stroke=None)+E(T,118.6,344.5,1.2,1.0,WHITE,0,k,stroke=None)
    s+=E(T,134.5,343,5.2,3.6,BLACK,0,k,5,stroke=None)+E(T,135.8,344.6,1.3,0.9,WHITE,0,k,stroke=None)
    s+=E(T,116.8,354.5,3.2,4.0,BLACK,0,k,10,stroke=None)
    s+=E(T,151.6,345.5,3.4,4.2,BLACK,0,k,-10,stroke=None)
    # pepperoni with little tails
    s+=topping(T,[(146.8,351),(151.5,352.5),(152,357),(148,359),(144,361,'c'),(144.8,355)],PEP,k,ring)
    s+=topping(T,[(130.5,351.5),(136.5,354),(138,362),(135.5,372),(131,374),(126.5,370),(124.5,361),(126,354)],PEPC,k,ring)
    s+=topping(T,[(117.8,359.6),(120.4,364),(118,368.8),(115.2,364.4)],PEP,k,ring)
    s+=topping(T,[(133,375.5),(137.8,376.5),(138.5,380.5),(134.5,382.5),(129,383,'c'),(130.5,378)],PEP,k,ring)
    s+=topping(T,[(162.5,334),(166,336.5),(165,341),(161.5,342.5),(159,347,'c'),(159.5,338)],PEP,k,ring)
    s+=E(T,177.5,331,3.6,3.6,BLACK,0,k,stroke=None)   # the blob he put on the tip
    return s

def sausage(T,k,sw=9,sd=6):
    s=''
    seg2=[(183.5,250),(196,244),(209.5,250),(210.5,268),(206,286),(196,291),(187,286),(183,268)]
    s+=shape(M(T,seg2),SAUS,sw)
    s+=line(M(T,[(196,245),(195,268),(194.5,290)]),sd)
    s+=line(M(T,[(184,262),(190,272),(196,276),(203,273),(209.5,262)]),sd)
    seg1=[(182.5,190),(186,177),(197,173),(208,177),(212,192),(212,220),(211.5,243,'c'),(183.5,244,'c'),(182.5,220)]
    s+=shape(M(T,seg1),SAUS,sw)
    for a,b,c in [((183,186),(197,183),(211.5,186)),((182.5,205),(197,204),(212,205)),((183,229),(197,227.5),(212,228)),((183,238),(197,236),(211.5,237.5))]:
        s+=line(M(T,[a,b,c]),sd)
    s+=E(T,188.8,195.8,2.0,2.6,BLACK,0,k,stroke=None)+E(T,198.5,195.2,2.0,2.6,BLACK,0,k,stroke=None)
    s+=line(M(T,[(187.5,214),(190,218.5),(195,219.5),(200,216.5),(202.5,212)]),sd)
    s+=line(M(T,[(192,288),(194,294),(198,288)]),sd)
    return s

def heart(T,k,pts,eyes,brows,squig,sw=9,sd=6,fill=WHITE,extra=None):
    s=shape(M(T,pts),fill,sw)
    for (cx,cy,rx,ry,rot) in eyes: s+=E(T,cx,cy,rx,ry,BLACK,0,k,rot,stroke=None)
    for b in brows: s+=line(M(T,b),sd)
    if squig: s+=line(M(T,squig),sd,SQUIG)
    if extra: s+=extra
    return s

HEART1=[(159,247,'c'),(140,230),(122,211),(120,193),(125,177),(134,168.5),(145,170),(152,181),(155.5,195,'c'),(160,180),(167,170.5),(175,169.5),(179.5,180),(177.5,200),(171.5,217),(165,233)]
def fish1(T,k,sw=9,sd=6):
    return heart(T,k,HEART1,[(138.8,186,3.4,6.6,-8),(167.5,188.5,3.1,6.6,5)],
        [[(131,176),(137,178),(143,182)],[(173,178.5),(168,180),(163.5,183)]],
        [(131.5,210),(136,205.5),(141,204.5),(144,208.5),(145.5,213),(150.5,211.5)],sw,sd)
HEART2=[(242.5,243,'c'),(229,228),(218,214),(212.5,198),(213,184),(218,174),(225,172.5),(229,179),(230,188,'c'),(234,177),(241,170.5),(249,169),(253,177),(252.5,193),(249.5,212),(246,229)]
def fish2(T,k,sw=9,sd=6):
    return heart(T,k,HEART2,[(222,186,3.0,5.2,-5),(243.2,181.5,2.8,5.6,5)],
        [[(216,180),(220.5,181),(226,184)],[(248,176),(243,177.5),(238.5,181)]],
        [(230.5,202.5),(234,203),(236.5,200.5),(239,196)],sw,sd)
HEART3=[(212,401,'c'),(196,395.5),(179,390.5,'c'),(177.5,375),(180,363),(186.5,356),(193.5,359),(198.8,370,'c'),(201.5,360),(207,354.5),(214,356.5),(216.5,366),(215,384)]
def fish3(T,k,sw=9,sd=6):
    s=shape(M(T,HEART3),WHITE,sw)
    s+=line(M(T,[(230,366),(221,378),(213.5,389)]),sw)
    s+=E(T,190.6,373.2,5.4,7.0,BLACK,0,k,-8,stroke=None)+E(T,191.6,377,1.5,1.4,WHITE,0,k,stroke=None)
    s+=E(T,207.6,367.8,5.0,6.0,BLACK,0,k,8,stroke=None)+E(T,208.6,370,1.4,1.4,WHITE,0,k,stroke=None)
    s+=line(M(T,[(192.5,386.5),(195,390),(200,389.5),(205,383.5),(208.5,379)]),sd)
    return s

def roundthing(T,k,sw=9,sd=6,with_stick=True):
    s=''
    if with_stick:
        knots=[(200.5,322.5),(206,331),(210.5,340),(199.5,346.5),(195.5,329)]
        s+=line(M(T,[(200.5,322,'c'),(206,331,'c'),(210.5,340,'c'),(199.5,346.5,'c'),(195.5,329,'c'),(178,331,'c')]),sd)
        for (x,y) in knots[1:]: s+=E(T,x,y,2.6,2.6,BLACK,0,k,stroke=None)
    circ=[(194,260),(213,266),(224,282),(224,302),(214,318),(199,323.5),(180,320),(167,307),(163,289),(170,272)]
    s+=shape(M(T,circ),WHITE,sw)
    s+=line(M(T,[(189.5,297.5,'c'),(196,296),(199.5,299),(193,303.5,'c'),(200,306),(201,311),(195.5,314)]),sd)
    return s
def roundthing_beak(T,k,sd=6):
    return line(M(T,[(187,270.5,'c'),(176.5,279.5,'c'),(189,281.5,'c')]),sd)

def triangle(T,k,sw=9,sd=6):
    s=''
    s+=shape(M(T,[(211,328,'c'),(245,323,'c'),(248,333,'c')]),WHITE,sd)
    body=[(245,291,'c'),(267,314,'c'),(292.5,302,'c'),(274,379,'c'),(249,331,'c'),(243,309)]
    s+=shape(M(T,body),WHITE,sw)
    s+=line(M(T,[(249.5,327),(250.5,311),(256,302.5),(262.5,305),(267,314)]),sd)
    return s
