from PIL import Image
A='/home/claude/game/assets/png/'
names=['monster_unfolded','monster_folded','pizza','sausage','fish_1','fish_2','fish_3','round_thing','triangle_thing']
tiles=[]
for bg in [(34,34,40),(92,140,70)]:
    row=[]
    for n in names:
        im=Image.open(A+n+'.png').convert('RGBA'); im.thumbnail((300,300))
        t=Image.new('RGBA',(310,310),bg+(255,)); t.alpha_composite(im,((310-im.width)//2,(310-im.height)//2)); row.append(t)
    tiles.append(row)
out=Image.new('RGB',(310*len(names),620))
for r,row in enumerate(tiles):
    for c,t in enumerate(row): out.paste(t.convert('RGB'),(c*310,r*310))
out.save('/home/claude/game/work/m2/bg.jpg')
# style check beside set
ims=[Image.open(A+n+'.png').convert('RGBA') for n in ['beaver','frankenstein_unfolded','monster_unfolded','monster_folded','crab']]
h=600; ims=[i.resize((int(i.width*h/i.height),h)) for i in ims]
o=Image.new('RGBA',(sum(i.width for i in ims)+80,h),(255,255,255,255)); x=0
for i in ims: o.alpha_composite(i,(x,0)); x+=i.width+20
o.convert('RGB').save('/home/claude/game/work/m2/style.jpg')
