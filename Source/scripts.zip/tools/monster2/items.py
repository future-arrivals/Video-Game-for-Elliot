import sys, json; sys.path.insert(0,'/home/claude/game/tools/monster2')
import kit
from kit import finalize
import foods
kit.S=1.0
LONG=250
ITEMS={  # name: (fn, source bbox in monster units incl. outline)
 'pizza':(lambda T,k: foods.pizza(T,k,7,6), (90,326,182,396)),
 'sausage':(lambda T,k: foods.sausage(T,k,7,6), (179,169,216,296)),
 'fish_1':(lambda T,k: foods.fish1(T,k,7,6), (116,165,184,251)),
 'fish_2':(lambda T,k: foods.fish2(T,k,7,6), (208,165,257,247)),
 'fish_3':(lambda T,k: foods.fish3(T,k,7,6), (174,351,234,405)),
 'round_thing':(lambda T,k: foods.roundthing(T,k,7,6)+foods.roundthing_beak(T,k,6), (159,256,228,350)),
 'triangle_thing':(lambda T,k: foods.triangle(T,k,7,6), (207,287,297,383)),
}
out={}
for name,(fn,(x0,y0,x1,y1)) in ITEMS.items():
    w,h=x1-x0,y1-y0; k=(LONG-24-7)/max(w,h)
    T=lambda p,x0=x0,y0=y0,k=k:(round(20+(p[0]-x0)*k,1),round(20+(p[1]-y0)*k,1))
    body=fn(T,k)
    vb=finalize(name,body,(0,0,40+w*k,40+h*k))
    out[name]={'vb':vb,'k':k,'src_bbox':[x0,y0,x1,y1]}
    print(name,vb)
json.dump(out,open('/home/claude/game/work/m2/items_vb.json','w'),indent=1)
