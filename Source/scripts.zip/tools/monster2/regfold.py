# Register the folded photo onto folded-sprite unit space (affine fit on head landmarks)
import numpy as np
from PIL import Image
Image.MAX_IMAGE_PIXELS=None
U=np.array([(146,104),(227,94.5),(157,16),(218,21),(118,132),(268,132)],float)
P=np.array([(215,422),(345,407),(220,270),(325,272),(180,479),(410,479)],float)*(4284/675)
A=np.c_[U,np.ones(len(U))]; M,res,_,_=np.linalg.lstsq(A,P,rcond=None)
print('residual px',np.sqrt(((A@M-P)**2).sum(1)))
im=Image.open('/home/claude/game/work/m2/f_up.png').convert('RGB')
k=5; W,H=460*k,280*k   # units -20..440, -20..260
# output pixel (X,Y) -> unit (X/k-20, Y/k-20) -> photo
a,b=M[0],M[1]; c=M[2]
# PIL affine wants input coords for each output pixel: x_in = A*X + B*Y + C
coef=(a[0]/k, b[0]/k, c[0]-20*a[0]-20*b[0], a[1]/k, b[1]/k, c[1]-20*a[1]-20*b[1])
out=im.transform((W,H),Image.AFFINE,coef,resample=Image.BICUBIC)
out.save('/home/claude/game/work/m2/folded_reg.png')
