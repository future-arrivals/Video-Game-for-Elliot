"""Hand-authored path helpers. Points are placed by hand; path() joins them with
Catmull-Rom-derived cubic beziers. A point (x,y,'c') is a sharp corner."""
import math, subprocess, re
OUT='#1a1a1a'
S=1.15   # unit scale: photo-crop units -> sprite units (folded long side ~420)
def _pts(P): return [(float(p[0]),float(p[1]),len(p)>2 and p[2]=='c') for p in P]
def f(v): s='%.1f'%v; return s[:-2] if s.endswith('.0') else s
def path(P, closed=True, t=0.5, dx=0, dy=0):
    P=[((x+dx)*S,(y+dy)*S,c) for x,y,c in _pts(P)]; n=len(P)
    get=(lambda i:P[i%n]) if closed else (lambda i:P[max(0,min(n-1,i))])
    d='M%s %s'%(f(P[0][0]),f(P[0][1]))
    for i in range(n if closed else n-1):
        p0,p1,p2,p3=get(i-1),get(i),get(i+1),get(i+2)
        if p1[2] and p2[2]: d+=' L%s %s'%(f(p2[0]),f(p2[1])); continue
        c1=(p1[0],p1[1]) if p1[2] else (p1[0]+(p2[0]-p0[0])*t/3, p1[1]+(p2[1]-p0[1])*t/3)
        c2=(p2[0],p2[1]) if p2[2] else (p2[0]-(p3[0]-p1[0])*t/3, p2[1]-(p3[1]-p1[1])*t/3)
        d+=' C%s %s %s %s %s %s'%(f(c1[0]),f(c1[1]),f(c2[0]),f(c2[1]),f(p2[0]),f(p2[1]))
    if closed: d+='Z'
    return d
def shape(P, fill, sw=9, stroke=OUT, extra=''):
    s=' stroke="%s" stroke-width="%s"'%(stroke,sw) if stroke else ''
    return '<path d="%s" fill="%s"%s%s/>'%(path(P),fill,s,extra)
def line(P, sw=9, stroke=OUT):
    return '<path d="%s" fill="none" stroke="%s" stroke-width="%s"/>'%(path(P,False),stroke,sw)
def zig(P, sw=6, stroke=OUT):
    "polyline with all-sharp corners"
    return line([(p[0],p[1],'c') for p in P], sw, stroke)
def ellipse(cx,cy,rx,ry,fill,sw=9,rot=0,stroke=OUT,n=8):
    pts=[]; r=math.radians(rot)
    for i in range(n):
        a=2*math.pi*i/n; x,y=rx*math.cos(a),ry*math.sin(a)
        pts.append((cx+x*math.cos(r)-y*math.sin(r), cy+x*math.sin(r)+y*math.cos(r)))
    return shape(pts,fill,sw,stroke=stroke)
def zigline(a,b,n,amp,phase=1):
    "zigzag from a to b with n teeth, tips offset by amp on the left normal (phase flips)."
    (x0,y0),(x1,y1)=a,b; L=math.hypot(x1-x0,y1-y0); nx,ny=-(y1-y0)/L*phase,(x1-x0)/L*phase
    P=[]
    for i in range(2*n+1):
        t=i/(2*n); x,y=x0+(x1-x0)*t,y0+(y1-y0)*t
        if i%2: x,y=x+nx*amp,y+ny*amp
        P.append((round(x,1),round(y,1)))
    return P
def tr_y(dy): return 'translate(0,%s)'%f(dy*S)
def g(id_, body, tr=''):
    return '<g id="%s"%s>%s</g>'%(id_,(' transform="%s"'%tr) if tr else '',body)
def doc(body, vb):
    x,y,w,h=vb
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="%s %s %s %s" width="%s" height="%s">\n'
            '<g stroke-linecap="round" stroke-linejoin="round">\n%s\n</g>\n</svg>\n')%(f(x),f(y),f(w),f(h),f(w),f(h),body)
def render(svg, png, long=1024):
    m=re.search(r'viewBox="([\d\.\- ]+)"',open(svg).read()); x,y,w,h=map(float,m.group(1).split())
    a=['-w',str(long)] if w>=h else ['-h',str(long)]
    subprocess.run(['rsvg-convert',*a,'-a','-b','none',svg,'-o',png],check=True)
ASSET='/home/claude/game/assets'
def finalize(name, body, ws=(0,0,500,600)):
    """Write work-space svg (unit coords of the photo crop) and the tight final svg (+12 pad) + png."""
    import numpy as np
    from PIL import Image
    X,Y,W,H=[v*S for v in ws]; ws=(X,Y,W,H); M=60
    tmp='/home/claude/game/work/m2/%s_tmp.svg'%name
    open(tmp,'w').write(doc(body,(X-M,Y-M,W+2*M,H+2*M)))
    subprocess.run(['rsvg-convert','-z','4','-b','none',tmp,'-o',tmp+'.png'],check=True)
    a=np.array(Image.open(tmp+'.png'))[...,3]; ys,xs=np.nonzero(a>0)
    x0,x1=xs.min()/4+X-M,(xs.max()+1)/4+X-M; y0,y1=ys.min()/4+Y-M,(ys.max()+1)/4+Y-M
    vb=(math.floor(x0-12),math.floor(y0-12),math.ceil(x1-x0+24),math.ceil(y1-y0+24))
    fn='%s/svg/%s.svg'%(ASSET,name); open(fn,'w').write(doc(body,vb))
    render(fn,'%s/png/%s.png'%(ASSET,name))
    open('/home/claude/game/work/m2/%s_ws.svg'%name,'w').write(doc(body,ws))  # ws in sprite units
    return vb
