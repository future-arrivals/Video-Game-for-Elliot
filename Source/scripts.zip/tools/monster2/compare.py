# Build compare_monster.png: photo crop (left) | redraw (right), same size & orientation, per sprite
import json, subprocess
from PIL import Image, ImageDraw
from uv import region
A='/home/claude/game/assets'
mv=json.load(open('/home/claude/game/work/m2/monster_vb.json')); iv=json.load(open('/home/claude/game/work/m2/items_vb.json'))
S=1.15
def svgpng(name,W,H):
    subprocess.run(['rsvg-convert','-w',str(W),'-h',str(H),'-b','white','%s/svg/%s.svg'%(A,name),'-o','/tmp/m2_c.png'],check=True)
    return Image.open('/tmp/m2_c.png').convert('RGB')
rows=[]
def row(name,key,ub,H):
    x0,y0,x1,y1=ub; ppu=H/(y1-y0)
    ph=region(key,x0,y0,x1,y1,ppu); rd=svgpng(name,ph.width,ph.height); rows.append((name,ph,rd))
for name,key in [('monster_unfolded','u'),('monster_folded','f')]:
    x,y,w,h=mv['unfolded' if 'un' in name else 'folded']; row(name,key,(x/S,y/S,(x+w)/S,(y+h)/S),900 if 'un' in name else 520)
for name,d in iv.items():
    x,y,w,h=d['vb']; k=d['k']; bx,by=d['src_bbox'][:2]
    u=lambda X,Y:((X-20)/k+bx,(Y-20)/k+by)
    a=u(x,y); b=u(x+w,y+h); row(name,'u',(a[0],a[1],b[0],b[1]),330)
# layout: monster rows full width, items two per row
W=max(r[1].width*2+30 for r in rows[:2]); blocks=[]
for n,ph,rd in rows[:2]:
    im=Image.new('RGB',(ph.width*2+30,ph.height+30),'white'); im.paste(ph,(0,30)); im.paste(rd,(ph.width+30,30)); ImageDraw.Draw(im).text((4,8),n+'  (photo | redraw)',fill='black'); blocks.append(im)
items=rows[2:]; line=[]; lw=0
for n,ph,rd in items:
    im=Image.new('RGB',(ph.width*2+20,ph.height+30),'white'); im.paste(ph,(0,30)); im.paste(rd,(ph.width+20,30)); ImageDraw.Draw(im).text((4,8),n,fill='black')
    if lw+im.width+30>W and line: blocks.append(line); line=[]; lw=0
    line.append(im); lw+=im.width+30
if line: blocks.append(line)
def flat(b):
    if isinstance(b,list):
        h=max(i.height for i in b); o=Image.new('RGB',(W,h),'white'); x=0
        for i in b: o.paste(i,(x,0)); x+=i.width+30
        return o
    return b
blocks=[flat(b) for b in blocks]
out=Image.new('RGB',(W,sum(b.height+20 for b in blocks)),(235,235,235)); y=0
for b in blocks: out.paste(b,(0,y)); y+=b.height+20
out.save(A+'/compare_monster.png'); print(out.size)
