# uv.py src ux0 uy0 ux1 uy1 ppu out [svg_ws]  -- photo region in unit coords with grid; optional overlay of work-space svg
import sys, math, subprocess
from PIL import Image, ImageDraw
Image.MAX_IMAGE_PIXELS=None
SRC={'u':('/home/claude/game/work/m2/u_up.png',0.115,-46,-64.4),
     'f':('/home/claude/game/work/m2/folded_reg.png',0.2,-20,-20)}
_cache={}
def photo(key):
    if key not in _cache: _cache[key]=Image.open(SRC[key][0]).convert('RGB')
    return _cache[key]
def region(key,ux0,uy0,ux1,uy1,ppu):
    f,s,ox,oy=SRC[key]; im=photo(key)
    tp=lambda u,o:(u-o)/s
    cr=im.crop((int(tp(ux0,ox)),int(tp(uy0,oy)),int(tp(ux1,ox)),int(tp(uy1,oy))))
    return cr.resize((int((ux1-ux0)*ppu),int((uy1-uy0)*ppu)),Image.LANCZOS)
def grid(cr,ux0,uy0,ux1,uy1,ppu,step=None):
    d=ImageDraw.Draw(cr); W,H=cr.size
    step=step or (10 if ppu>=3 else 20)
    for u in range(int(math.ceil(ux0/step))*step,int(ux1)+1,step):
        X=(u-ux0)*ppu; d.line([(X,0),(X,H)],fill=(0,140,255) if u%50==0 else (170,215,255)); d.text((X+2,2),str(u),fill=(255,0,0))
    for u in range(int(math.ceil(uy0/step))*step,int(uy1)+1,step):
        Y=(u-uy0)*ppu; d.line([(0,Y),(W,Y)],fill=(0,140,255) if u%50==0 else (170,215,255)); d.text((2,Y+2),str(u),fill=(255,0,0))
    return cr
if __name__=='__main__':
    key=sys.argv[1]; ux0,uy0,ux1,uy1=map(float,sys.argv[2:6]); ppu=float(sys.argv[6]); out=sys.argv[7]
    cr=region(key,ux0,uy0,ux1,uy1,ppu)
    if len(sys.argv)>8:
        svg=sys.argv[8]; W,H=cr.size
        tmp='/tmp/m2_uv.svg'; s=open(svg).read()
        import re
        s=re.sub(r'viewBox="[^"]*" width="[^"]*" height="[^"]*"','viewBox="%g %g %g %g" width="%d" height="%d"'%(ux0,uy0,ux1-ux0,uy1-uy0,W,H),s,1)
        open(tmp,'w').write(s)
        subprocess.run(['rsvg-convert','-b','none',tmp,'-o','/tmp/m2_uv.png'],check=True)
        sv=Image.open('/tmp/m2_uv.png').convert('RGBA')
        a=sv.split()[3].point(lambda v:int(v*0.55))
        sv.putalpha(a); base=cr.convert('RGBA'); base.alpha_composite(sv); cr=base.convert('RGB')
    grid(cr,ux0,uy0,ux1,uy1,ppu).save(out)
