import sys, math, subprocess, re
sys.path.insert(0,'/home/claude/game/tools/flat')
from svgkit import path, shape, line, ellipse, doc, render, OUT   # reuse helper (read-only import)
import numpy as np
from PIL import Image
ASSET='/home/claude/game/assets'
BLACK='#1a1a1a'; WHITE='#fbfaf6'
def fillonly(P,fill): return '<path d="%s" fill="%s" stroke="none"/>'%(path(P,True),fill)
def oline(P,sw=9): return line(P,sw)
def dot(cx,cy,rx,ry,fill=BLACK,sw=0,rot=0):
    return ellipse(cx,cy,rx,ry,fill,sw=sw if sw else 1,rot=rot,wob=0.02,stroke=OUT if sw else None)
def g(id_,body,extra=''): return '<g id="%s"%s>%s</g>'%(id_,extra,body)
def bbox(body, box=(-100,-100,1000,1000), z=2):
    x0,y0,x1,y1=box; tmp='/tmp/p2_bbox.svg'
    open(tmp,'w').write(doc(body,(x0,y0,x1-x0,y1-y0)))
    subprocess.run(['rsvg-convert','-z',str(z),'-b','none',tmp,'-o','/tmp/p2_bbox.png'],check=True)
    a=np.array(Image.open('/tmp/p2_bbox.png'))[...,3]; ys,xs=np.nonzero(a>0)
    return xs.min()/z+x0,ys.min()/z+y0,(xs.max()+1)/z+x0,(ys.max()+1)/z+y0
def write(name, body, box=(-100,-100,1000,1000)):
    x0,y0,x1,y1=bbox(body,box)
    vb=(math.floor(x0-12),math.floor(y0-12),math.ceil(x1-x0+24),math.ceil(y1-y0+24))
    f='%s/svg/%s.svg'%(ASSET,name); open(f,'w').write(doc(body,vb))
    render(f,'%s/png/%s.png'%(ASSET,name)); return vb
def worksvg(body, W, H, out):
    open(out,'w').write(doc(body,(0,0,W,H)))

class Scaled:
    """author in crop units; emit in sprite units (u*s). stroke widths are given in sprite units."""
    def __init__(s, k, ox=0, oy=0): s.k=k; s.ox=ox; s.oy=oy
    def P(s, pts): return [tuple([(p[0]-s.ox)*s.k,(p[1]-s.oy)*s.k]+list(p[2:])) for p in pts]
    def shape(s, pts, fill, sw=7): return shape(s.P(pts), fill, sw)
    def line(s, pts, sw=7): return line(s.P(pts), sw)
    def fillonly(s, pts, fill): return fillonly(s.P(pts), fill)
    def ell(s, cx, cy, rx, ry, fill, sw=7, rot=0, stroke=True):
        return ellipse((cx-s.ox)*s.k, (cy-s.oy)*s.k, rx*s.k, ry*s.k, fill, sw=sw, rot=rot, wob=0.02, stroke=OUT if stroke else None)
