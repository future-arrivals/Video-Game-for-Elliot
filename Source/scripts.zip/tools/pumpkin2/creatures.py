# Hand-placed bezier redraws of the creatures/items on the pumpkin sheet (IMG_3520).
# Each sprite is authored in the unit space of its photo crop (u = px/K) and emitted scaled by S.
import sys, json
from kit import *
from pumpkin import ORANGE, YELLOW
C='/home/claude/game/assets/crops/'; R='/home/claude/game/assets/reference/'
SPR={}   # name -> (body, crop, K, S, ox, oy)

# ---------------- ghost.svg : droopy-faced ghost with arms out (crop pumpkin2_ghost, K=3) ----------------
S=0.9; k=Scaled(S)
body=[(160,12),(190,20),(207,37),(218,60),(220,82),(213,108),(208,150),(203,187),(200,207),(196,218),(185,223),(177,213),(170,197),(161,181),
      (152,184),(143,200),(133,210),(120,212),(113,200),(110,173),(103,160),(94,160),(80,173),(60,193),(47,202),(37,197),(30,177),(33,150),
      (43,123),(60,90),(80,57),(100,33),(122,18)]
armR=[(214,82),(240,74),(266,80),(278,97),(271,120),(253,139),(233,148),(210,152)]
b=k.shape(armR,WHITE)+k.shape(body,WHITE)+k.line([(73,38),(52,37),(30,44),(11,55),(4,73),(13,90),(32,100)])
b+=k.shape([(121,47),(129,44),(138,42.5),(137,46),(129,48.5),(121,49.5)],BLACK,5)+k.shape([(157,50),(165,45),(173,42),(172,46.5),(165,50),(158,52)],BLACK,5)
b+=k.shape([(99,107),(84,111),(68,123),(58,140),(58,151),(68,151),(84,139),(102,127)],WHITE)        # tongue
b+=k.line([(99,84),(97,100),(104,117),(120,128),(140,127),(162,111),(178,89)])
SPR['ghost']=(b,C+'pumpkin2_ghost.jpg',3,S)

# ---------------- bat.svg : smiley stick-figure bat (crop pumpkin2_bat, K=4.5) ----------------
S=0.92; k=Scaled(S)
wingL=[(9,50,'c'),(30,33,'c'),(50,20,'c'),(38,44,'c'),(62,32,'c'),(56,58,'c'),(68,54),(82,48),(96,57),(102,78,'c'),(112,86,'c'),(86,75),(57,63)]
wingR=[(150,96,'c'),(170,82),(188,77),(204,82),(213,95),(218,123,'c'),(245,87,'c'),(256,136,'c'),(272,80,'c'),(280,92,'c'),(281,147,'c'),(257,143),(217,133),(187,122)]
b=k.shape(wingL,WHITE)+k.shape(wingR,WHITE)
b+=k.line([(118,114),(101,125),(85,137)])+k.line([(85,137),(63,146)])+k.line([(84,139),(67,157)])+k.line([(86,140),(91,166)])
b+=k.line([(140,123),(152,155),(165,173)])+k.line([(165,173),(177,188)])+k.line([(164,174),(149,193)])+k.line([(164,175),(163,198)])
b+=k.ell(133,92,24,28,WHITE,rot=-12)
b+=k.line([(127,63),(132,79)],6)+k.ell(124.5,80.5,3.6,2.4,BLACK,stroke=False,rot=-10)+k.ell(147,89,3.6,3.8,BLACK,stroke=False)
b+=k.line([(120,92),(124,104),(132,110),(142,104)],6)
SPR['bat']=(b,C+'pumpkin2_bat.jpg',4.5,S)

# ---------------- spider.svg : angry spider-bat with teeth (crop pumpkin2_spider, K=4.2) ----------------
S=1.0; k=Scaled(S)
wingL=[(31,55,'c'),(60,83,'c'),(69,13,'c'),(79,87,'c'),(88,27,'c'),(96,84,'c'),(101,38,'c'),(104,80),(114,62),(123,56),(130,70),(137,96,'c'),(100,90),(62,84)]
wingL=[(31,55,'c'),(69,13,'c'),(79,82,'c'),(88,27,'c'),(96,82,'c'),(101,38,'c'),(104,77),(114,60),(123,55),(130,70),(137,96,'c'),(100,91),(62,84)]
wingR=[(180,96,'c'),(214,49,'c'),(220,86,'c'),(252,43,'c'),(258,85,'c'),(219,88),(185,98)]
b=k.line([(32,55),(22,37)])+k.line([(32,55),(36,36)])+k.line([(32,55),(14,53)])
b+=k.shape(wingL,WHITE)+k.shape(wingR,WHITE)
for a,c2 in [((131,111),(112,132)),((136,114),(125,137)),((143,116),(143,138)),((164,117),(173,147)),((172,116),(183,145)),((178,113),(198,138))]:
    b+=k.line([a,c2])
b+=k.ell(158,93,23,24,WHITE,rot=0)
b+=k.line([(150,66),(166,73)],6)+k.line([(184,60),(176,77)],6)
b+=k.ell(153,84,3.6,4.4,BLACK,stroke=False,rot=10)+k.ell(173,87,3.4,5.0,BLACK,stroke=False)
b+=k.shape([(142,99,'c'),(174,98,'c'),(171,110),(158,115),(146,111)],WHITE,5)
for x in (149,157,165): b+=k.line([(x,99),(x+0.5,109)],5)
SPR['spider']=(b,C+'pumpkin2_spider.jpg',4.2,S)

# ---------------- lollipop.svg : spiral on a stick (reference photo_lollipop, K=1.9) ----------------
import math
S=1.0; k=Scaled(S)
stick=[(118,115,'c'),(263,197,'c'),(251,234,'c'),(103,140,'c')]
disc=[(100,26),(132,36),(152,60),(160,88),(156,112),(142,131),(120,162),(92,168),(68,164),(44,148),(24,120),(20,96),(32,56),(60,34)]
sp=[]
cx,cy=89,95
for i in range(0,48):
    t=i/48*2.33                     # 2.33 turns, ending at the stick like his
    th=math.radians(-76)+2*math.pi*t
    r=4+21*t
    sp.append((cx+r*math.cos(th)*1.06, cy+r*math.sin(th)))
b=k.shape(stick,WHITE)+k.shape(disc,WHITE)+k.line(sp)
SPR['lollipop']=(b,R+'photo_lollipop.jpg',1.9,S)

# ---------------- candy.svg : wrapped candy (reference photo_candy, K=3.3) ----------------
S=1.15; k=Scaled(S)
b=k.shape([(30,17,'c'),(16,112,'c'),(100,93,'c'),(95,78,'c')],WHITE)
b+=k.shape([(222,54,'c'),(231,110,'c'),(125,118,'c'),(138,90,'c')],WHITE)
b+=k.ell(116,92,26.5,31.5,WHITE,rot=-4)
SPR['candy']=(b,R+'photo_candy.jpg',3.3,S)

# ---------------- orange_object.svg : mitten joined to a lumpy shape (crop pumpkin2_orange, K=4) ----------------
S=0.95; k=Scaled(S)
mitten=[(51,42,'c'),(39,40),(37,30),(43,19),(54,14),(66,17),(76,30),(84,58),(88,100),(86,128),(80,137,'c'),(22,139,'c'),(13,123),(10,108),(16,94),
        (27,83),(28,72),(18,64),(17,53),(28,46)]
blob=[(118,160),(150,140),(185,125),(210,120),(228,127),(240,139),(258,146),(266,164),(270,180,'c'),(257,186),(246,198),(240,210),(222,214),
      (200,219),(181,215),(160,209),(138,207),(124,201),(117,188),(114,172)]
oval=[(100,124),(114,134),(118,155),(112,175),(100,183),(85,175),(78,158),(84,135)]
b=k.shape(mitten,ORANGE)+k.shape(blob,ORANGE)+k.shape(oval,ORANGE)
SPR['orange_object']=(b,C+'pumpkin2_orange.jpg',4,S)

# ---------------- ghost_2 / ghost_3 : small ghosts from inside the pumpkin (pumpkin units, reference photo_pumpkin_unfolded K=5.8 X0=100) ----
S=2.75; k=Scaled(S,138,546)
b=k.shape([(167,580),(152,575),(141,578),(142,586),(152,590),(167,588)],WHITE)
b+=k.shape([(212,582),(224,579),(231,583),(228,592),(214,598)],WHITE)
b+=k.shape([(191,551),(207,557),(214,578),(210,600),(201,616),(194,628,'c'),(184,613),(170,599),(166,580),(173,561)],WHITE)
b+=k.ell(189,564,2.3,3.3,BLACK,stroke=False)+k.ell(204.5,566,2.3,3.3,BLACK,stroke=False)
b+=k.line([(175,578),(179,592),(191,600),(202,595),(207,586)],7)+k.line([(182,585),(188,592),(197,593),(202,589)],6)
SPR['ghost_2']=(b,R+'photo_pumpkin_unfolded.jpg',5.8,S,138,546)
S=2.5; k=Scaled(S,243,544)
body6=[(250,578),(246,580,'c'),(257,567),(274,558),(295,551),(317,547),(333,549),(343,562),(344,574),(340,587),(334,595),(328,594),(325,585),(321,581),
       (316,585),(312,595),(309,605),(305,606),(300,600),(292,587),(286,582),(280,584),(275,593),(268,607),(262,613),(257,610),(253,595)]
b=k.shape(body6,WHITE)
b+=k.ell(268,575,3.8,5.8,WHITE,sw=6,rot=10)+k.ell(292,565,2.4,3.4,BLACK,stroke=False,rot=20)+k.ell(315,562.5,4.6,3.6,BLACK,stroke=False,rot=-10)
b+=k.line([(297,571),(300,582),(304,588),(309,585),(313,578),(317,574)],7)
b+=k.shape([(306,586),(311,585),(312.5,592),(310,598.5),(306,597.5),(305,591)],BLACK,4)
SPR['ghost_3']=(b,R+'photo_pumpkin_unfolded.jpg',5.8,S,243,544)
# ---------------- ghost_big : the boss ghost from inside the pumpkin, pumpkin scale (stroke 9) ----------------
import pumpkin as PK
k=Scaled(1.0)
b=k.shape(PK.armR,WHITE,9)+k.shape(PK.armL,WHITE,9)+k.shape(PK.body1,WHITE,9)
b+=k.shape([(161,293),(170,284),(183,284),(191,295),(188,312),(178,324),(166,314)],BLACK,4)+k.ell(172,292,5.2,4.4,WHITE,stroke=False,rot=-20)
b+=k.shape([(216,284),(226,276),(240,278),(247,292),(243,308),(235,316),(222,305)],BLACK,4)+k.ell(227,285,5.2,4.4,WHITE,stroke=False,rot=-20)
b+=k.shape([(184,334,'c'),(212,331),(240,334,'c'),(239,352),(232,371),(217,386),(203,379),(192,361)],BLACK,6)
SPR['ghost_big']=(b,R+'photo_pumpkin_unfolded.jpg',5.8,1.0,0,0)

if __name__=='__main__':
    meta={}
    for n,v in SPR.items():
        b=v[0]; vb=write(n,b,(-300,-300,1500,1500)); meta[n]=dict(vb=vb,crop=v[1],K=v[2],S=v[3],ox=v[4] if len(v)>4 else 0,oy=v[5] if len(v)>5 else 0)
        print(n,vb)
    json.dump(meta,open('/tmp/p2_creatures_meta.json','w'),indent=1)
