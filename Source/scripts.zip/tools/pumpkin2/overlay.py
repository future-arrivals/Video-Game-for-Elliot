# overlay.py ref K X0 Y0 worksvg ux0 uy0 ux1 uy1 ppu out  -> photo | redraw | 50% blend (region in unit coords)
import sys, subprocess, re
from PIL import Image
ref=sys.argv[1]; K,X0,Y0=map(float,sys.argv[2:5]); ws=sys.argv[5]; ux0,uy0,ux1,uy1=map(float,sys.argv[6:10]); ppu=float(sys.argv[10]); out=sys.argv[11]
im=Image.open(ref).convert('RGB')
W,H=int((ux1-ux0)*ppu),int((uy1-uy0)*ppu)
ph=im.crop((int(ux0*K+X0),int(uy0*K+Y0),int(ux1*K+X0),int(uy1*K+Y0))).resize((W,H),Image.LANCZOS)
s=open(ws).read(); s=re.sub(r'viewBox="[^"]+" width="[^"]+" height="[^"]+"','viewBox="%g %g %g %g" width="%d" height="%d"'%(ux0,uy0,ux1-ux0,uy1-uy0,W,H),s,1)
open('/tmp/p2_ov.svg','w').write(s)
subprocess.run(['rsvg-convert','/tmp/p2_ov.svg','-o','/tmp/p2_ov.png'],check=True)
sv=Image.open('/tmp/p2_ov.png').convert('RGBA'); bg=Image.new('RGBA',sv.size,'white'); bg.alpha_composite(sv); sv=bg.convert('RGB')
bl=Image.blend(ph,sv,0.5)
o=Image.new('RGB',(W*3+20,H),'white'); o.paste(ph,(0,0)); o.paste(sv,(W+10,0)); o.paste(bl,(2*W+20,0)); o.save(out)
