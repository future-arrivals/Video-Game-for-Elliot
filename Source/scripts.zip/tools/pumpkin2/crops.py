# upright, lighting-corrected crops from the full-res HEIC of IMG_3520 (paper white normalised)
import numpy as np, glob
import pillow_heif; pillow_heif.register_heif_opener()
from PIL import Image, ImageOps
f=glob.glob('/mnt/user-data/uploads/*IMG_3520.HEIC')[0]
im=ImageOps.exif_transpose(Image.open(f)).convert('RGB'); s=im.width/1050
R=dict(orange=(740,560,1015,790),spider=(780,1060,1050,1230),bat=(740,770,1050,990),ghost=(830,430,1040,600))
for n,box in R.items():
    c=np.asarray(im.crop(tuple(int(v*s) for v in box))).astype(float)
    w=np.percentile(c.reshape(-1,3),92,0)
    c=np.clip(c/w,0,1)**1.25*255
    Image.fromarray(c.astype(np.uint8)).save('/home/claude/game/assets/crops/pumpkin2_%s.jpg'%n,quality=92)
