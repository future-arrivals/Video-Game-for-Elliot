# grid.py ref K X0 Y0 ux0 uy0 ux1 uy1 ppu out  -- view ref photo region in unit coords (u=(px-X0)/K)
import sys, math
from PIL import Image, ImageDraw
ref=sys.argv[1]; K,X0,Y0=map(float,sys.argv[2:5]); ux0,uy0,ux1,uy1=map(float,sys.argv[5:9]); ppu=float(sys.argv[9]); out=sys.argv[10]
im=Image.open(ref).convert('RGB')
cr=im.crop((int(ux0*K+X0),int(uy0*K+Y0),int(ux1*K+X0),int(uy1*K+Y0)))
W,H=int((ux1-ux0)*ppu),int((uy1-uy0)*ppu); cr=cr.resize((W,H),Image.LANCZOS); d=ImageDraw.Draw(cr)
step=float(sys.argv[11]) if len(sys.argv)>11 else (10 if ppu>=3 else 20)
u=math.ceil(ux0/step)*step
while u<=ux1:
    X=(u-ux0)*ppu; d.line([(X,0),(X,H)],fill=(0,140,255) if u%50==0 else (150,210,255)); d.text((X+2,2),'%g'%u,fill=(255,0,0)); u+=step
u=math.ceil(uy0/step)*step
while u<=uy1:
    Y=(u-uy0)*ppu; d.line([(0,Y),(W,Y)],fill=(0,140,255) if u%50==0 else (150,210,255)); d.text((2,Y+2),'%g'%u,fill=(255,0,0)); u+=step
cr.save(out)
