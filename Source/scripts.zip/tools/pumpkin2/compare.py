# builds assets/compare_pumpkin_creatures.png (photo | redraw) and crops/pumpkin2_bgcheck.png (dark | mid-green)
import json, re, subprocess
from PIL import Image, ImageDraw
A='/home/claude/game/assets'
cm=json.load(open('/tmp/p2_creatures_meta.json'))
def vbox(n): return list(map(float,re.search(r'viewBox="([^"]+)"',open(f'{A}/svg/{n}.svg').read()).group(1).split()))
def photo_for(n):
    x,y,w,h=vbox(n)
    if n=='pumpkin_folded':
        return Image.open(f'{A}/reference/photo_pumpkin_folded.jpg').crop((0,40,2450,1920))
    if n=='pumpkin_unfolded': ref,K,X0,S,ox,oy=f'{A}/reference/photo_pumpkin_unfolded.jpg',5.8,100,1,0,0
    else:
        m=cm[n]; ref,K,S,ox,oy=m['crop'],m['K'],m['S'],m['ox'],m['oy']; X0=100 if 'pumpkin_unfolded' in ref else 0
    im=Image.open(ref).convert('RGB')
    f=lambda u,o,O: (u/S+o)*K+O
    box=(f(x,ox,X0),f(y,oy,0),f(x+w,ox,X0),f(y+h,oy,0))
    bg=Image.new('RGB',(int(box[2]-box[0]),int(box[3]-box[1])),(200,200,200)); bg.paste(im.crop(tuple(map(int,box))),(0,0)); return bg
def render(n,h,bgc):
    subprocess.run(['rsvg-convert','-h',str(h),f'{A}/svg/{n}.svg','-o','/tmp/p2_cmp.png'],check=True)
    sv=Image.open('/tmp/p2_cmp.png').convert('RGBA'); b=Image.new('RGBA',sv.size,bgc); b.alpha_composite(sv); return b.convert('RGB')
names=['pumpkin_unfolded','pumpkin_folded','ghost_big','ghost','ghost_2','ghost_3','bat','spider','lollipop','candy','orange_object']
cells=[]
for n in names:
    H=640 if n=='pumpkin_unfolded' else 300
    ph=photo_for(n); ph=ph.resize((int(ph.width*H/ph.height),H))
    sv=render(n,H,'white'); cells.append((n,ph,sv,render(n,H,(28,30,40)),render(n,H,(70,140,70))))
def sheet(cols,out,lab):
    rows=[[cells[0]],[cells[1],cells[2]],[cells[3],cells[4],cells[5]],[cells[6],cells[7]],[cells[8],cells[9],cells[10]]]
    def cw(c): return sum(c[i].width for i in cols)+10*(len(cols)-1)
    W=max(sum(cw(c)+30 for c in r) for r in rows)+20
    Ht=sum(max(c[1].height for c in r)+30 for r in rows)+10
    S=Image.new('RGB',(W,Ht),(235,235,235)); d=ImageDraw.Draw(S); yy=5
    for r in rows:
        xx=10
        for c in r:
            d.text((xx,yy),c[0]+' '+lab,fill='black'); x2=xx
            for i in cols: S.paste(c[i],(x2,yy+16)); x2+=c[i].width+10
            xx+=cw(c)+30
        yy+=max(c[1].height for c in r)+30
    S.save(out)
sheet([1,2],f'{A}/compare_pumpkin_creatures.png','(photo | redraw)')
sheet([3,4],f'{A}/crops/pumpkin2_bgcheck.png','(dark | green)')
