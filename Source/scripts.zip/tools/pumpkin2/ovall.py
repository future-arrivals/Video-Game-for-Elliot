import json, subprocess, re
from PIL import Image
m=json.load(open('/tmp/p2_creatures_meta.json')); A='/home/claude/game/assets'
outs=[]
for n in ['ghost','bat','spider','candy','orange_object','ghost_2','ghost_3']:
    v=m[n]; x,y,w,h=v['vb']; K=v['K']/v['S']; X0=v['ox']*v['K']+(100 if 'pumpkin_unfolded' in v['crop'] else 0); Y0=v['oy']*v['K']
    ppu=300/h
    subprocess.run(['python3','overlay.py',v['crop'],str(K),str(X0),str(Y0),f'{A}/svg/{n}.svg',str(x),str(y),str(x+w),str(y+h),str(ppu),f'/tmp/ov_{n}.png'],check=True,stderr=subprocess.DEVNULL)
    outs.append(Image.open(f'/tmp/ov_{n}.png'))
W=max(o.width for o in outs[:4]); 
S=Image.new('RGB',(max(o.width for o in outs)*2+10, sum(o.height+10 for o in outs[::2])),'white')
yy=0
for i in range(0,len(outs),2):
    S.paste(outs[i],(0,yy))
    if i+1<len(outs): S.paste(outs[i+1],(outs[i].width+10,yy))
    yy+=310
S.save('/tmp/ovall.png')
