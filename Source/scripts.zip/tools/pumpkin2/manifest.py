import json, re
A='/home/claude/game/assets'
from pumpkin import T,B,D,LO,RO
def vb(n): return [float(v) for v in re.search(r'viewBox="([^"]+)"',open(f'{A}/svg/{n}.svg').read()).group(1).split()]
def ids(n): return re.findall(r'<g id="([^"]+)"',open(f'{A}/svg/{n}.svg').read())
S=[('pumpkin_unfolded','pumpkin','unfolded (mouth open)'),('pumpkin_folded','pumpkin','folded (mouth shut)'),
   ('ghost_big','big ghost from inside the pumpkin (boss): big black eyes with highlights, black open mouth, right arm raised','creature (boss)'),
   ('ghost','droopy-faced ghost with tongue out and arms out (drawn beside the pumpkin)','creature'),
   ('ghost_2','small grinning ghost with pointed tail and two arms (bottom-middle ghost inside the pumpkin)','creature'),
   ('ghost_3','wide three-eyed ghost with tongue (bottom-right ghost inside the pumpkin)','creature'),
   ('bat','smiley stick-figure bat with zigzag wings','creature'),
   ('spider','angry spider-bat with teeth, six legs and zigzag wings','creature'),
   ('lollipop','spiral lollipop','pickup'),('candy','wrapped candy','pickup'),
   ('orange_object','orange mitten/hand joined by a small oval to a lumpy shape','pickup/prop')]
out={'spec':'Hand-placed bezier paths (Catmull-Rom through hand-read points -> cubic C), stroke #1a1a1a round caps/joins; pumpkin & ghost_big stroke 9 (6-7 for small ghosts/faces/web); doodles ~250 units, stroke 7. Flat fills only. Scripts: tools/pumpkin2/.',
 'pumpkin_hinge':{'top_hinge_line_y':T,'bottom_hinge_line_y':B,'hinge_x_range':[LO,RO],'inside_span_y':[T,B],'folded_part_bottom_translate':[0,-D],
   'description':f'Both hinges are horizontal. part-top ends at y={T}; part-inside spans y {T}..{B}; part-bottom starts at y={B}. pumpkin_folded uses identical part-top/part-bottom geometry with part-bottom transform translate(0,-{D}) and no part-inside: the lower teeth tips then sit on the upper mouth line, side outlines continue straight through the hinge.',
   'animate':f'Unfold by t in 0..1: translate part-bottom by (0,-{D}*(1-t)); reveal part-inside from y={T} down to {T}+{D}*t (or scale (1,t) about y={T}). Draw order: part-bottom, part-inside, part-top (ghosts in part-inside overlap the lower teeth slightly, as he drew them).',
   'ghosts_inside':6,
   'ghost_ids':{'ghost-1':'big ghost (boss)','ghost-2':'top-left ghost hanging over the left wall','ghost-3':'peeking ghost under the teeth; its head (arc + two eyes) is drawn on the shell in part-top as group ghost-3-head, as he drew it, so it also shows when folded','ghost-4':'bottom-left small ghost','ghost-5':'bottom-middle grinning ghost','ghost-6':'bottom-right three-eyed ghost'}},
 'sprites':[]}
for n,c,f in S:
    v=vb(n); out['sprites'].append({'file':f'svg/{n}.svg','png':f'png/{n}.png','character':c,'form':f,'viewBox':v,'viewBox_size':v[2:],'part_ids':ids(n)})
json.dump(out,open(f'{A}/manifest_pumpkin_creatures.json','w'),indent=1)
print(json.dumps(out['sprites'][:2],indent=0)[:600])
