import sys
from PIL import Image
import numpy as np
ref=sys.argv[1]; K,X0,Y0=map(float,sys.argv[2:5]); mode=sys.argv[5]; vals=[float(v) for v in sys.argv[6].split(',')]
lo,hi=map(float,sys.argv[7].split(','))
a=np.asarray(Image.open(ref).convert('L')).astype(float)
for v in vals:
    if mode=='row':
        py=int(v*K+Y0); line=a[py-2:py+3].mean(0); xs=np.arange(int(lo*K+X0),int(hi*K+X0))
    else:
        px=int(v*K+X0); line=a[:,px-2:px+3].mean(1); xs=np.arange(int(lo*K+Y0),int(hi*K+Y0))
    xs=xs[(xs>=0)&(xs<len(line))]; dark=line[xs]<90
    runs=[];s=None
    for i,d in zip(xs,dark):
        if d and s is None: s=i
        if not d and s is not None: runs.append((s,i));s=None
    o=X0 if mode=='row' else Y0
    print(mode,v,[round(((r[0]+r[1])/2-o)/K,1) for r in runs])
