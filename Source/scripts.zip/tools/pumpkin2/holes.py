# report enclosed transparent regions (holes/gaps) in rendered sprite PNGs
import sys, numpy as np
from PIL import Image
from scipy import ndimage
for n in sys.argv[1:]:
    a=np.asarray(Image.open('/home/claude/game/assets/png/%s.png'%n))[...,3]
    tr=a<128; lab,k=ndimage.label(tr)
    border=set(np.unique(np.concatenate([lab[0],lab[-1],lab[:,0],lab[:,-1]])))
    holes=[(i,(lab==i).sum()) for i in range(1,k+1) if i not in border]
    big=[(i,s) for i,s in holes if s>20]
    print(n, 'enclosed transparent regions:', len(holes), 'sizes>20px:', [s for i,s in big][:10])
    for i,s in big[:5]:
        ys,xs=np.nonzero(lab==i); print('   at px', xs.mean().round(), ys.mean().round())
