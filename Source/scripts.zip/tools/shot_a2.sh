#!/bin/sh
# usage: shot_a2.sh <hash> <out.png>   (renders one 844x390 frame of style-A2.html at 2x)
google-chrome --headless=new --no-sandbox --disable-gpu --hide-scrollbars --force-device-scale-factor=2 \
  --window-size=844,390 --virtual-time-budget=6000 --screenshot="$2" "file:///home/claude/game/style/style-A2.html#$1" 2>/dev/null
