// Opens style-A2.html in headless Chrome in real time, lets the animation run, and reports
// console errors, frames rendered, and per-frame cost measured inside the rAF loop.
const puppeteer = require('puppeteer-core');
(async () => {
  const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox', '--window-size=1250,900'] });
  const p = await b.newPage(); const errs = [];
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  p.on('pageerror', e => errs.push(String(e)));
  await p.setViewport({ width: 1250, height: 900, deviceScaleFactor: 2 });
  await p.goto('file:///home/claude/game/style/style-A2.html');
  await p.waitForFunction('document.body.dataset.ready === "1"', { timeout: 20000 });
  // wrap renderWorld to time real frames
  await p.evaluate(() => { window.__ft = []; const rw = renderWorld; renderWorld = (c, s) => { const a = performance.now(); rw(c, s); window.__ft.push(performance.now() - a); }; });
  const t0 = Date.now(); await new Promise(r => setTimeout(r, 6000));
  const res = await p.evaluate(() => { const f = window.__ft.slice().sort((a, b) => a - b); return { frames: f.length, avg: f.reduce((a, b) => a + b, 0) / f.length, med: f[f.length >> 1], p95: f[Math.floor(f.length * .95)], max: f[f.length - 1], t: document.body.dataset.t, err: document.getElementById('err').textContent }; });
  res.wall = (Date.now() - t0) / 1000; res.fps = res.frames / res.wall;
  await p.screenshot({ path: '/home/claude/game/style/A2-anim-live-capture.png', clip: { x: 28, y: 150, width: 1194, height: 560 } });
  console.log(JSON.stringify({ ...res, consoleErrors: errs }, null, 1));
  await b.close();
})().catch(e => { console.error('FAIL', e); process.exit(1); });
