"""Sample real marker colours from the cut-outs (k-means on coloured pixels)."""
import sys, glob, numpy as np, cv2
from PIL import Image
px=[]
for f in glob.glob(sys.argv[1]+'/*.png'):
    a=np.asarray(Image.open(f).convert('RGBA')).reshape(-1,4)
    a=a[a[:,3]>250][:,:3].astype(np.float32)
    mx,mn=a.max(1),a.min(1); sat=(mx-mn)/np.maximum(mx,1)
    px.append(a[(sat>0.35)&(mx>60)])
px=np.concatenate(px); np.random.seed(0); px=px[np.random.choice(len(px),min(60000,len(px)),replace=False)]
_,lab,cen=cv2.kmeans(px,14,None,(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,50,0.5),5,cv2.KMEANS_PP_CENTERS)
cnt=np.bincount(lab.ravel())
for i in np.argsort(-cnt): c=cen[i].astype(int); print('#%02x%02x%02x'%tuple(c), cnt[i])
