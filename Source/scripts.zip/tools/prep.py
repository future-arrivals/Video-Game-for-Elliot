import cv2, numpy as np, sys
from rectify import flatten
W='/home/claude/game/work'
for n,k in [('3519',0),('3520',0),('3526',1),('3527',1)]:
    img=cv2.imread(f'{W}/full/IMG_{n}.png'); r=np.rot90(img,k).copy()
    fl=flatten(r); cv2.imwrite(f'{W}/flat_{n}.png',fl)
    cv2.imwrite(f'{W}/prev_{n}.jpg',cv2.resize(fl,None,fx=0.25,fy=0.25,interpolation=cv2.INTER_AREA))
    print(n,fl.shape)
