"""Rough sticker-style cut-outs from the drawing photos, for style mockups only.
Usage: python3 rough_crops.py <drawings_dir> <out_dir>
Coordinates are in full-res pixels (previews were half size, so x2)."""
import sys, os
import numpy as np
from PIL import Image, ImageOps, ImageFilter
from scipy import ndimage as ndi

SRC, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)

# name: (file, (x0,y0,x1,y1) in preview coords, rotate CCW degrees, target max px)
CROPS = {
    "pumpkin_folded": ("IMG_3519.jpg", (97, 229, 404, 462), 0, 300),
    "pumpkin_open":   ("IMG_3520.jpg", (102, 106, 402, 616), 0, 360),
    "ghost":          ("IMG_3520.jpg", (412, 212, 522, 302), 0, 140),
    "bat":            ("IMG_3520.jpg", (393, 386, 527, 500), 0, 170),
    "spider":         ("IMG_3520.jpg", (438, 553, 502, 612), 0, 110),
    "lollipop":       ("IMG_3519.jpg", (72, 243, 142, 302), 0, 100),
    "candy":          ("IMG_3519.jpg", (348, 243, 452, 296), 0, 120),
    "fish_folded":    ("IMG_3521.jpg", (168, 88, 448, 388), 0, 260),
    "fish_open":      ("IMG_3522.jpg", (58, 98, 652, 425), 0, 420),
    "icecream_folded":("IMG_3523.jpg", (145, 50, 622, 440), 90, 300),
    "icecream_open":  ("IMG_3524.jpg", (48, 12, 492, 652), 0, 380),
    "cat":            ("IMG_3525.jpg", (198, 38, 372, 127), 90, 200),
    "beaver":         ("IMG_3525.jpg", (152, 242, 378, 402), 90, 240),
    "owl":            ("IMG_3525.jpg", (222, 492, 418, 608), 90, 220),
    "monster_folded": ("IMG_3526.jpg", (198, 58, 502, 472), 90, 300),
    "monster_open":   ("IMG_3527.jpg", (38, 48, 622, 502), 90, 400),
    "pot_folded":     ("IMG_3528.jpg", (190, 48, 522, 492), 90, 300),
    "pot_open":       ("IMG_3529.jpg", (42, 38, 682, 472), 90, 420),
    "juice":          ("IMG_3530.jpg", (122, 122, 368, 478), 0, 260),
}

def cutout(im, main_only=False):
    a = np.asarray(im.convert("RGB")).astype(np.float32) / 255.0
    mx, mn = a.max(2), a.min(2)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-3), 0)
    # local paper brightness, so shadows on the paper don't count as ink
    lum = a.mean(2)
    paper = ndi.maximum_filter(ndi.uniform_filter(lum, 9), 41)
    dark = lum < paper * 0.58
    ink = dark | (sat > 0.22)
    # remove skin (fingers holding the paper)
    hsv = np.asarray(im.convert("HSV")).astype(np.float32) / 255.0
    h, sv, v = hsv[..., 0] * 360, hsv[..., 1], hsv[..., 2]
    skin = (h > 5) & (h < 28) & (sv > 0.10) & (sv < 0.50) & (v > 0.45)
    skin = ndi.binary_opening(skin, iterations=3)
    skin = ndi.binary_dilation(skin, iterations=5)
    ink &= ~skin
    ink = ndi.binary_opening(ink, iterations=1)
    m = ndi.binary_closing(ink, iterations=6)
    m = ndi.binary_fill_holes(m)
    lab, n = ndi.label(m)
    if n:
        sizes = ndi.sum(m, lab, range(1, n + 1))
        keep = np.zeros(n + 1, bool)
        keep[1:] = sizes > max(60, sizes.max() * 0.015)
        # drop bits touching the crop edge (fingers, wood, paper edges), except the main body
        big = int(np.argmax(sizes)) + 1
        edge = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0, big}
        for e in edge:
            keep[e] = False
        if main_only:
            keep[1:] &= sizes > sizes.max() * 0.2
        m = keep[lab]
    # white sticker border around the drawing
    border = ndi.binary_dilation(m, iterations=7)
    border = ndi.binary_fill_holes(border)
    rgba = np.dstack([np.asarray(im.convert("RGB")), (border * 255).astype(np.uint8)])
    # paper pixels inside the sticker become clean white (hides paper shadow)
    rgb = rgba[..., :3].astype(np.float32)
    w = np.clip((lum - paper * 0.80) / (paper * 0.12 + 1e-3), 0, 1)[..., None]
    w = w * (~ink)[..., None]
    rgb = rgb * (1 - w) + 252 * w
    rgba[..., :3] = rgb.astype(np.uint8)
    out = Image.fromarray(rgba, "RGBA")
    alpha = out.split()[3].filter(ImageFilter.GaussianBlur(1.2))
    out.putalpha(alpha)
    return out

for name, (f, box, rot, size) in CROPS.items():
    im = ImageOps.exif_transpose(Image.open(os.path.join(SRC, f)))
    box = tuple(v * 2 for v in box)
    c = im.crop(box)
    if rot:
        c = c.rotate(rot, expand=True)
    c = cutout(c, name.startswith('pumpkin'))
    bb = c.getbbox()
    if bb:
        c = c.crop(bb)
    c.thumbnail((size, size), Image.LANCZOS)
    c.save(os.path.join(OUT, name + ".png"))
    print(name, c.size)
