import cv2, numpy as np, sys
W='/home/claude/game/work'
a,b=sys.argv[1],sys.argv[2]; s=0.35
A=cv2.imread(f'{W}/flat_{a}.png',0); B=cv2.imread(f'{W}/flat_{b}.png',0)
A=cv2.resize(A,None,fx=s,fy=s,interpolation=cv2.INTER_AREA); B=cv2.resize(B,None,fx=s,fy=s,interpolation=cv2.INTER_AREA)
sift=cv2.SIFT_create(8000)
ka,da=sift.detectAndCompute(A,None); kb,db=sift.detectAndCompute(B,None)
m=cv2.BFMatcher().knnMatch(da,db,k=2)
good=[x for x,y in m if x.distance<0.8*y.distance]
pa=np.float32([ka[g.queryIdx].pt for g in good]); pb=np.float32([kb[g.trainIdx].pt for g in good])
print('good',len(good))
for it in range(3):
    if len(pa)<6: break
    M,inl=cv2.estimateAffinePartial2D(pa,pb,method=cv2.RANSAC,ransacReprojThreshold=4,maxIters=20000)
    inl=inl.ravel().astype(bool)
    sc=np.hypot(M[0,0],M[1,0]); ang=np.degrees(np.arctan2(M[1,0],M[0,0]))
    P=pa[inl]/s
    print(f'set{it}: n={inl.sum()} scale={sc:.4f} rot={ang:.2f} t=({M[0,2]/s:.0f},{M[1,2]/s:.0f}) srcbox x{P[:,0].min():.0f}-{P[:,0].max():.0f} y{P[:,1].min():.0f}-{P[:,1].max():.0f}')
    pa,pb=pa[~inl],pb[~inl]
