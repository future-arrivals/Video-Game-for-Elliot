#!/bin/sh
# Screenshot the style page with headless Chrome. usage: shot.sh <html> <png> [width] [height]
google-chrome --headless=new --no-sandbox --disable-gpu --hide-scrollbars --force-device-scale-factor=1 \
  --window-size=${3:-1800},${4:-2900} --screenshot="$2" "file://$1" 2>/dev/null
