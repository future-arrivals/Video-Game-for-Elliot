import numpy as np
def white_balance(img):
    L=img.mean(2)
    sel=img[L>np.percentile(L,70)]
    paper=np.median(sel,0)
    return np.clip(img/paper*240,0,255)
def hsv(img):
    import cv2
    h=cv2.cvtColor(np.clip(img,0,255).astype(np.uint8),cv2.COLOR_RGB2HSV).astype(float)
    return h[...,0]*2,h[...,1]/255,h[...,2]/255
def mask(img,mode):
    H,S,V=hsv(img)
    mx=img.max(2); mn=img.min(2)
    if mode=='black': return ((mx<95)&((mx-mn)<55)).astype(np.uint8)
    if mode=='red': return (((H<15)|(H>340))&(S>0.35)&(V>0.35)).astype(np.uint8)
    if mode=='pink': return (((H>300)|(H<10))&(S>0.12)&(S<0.6)&(V>0.6)).astype(np.uint8)
    if mode=='teal': return ((H>160)&(H<200)&(S>0.25)).astype(np.uint8)
    if mode=='ltgreen': return ((H>60)&(H<100)&(S>0.3)&(V>0.4)).astype(np.uint8)
    if mode=='green': return ((H>110)&(H<170)&(S>0.2)&(V>0.3)).astype(np.uint8)
    raise ValueError(mode)

def mask2(img,mode):
    H,S,V=hsv(img)
    if mode=='redfill': return (((H<14)|(H>340))&(S>0.5)&(V>0.5)).astype(np.uint8)
    if mode=='brown': return (((H<32)|(H>350))&(S>0.55)&(V>0.12)&(V<0.68)).astype(np.uint8)
    if mode=='white': return ((S<0.28)&(V>0.72)).astype(np.uint8)
    if mode=='tealfill': return ((H>160)&(H<205)&(S>0.35)&(V>0.3)).astype(np.uint8)
    if mode=='pinkfill': return (((H>300)|(H<12))&(S>0.18)&(V>0.6)).astype(np.uint8)
    if mode=='red2': return (((H<14)|(H>335))&(S>0.35)&(V>0.4)).astype(np.uint8)
    if mode=='grey': return ((S<0.3)&(V>0.12)&(V<0.45)).astype(np.uint8)
    if mode=='ltgreenfill': return ((H>55)&(H<105)&(S>0.35)&(V>0.35)).astype(np.uint8)
    if mode=='dkgreen': return ((H>105)&(H<175)&(S>0.4)&(V>0.12)).astype(np.uint8)
    return mask(img,mode)
