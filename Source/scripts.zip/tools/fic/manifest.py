import json, re
from build import write_pair
A='/home/claude/game/assets'
def vb(n): return [float(v) for v in re.search(r'viewBox="([^"]+)"',open(f'{A}/svg/{n}.svg').read()).group(1).split()]
def ids(n): return re.findall(r'<g id="([^"]+)"',open(f'{A}/svg/{n}.svg').read())
import icecream as IC
r=write_pair(IC.sp,IC.PARTS,'icecream_unfolded',title='Ice cream (unfolded)')
U=lambda y:(y-IC.sp.o[1])*IC.S
fish=json.load(open('fish_res.json')); pot=json.load(open('pot_res.json')); icf=json.load(open('icf_res.json'))
dood=json.load(open('doodle_res.json'))
fb=fish['_bands']; pb=pot['_bands']
M={'scale_note':'units = SVG user units; folded long side ~400. Outline stroke #1a1a1a width 9 (fine face/handwriting/grid details 4-7 where 9 would fill the shape in); doodles 7 in his marker colour.',
 'sprites':[]}
def add(n,char,form,hinge,extra=None):
    v=vb(n); d={'file':f'svg/{n}.svg','png':f'png/{n}.png','character':char,'form':form,'viewBox':v,'size':[v[2],v[3]],'part_ids':ids(n),'hinge':hinge}
    if extra: d.update(extra)
    M['sprites'].append(d)
add('fish_folded','pink fish','folded',{'type':'horizontal','y':fb['part-head'][1],
   'note':'part-head shown above y, part-tail shown below y (part-tail carries translate(0,%.1f) relative to the unfolded geometry). Same ink as unfolded: identical path data.'%fb['part-tail'][2]})
add('fish_unfolded','pink fish','unfolded',{'type':'horizontal','head_bottom_y':fb['part-head'][1],'tail_top_y':fb['part-tail'][0],
   'note':'Unfold = slide part-tail down by %.1f while part-seg-1..5 and part-fin-left/right appear in order head-to-tail between the two lines.'%(-fb['part-tail'][2]),
   'segment_order_top_to_bottom':['part-seg-1 (Mommy)','part-seg-2 (two hearts)','part-seg-3 (Elliot)','part-seg-4 (Mom, scribbled out)','part-seg-5 (I love U)']})
add('icecream_folded','ice cream','folded',{'type':'horizontal','y':icf['fold_y'],
   'note':'Fold edge between part-scoop-5 (red, above) and part-scoop-1 (teal strip, below). The folded form is a separate drawing on the outside of the flap (bigger eyes, taller cone), so its geometry is not shared with the unfolded form; cross-fade or flip the flap rather than morphing paths.'})
add('icecream_unfolded','ice cream','unfolded',{'type':'horizontal','top_y':U(388),'bottom_y':U(1053),
   'note':'Tower opens between the bottom of part-scoop-5 (red, top_y) and the visible teal strip of part-scoop-1 (bottom_y); part-scoop-4,3,2 and part-arms appear in between. Scoops numbered bottom (1, sleepy teal) to top (5, red cherry).'})
add('flowerpot_folded','red flowerpot monster','folded',{'type':'horizontal','y':pb['part-flower'][1],
   'note':'part-flower and the top of part-stem above y; part-pot below, translated by %.1f. Same ink as unfolded: identical path data.'%pb['part-pot'][2]})
add('flowerpot_unfolded','red flowerpot monster','unfolded',{'type':'horizontal','stem_top_y':pb['part-flower'][1],'stem_bottom_y':pb['part-pot'][0],
   'note':'Grow part-stem with scaleY anchored at stem_bottom_y (soil line); move part-flower up with the stem top. part-shoot and part-bulbs attach to the stem sides and should fade/scale in once the stem is long.'})
for n,v in dood.items():
    add(n,'flowerpot doodle','stand-alone',None,{'placement_in_flowerpot_unfolded':{'x':v[0],'y':v[1]},
        'note':'viewBox origin is already in flowerpot_unfolded coordinates: draw at (x,y) to sit where he drew it. For the folded pot, doodles below the fold shift by %.1f in y; the striped heart and smiley bulbs are hidden when folded.'%pb['part-pot'][2]})
json.dump(M,open(f'{A}/manifest_fish_icecream_flowerpot.json','w'),indent=1)
print(json.dumps([[s['file'],s['size'],s['part_ids']] for s in M['sprites']]))
