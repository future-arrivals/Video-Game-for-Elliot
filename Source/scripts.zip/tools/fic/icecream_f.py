"""Folded ice cream: drawn from IMG_3523 (its own drawing on the folded flap)."""
import json, math, numpy as np, cv2
from build import Sprite, write_pair, INK, autocrop, render, shift, OUT
from shapes import color_blobs
K='3523'; S=0.432
D=json.load(open('/home/claude/game/tools/fic/traces/icF.json')); T=D['strokes']
RED='#dc3f3d'; CHERRY='#cc3a36'; STALK='#a8492a'; CONE='#761e0c'; TEAL='#2a8f8b'; WHITE='#ffffff'
sp=Sprite(S, origin=(90,140), eps=1.2)
def st(part,ids,width=9,**kw):
    for i in ids: sp.stroke(part,T[i],width=width,**kw)
# outlines
st('scoop-5',[47,50,49]); sp.stroke('scoop-5',T[46][:8])   # right brow
st('scoop-5',[51])                                          # left brow
FOLD=[(266,719),(400,721),(560,723),(700,724),(758,723)]
sp.stroke('scoop-5',FOLD,width=6,steady=0)
st('scoop-1',[69,77,79])
CONE_TOP=[(287,756),(296,772),(317.7,765.5),(352.8,767.7),(374.7,774.3),(387.9,796.2),(414.2,785.3),(449.3,780.9),(475.6,791.8),(537,794.9),(556.8,783),(580.9,778.7),(607.2,769.9),(624.7,763.3),(668.6,774.3),(694.9,778.7),(707,776)]
sp.stroke('scoop-1',CONE_TOP)
st('cone',[78,70])
for part,seed,col in [('scoop-5',(500,600),RED),('scoop-1',(330,740),TEAL),('cone',(480,900),CONE)]:
    sp.seed_fill(part,seed,col,within={'scoop-5':(250,360,780,730),'scoop-1':(260,700,780,800),'cone':(260,740,770,1030)}[part])
# face
sp.dot('scoop-5',(390,579),0,rx=41,ry=54,rot=-6,n=14,seed=1)
sp.dot('scoop-5',(374,560),0,rx=15,ry=18,rot=15,n=10,color=WHITE,seed=2)
sp.dot('scoop-5',(670,553),0,rx=60,ry=78,rot=-12,n=16,seed=3)
sp.dot('scoop-5',(642,568),0,rx=27,ry=29,rot=-10,n=12,color=WHITE,seed=4)
st('scoop-5',[68,66],width=7); st('scoop-5',[67],width=6)
# teal strip: the bottom of a smile and a dark blob peeking under the flap
st('scoop-1',[72],width=7)
sp.fill('scoop-1',[(560,724),(622,724),(625,745),(615,760),(595,764),(575,755),(562,742)],INK,steady=0)
# cone waffle lines
st('cone',[96,99,107,102,108,91,109,113,111,103,114,112,98,101,100,89,97,92,86,82],width=6)
# action lines
st('fx',[61,65,83,95,115,117])
# cherries and stalk (no black outline)
for box,seed in [((110,330,320,560),11),((585,220,780,445),12)]:
    poly=color_blobs(K,box,'redfill',min_area=800,blur=3,keep=1)[0]
    (cx,cy),(w,h),ang=cv2.fitEllipse(np.array(poly,np.float32))
    r=(w+h)/4*0.97; sp.dot('cherries',(cx,cy),0,rx=r*1.04,ry=r*0.96,rot=ang+90,n=14,wob=0.035,color=CHERRY,seed=seed)
sp.fill('cherries',[(424,190),(452,178),(478,180),(500,166),(522,170),(540,182),(545,250),(540,360),(520,410),(430,410),(420,330),(420,250)],STALK,steady=0)
sp.stroke('cherries',[(425,262),(360,312),(296,364)],color=STALK,width=44*S,steady=0)
sp.stroke('cherries',[(536,190),(580,262),(625,350)],color=STALK,width=44*S,steady=0)
PARTS=[('part-fx',['fx']),('part-cherries',['cherries']),('part-cone',['cone']),('part-scoop-1',['scoop-1']),('part-scoop-5',['scoop-5'])]
if __name__=='__main__':
    v=autocrop(sp,PARTS,'/tmp/_t.svg'); shift(sp,-v[0]+1,-v[1]+1)
    v=autocrop(sp,PARTS,f'{OUT}/svg/icecream_folded.svg',title='Ice cream (folded)')
    v=(0,0,v[0]+v[2],v[1]+v[3]); sp.svg(PARTS,f'{OUT}/svg/icecream_folded.svg',viewbox=v,title='Ice cream (folded)')
    render(f'{OUT}/svg/icecream_folded.svg',f'{OUT}/png/icecream_folded.png'); print(v)
    json.dump({'viewBox':v,'fold_y':(721-sp.o[1])*S},open('/home/claude/game/tools/fic/icf_res.json','w'))
