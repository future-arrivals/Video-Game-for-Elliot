"""Extract centre-lines of marker strokes from a photo region.
usage: trace.py KEY x0 y0 x1 y1 OUTPREFIX [--mode black|COLOR] [--thick R]
Coordinates are in the upright *_small.jpg pixel space (1050 px wide)."""
import sys, json, argparse
import numpy as np, cv2
from PIL import Image, ImageDraw
from skimage.morphology import skeletonize
from skan import Skeleton
import colorspec

def load(key,x0,y0,x1,y1,f):
    full=Image.open(f'/home/claude/game/tools/fic/ref/{key}_full.png')
    s=full.width/1050
    c=full.crop((int(x0*s),int(y0*s),int(x1*s),int(y1*s)))
    c=c.resize((int((x1-x0)*f),int((y1-y0)*f)),Image.LANCZOS)
    return np.asarray(c).astype(np.float32)

def tangent(co,k=8):
    # direction pointing *out of* the path at its start
    p0=co[0]; i=min(len(co)-1,k); v=p0-co[i]; n=np.hypot(*v)
    return v/n if n>0 else v

def merge_paths(paths, maxang=55):
    """paths: list of (N,2) arrays (x,y). Chain paths through shared endpoints
    choosing the straightest continuation."""
    ends=[]  # (path, which_end, point)
    for i,p in enumerate(paths):
        ends.append((i,0,p[0])); ends.append((i,1,p[-1]))
    pts=np.array([e[2] for e in ends])
    # group endpoints within 3.5px
    grp=-np.ones(len(ends),int); g=0
    for i in range(len(ends)):
        if grp[i]>=0: continue
        stack=[i]; grp[i]=g
        while stack:
            j=stack.pop()
            d=np.hypot(*(pts-pts[j]).T)
            for k in np.where((d<3.5)&(grp<0))[0]:
                grp[k]=g; stack.append(k)
        g+=1
    link={}  # (path,end)->(path,end)
    for gi in range(g):
        mem=[i for i in range(len(ends)) if grp[i]==gi]
        if len(mem)<2: continue
        dirs={}
        for m in mem:
            pi,e,_=ends[m]; co=paths[pi] if e==0 else paths[pi][::-1]
            dirs[m]=tangent(co)
        cand=[]
        for a in range(len(mem)):
            for b in range(a+1,len(mem)):
                ma,mb=mem[a],mem[b]
                if ends[ma][0]==ends[mb][0]: continue
                dot=float(np.dot(dirs[ma],dirs[mb]))  # -1 is straight
                ang=np.degrees(np.arccos(np.clip(-dot,-1,1)))
                if ang<maxang: cand.append((ang,ma,mb))
        cand.sort(); used=set()
        for ang,ma,mb in cand:
            if ma in used or mb in used: continue
            used|={ma,mb}
            link[(ends[ma][0],ends[ma][1])]=(ends[mb][0],ends[mb][1])
            link[(ends[mb][0],ends[mb][1])]=(ends[ma][0],ends[ma][1])
    seen=set(); out=[]
    def walk(pi,e):
        # start at path pi, entering from end e (so we traverse from e to other end)
        chain=[]
        while True:
            seen.add(pi)
            co=paths[pi] if e==0 else paths[pi][::-1]
            chain.extend(co.tolist() if not chain else co[1:].tolist())
            other=(pi,1-e)
            if other not in link: break
            npi,ne=link[other]
            if npi in seen: break
            pi,e=npi,ne
        return chain
    for i in range(len(paths)):
        if i in seen: continue
        # find a chain start: go backwards as far as possible
        pi,e=i,0; visited={i}
        while (pi,e) in link:
            npi,ne=link[(pi,e)]
            if npi in visited: break
            visited.add(npi); pi,e=npi,1-ne
        out.append(walk(pi,e))
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('key'); ap.add_argument('x0',type=float); ap.add_argument('y0',type=float)
    ap.add_argument('x1',type=float); ap.add_argument('y1',type=float); ap.add_argument('out')
    ap.add_argument('--mode',default='black'); ap.add_argument('--thick',type=float,default=7.5)
    ap.add_argument('--f',type=float,default=1.5); ap.add_argument('--minlen',type=float,default=9)
    ap.add_argument('--eps',type=float,default=1.0); ap.add_argument('--minblob',type=float,default=150)
    ap.add_argument('--close',type=int,default=3)
    a=ap.parse_args()
    img=colorspec.white_balance(load(a.key,a.x0,a.y0,a.x1,a.y1,a.f))
    mask=colorspec.mask2(img,a.mode)
    if a.close>1: mask=cv2.morphologyEx(mask.astype(np.uint8),cv2.MORPH_CLOSE,np.ones((a.close,a.close),np.uint8))
    mask=cv2.morphologyEx(mask.astype(np.uint8),cv2.MORPH_OPEN,np.ones((2,2),np.uint8))
    n,lab,st,_=cv2.connectedComponentsWithStats(mask)
    for i in range(1,n):
        if st[i,4]<30: mask[lab==i]=0
    dist=cv2.distanceTransform(mask,cv2.DIST_L2,5)
    core=(dist>a.thick).astype(np.uint8)
    r=int(a.thick)
    thick=cv2.dilate(core,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*r+1,)*2))&mask
    blobs=[]
    cs,_=cv2.findContours(thick,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    keep=np.zeros_like(thick)
    for c in cs:
        if cv2.contourArea(c)<a.minblob: continue
        cv2.drawContours(keep,[c],-1,1,-1)
        c2=cv2.approxPolyDP(c,0.8,True)[:,0,:].astype(float)
        blobs.append([[round(float(a.x0+p[0]/a.f),1),round(float(a.y0+p[1]/a.f),1)] for p in c2])
    thin=mask.copy(); thin[cv2.erode(keep,np.ones((3,3),np.uint8))>0]=0
    sk=skeletonize(thin>0)
    paths=[]
    if sk.sum()>0:
        S=Skeleton(sk); deg=S.degrees
        for i in range(S.n_paths):
            idx=S.path(i); co=S.path_coordinates(i)[:,::-1].astype(float)
            ln=np.sum(np.hypot(*np.diff(co,axis=0).T)) if len(co)>1 else 0
            e=[deg[idx[0]],deg[idx[-1]]]
            if ln<a.minlen and (1 in e): continue
            if ln<1.5: continue
            paths.append(co)
    chains=merge_paths(paths)
    strokes=[]
    for ch in chains:
        co=np.array(ch,np.float32)
        if len(co)>=2:
            ln=np.sum(np.hypot(*np.diff(co,axis=0).T))
            if ln<a.minlen: continue
        closed = len(co)>8 and np.hypot(*(co[0]-co[-1]))<3
        pts=cv2.approxPolyDP(co.reshape(-1,1,2),a.eps,False)[:,0,:]
        strokes.append([[round(float(a.x0+p[0]/a.f),1),round(float(a.y0+p[1]/a.f),1)] for p in pts])
    json.dump({'strokes':strokes,'blobs':blobs,'region':[a.x0,a.y0,a.x1,a.y1]},open(a.out+'.json','w'))
    f2=1400/max(a.x1-a.x0,a.y1-a.y0)
    base=Image.fromarray(np.clip(img,0,255).astype(np.uint8)).resize((int((a.x1-a.x0)*f2),int((a.y1-a.y0)*f2)))
    base=Image.blend(base,Image.new('RGB',base.size,'white'),0.65)
    d=ImageDraw.Draw(base); rng=np.random.RandomState(1)
    for b in blobs: d.polygon([((x-a.x0)*f2,(y-a.y0)*f2) for x,y in b],fill=(150,150,150))
    for i,s in enumerate(strokes):
        col=tuple(int(c) for c in rng.randint(0,190,3))
        P=[((x-a.x0)*f2,(y-a.y0)*f2) for x,y in s]
        d.line(P,fill=col,width=3)
        m=P[len(P)//2]; d.text((m[0]+3,m[1]-6),str(i),fill=col)
    base.save(a.out+'_dbg.png')
    print(len(strokes),'strokes',len(blobs),'blobs')
