import sys, numpy as np, cv2
from trace import load
import colorspec
from skimage.morphology import skeletonize
for k,box in [('3521',(180,500,780,1060)),('3522',(200,80,880,1300)),('3523',(150,100,950,1300)),('3524',(150,20,900,1350)),('3528',(250,380,880,1040)),('3529',(200,30,900,1340))]:
    img=colorspec.white_balance(load(k,*box,f=2.88 if k<'3525' else 4.08))
    m=colorspec.mask(img,'black').astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    dt=cv2.distanceTransform(m,cv2.DIST_L2,5)
    sk=skeletonize(m>0)
    w=2*dt[sk]; w=w[(w>3)&(w<60)]
    print(k,'median full-res line width px',np.median(w).round(1),'-> in small px',(np.median(w)/(2.88 if k<'3525' else 4.08)).round(2))
