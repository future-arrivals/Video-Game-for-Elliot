import sys
from PIL import Image
import numpy as np
k=sys.argv[1]
full=np.array(Image.open(f'/home/claude/game/tools/fic/ref/{k}_full.png'))
s=full.shape[1]/1050
for a in sys.argv[2:]:
    name,x,y=a.split(':'); x=int(float(x)*s); y=int(float(y)*s); r=int(4*s)
    p=full[y-r:y+r,x-r:x+r].reshape(-1,3)
    med=np.median(p,0).astype(int)
    import colorsys
    h,sat,v=colorsys.rgb_to_hsv(*(med/255))
    print(f'{name:12s} {tuple(med)} #{med[0]:02x}{med[1]:02x}{med[2]:02x} hsv=({h*360:.0f},{sat:.2f},{v:.2f})')
