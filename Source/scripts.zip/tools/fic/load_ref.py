import sys, glob
import pillow_heif; pillow_heif.register_heif_opener()
from PIL import Image, ImageOps
import os
os.makedirs('/home/claude/game/tools/fic/ref', exist_ok=True)
# rotation to upright (degrees CCW, PIL rotate convention)
ROT = {'3521':90,'3522':90,'3523':90,'3524':0,'3528':90,'3529':90}
for k,r in ROT.items():
    f = glob.glob(f'/mnt/user-data/uploads/*IMG_{k}.HEIC')[0]
    im = ImageOps.exif_transpose(Image.open(f)).convert('RGB')
    print(k, im.size)
    if r: im = im.rotate(r, expand=True)
    im.save(f'/home/claude/game/tools/fic/ref/{k}_full.png')
    s = im.copy(); s.thumbnail((1400,1400)); s.save(f'/home/claude/game/tools/fic/ref/{k}_small.jpg', quality=90)
    print(k, im.size)
