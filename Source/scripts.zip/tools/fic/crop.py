# usage: crop.py key x0 y0 x1 y1 out [grid]  (coords in _small.jpg space)
import sys, math
from PIL import Image, ImageDraw
Image.MAX_IMAGE_PIXELS=None
k=sys.argv[1]; x0,y0,x1,y1=map(float,sys.argv[2:6]); out=sys.argv[6]
grid = len(sys.argv)>7
full=Image.open(f'/home/claude/game/tools/fic/ref/{k}_full.png')
s=full.width/1050
c=full.crop((int(x0*s),int(y0*s),int(x1*s),int(y1*s)))
c.thumbnail((1400,1400))
if grid:
    d=ImageDraw.Draw(c); sx=c.width/(x1-x0)
    step=50 if (x1-x0)>300 else 20
    gx=math.ceil(x0/step)*step
    while gx<x1:
        X=(gx-x0)*sx; d.line([(X,0),(X,c.height)],fill=(0,160,255),width=1); d.text((X+2,2),str(int(gx)),fill=(0,0,255),font_size=16); gx+=step
    gy=math.ceil(y0/step)*step
    while gy<y1:
        Y=(gy-y0)*sx; d.line([(0,Y),(c.width,Y)],fill=(0,160,255),width=1); d.text((2,Y+2),str(int(gy)),fill=(0,0,255),font_size=16); gy+=step
c.save(out)
