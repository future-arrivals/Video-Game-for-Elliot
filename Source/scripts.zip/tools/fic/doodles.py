"""Stand-alone doodles around the flowerpot, at the flowerpot's scale and in its coordinate system."""
import json, math, numpy as np
from build import Sprite, autocrop, render, OUT, INK
R=json.load(open('/home/claude/game/tools/fic/pot_res.json'))
S=R['_S']; O=tuple(R['_origin'])
LG=json.load(open('/home/claude/game/tools/fic/traces/potLG.json'))['strokes']
PK=json.load(open('/home/claude/game/tools/fic/traces/potPink.json'))['strokes']
LTG='#8fbf3c'; PINKD='#f07cc3'
def mk(): return Sprite(S, origin=O, eps=1.0)
out={}
def write(name, sp, parts, title):
    v=autocrop(sp, parts, f'{OUT}/svg/{name}.svg', title=title)
    render(f'{OUT}/svg/{name}.svg', f'{OUT}/png/{name}.png')
    out[name]=v; print(name, v)
# pink heart with a frowny face, on its string
sp=mk()
sp.stroke('d',[(291,168),(285,155),(272,141),(256,138),(250,150),(249,175),(252,195),(265,215),(284,235),(296,247),(300,232),(308,205),(316,180),(320,155),(318,131),(310,121),(300,128),(293,145),(291,168)],color=PINKD,width=7,closed=True,steady=0,corner=55)
sp.stroke('d',[(258,141),(272,152),(286,166)],color=PINKD,width=4.5,steady=0)
sp.stroke('d',[(263,155),(265,163)],color=PINKD,width=4.5,steady=0); sp.stroke('d',[(299,151),(306,147)],color=PINKD,width=4.5,steady=0)
sp.stroke('d',[(281,201),(283,186),(292,180),(300,186),(305,200)],color=PINKD,width=4.5,steady=0)
sp.stroke('d',[p for p in PK[10]],color=PINKD,width=7,steady=0.8)
write('doodle_pink_heart',sp,[('doodle',['d'])],'Pink heart doodle')
# light-green square balloon with a face (left of pot)
sp=mk()
sp.stroke('d',[(120,1035),(128,1022),(150,1035),(185,1060),(212,1085),(218,1102),(205,1125),(185,1148),(162,1165),(135,1170),(118,1160),(112,1140),(96,1118),(100,1095),(112,1060)],color=LTG,width=7,closed=True,steady=0,corner=70)
sp.stroke('d',[(133,1048),(146,1047),(153,1062),(150,1078),(138,1082),(128,1072),(128,1056)],color=LTG,width=6,closed=True,steady=0)
sp.stroke('d',[(168,1088),(185,1082),(204,1092),(208,1108),(196,1120),(178,1118),(168,1104)],color=LTG,width=6,closed=True,steady=0)
sp.stroke('d',[(189,1101),(191,1103)],color=LTG,width=7,steady=0)
sp.stroke('d',[(148,1112),(140,1128),(150,1142),(168,1140),(176,1150),(170,1162)],color=LTG,width=6,steady=0)
sp.stroke('d',[(165,1165),(178,1190),(200,1215),(232,1245),(262,1265),(290,1270),(304,1265)],color=LTG,width=7,steady=0)
sp.stroke('d',[(188,1200),(203,1192)],color=LTG,width=7,steady=0)
write('doodle_green_square',sp,[('doodle',['d'])],'Light-green square balloon doodle')
# light-green round balloon (right of pot)
sp=mk()
for i in (65,68): sp.stroke('d',LG[i],color=LTG,width=7,steady=0.8)
write('doodle_green_circle',sp,[('doodle',['d'])],'Light-green round balloon doodle')
# light-green striped heart with a face (right of stem)
sp=mk()
for i in (20,21,23,24,30,31,32,34,35,36,37,38,41,44,45,46,48,33): sp.stroke('d',LG[i],color=LTG,width=7,steady=0.8)
write('doodle_green_heart',sp,[('doodle',['d'])],'Light-green striped heart doodle')
# two bare light-green sprigs beside the soil
sp=mk()
for i in (47,40): sp.stroke('d',LG[i],color=LTG,width=7,steady=0.8)
write('doodle_green_sprigs',sp,[('doodle',['d'])],'Light-green sprigs')
# smiley bulbs: heads only, from the flowerpot's own geometry
import flowerpot as FP
from build import shift
def boxclip(pts,box):
    x0,y0,x1,y1=box; runs=[]; cur=[]
    dense=[pts[0]]
    for a,b in zip(pts,pts[1:]):
        n=max(1,int(math.dist(a,b)/1.5))
        for t in range(1,n+1): dense.append((a[0]+(b[0]-a[0])*t/n,a[1]+(b[1]-a[1])*t/n))
    for p in dense:
        if x0<=p[0]<=x1 and y0<=p[1]<=y1: cur.append(p)
        else:
            if len(cur)>1: runs.append(cur)
            cur=[]
    if len(cur)>1: runs.append(cur)
    return runs
for name,box in [('doodle_bulb_small',(203,720,256,792)),('doodle_bulb_big',(212,808,297,922))]:
    sp=mk()
    U=lambda p:((p[0]-O[0])*S,(p[1]-O[1])*S)   # unit box in flowerpot coords
    ub=(U(box[:2])+U(box[2:]))
    for e in FP.sp.els:
        if e['part']!='bulbs': continue
        # FP.sp is in pre-shift units; convert to final flowerpot units
        so=FP.sp.o; pts=[((x/S+so[0]-O[0])*S,(y/S+so[1]-O[1])*S) for x,y in e['pts']]
        if e['kind']=='fill':
            c=np.mean(pts,0)
            if ub[0]<=c[0]<=ub[2] and ub[1]<=c[1]<=ub[3]: sp.els.append(dict(e,pts=pts))
        else:
            if e['closed']: pts=pts+[pts[0]]
            for r in boxclip(pts,ub): sp.els.append(dict(e,pts=r,closed=False))
    write(name,sp,[('doodle',['bulbs'])],'Smiley bulb')
json.dump(out,open('/home/claude/game/tools/fic/doodle_res.json','w'))
