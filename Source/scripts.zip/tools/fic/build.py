"""Tiny sprite builder: source-photo coordinates -> clean hand-style SVG."""
import json, math, subprocess, os
import numpy as np, cv2

INK='#1a1a1a'

def rdp(pts, eps):
    if len(pts)<3: return pts
    a=np.array(pts,float)
    out=cv2.approxPolyDP(a.astype(np.float32).reshape(-1,1,2),eps,False)[:,0,:]
    return out.tolist()

def chaikin(pts, it=1, closed=False):
    p=np.array(pts,float)
    for _ in range(it):
        if len(p)<3: break
        q=[]
        n=len(p)
        rng=range(n) if closed else range(n-1)
        if not closed: q.append(p[0])
        for i in rng:
            a=p[i]; b=p[(i+1)%n]
            q.append(0.75*a+0.25*b); q.append(0.25*a+0.75*b)
        if not closed: q.append(p[-1])
        p=np.array(q)
    return p.tolist()

def fmt(v): 
    s=f'{v:.1f}'
    return s[:-2] if s.endswith('.0') else s

def path_d(pts, closed=False, corner=65):
    p=[tuple(map(float,x)) for x in pts]
    if closed and len(p)>2 and math.dist(p[0],p[-1])<0.5: p=p[:-1]
    n=len(p)
    if n==1: return f'M{fmt(p[0][0])} {fmt(p[0][1])}h0'
    if n==2: return f'M{fmt(p[0][0])} {fmt(p[0][1])}L{fmt(p[1][0])} {fmt(p[1][1])}'
    def P(i):
        if closed: return p[i%n]
        return p[max(0,min(n-1,i))]
    def is_corner(i):
        if not closed and (i<=0 or i>=n-1): return True
        a=P(i-1); b=P(i); c=P(i+1)
        v1=(b[0]-a[0],b[1]-a[1]); v2=(c[0]-b[0],c[1]-b[1])
        l1=math.hypot(*v1); l2=math.hypot(*v2)
        if l1==0 or l2==0: return True
        cos=(v1[0]*v2[0]+v1[1]*v2[1])/(l1*l2)
        return math.degrees(math.acos(max(-1,min(1,cos))))>corner
    corners=[is_corner(i) for i in range(n)]
    d=[f'M{fmt(p[0][0])} {fmt(p[0][1])}']
    segs=n if closed else n-1
    for i in range(segs):
        a=P(i); b=P(i+1)
        if corners[i%n]: c1=a
        else:
            pa=P(i-1); c1=(a[0]+(b[0]-pa[0])/6, a[1]+(b[1]-pa[1])/6)
        if corners[(i+1)%n] if closed else corners[min(i+1,n-1)]: c2=b
        else:
            pc=P(i+2); c2=(b[0]-(pc[0]-a[0])/6, b[1]-(pc[1]-a[1])/6)
        d.append(f'C{fmt(c1[0])} {fmt(c1[1])} {fmt(c2[0])} {fmt(c2[1])} {fmt(b[0])} {fmt(b[1])}')
    if closed: d.append('Z')
    return ''.join(d)

def clip_poly_y(pts, y0, y1):
    """Sutherland-Hodgman clip of polygon to y0<=y<=y1."""
    def clip(poly, inside, inter):
        out=[]
        if not poly: return out
        prev=poly[-1]
        for cur in poly:
            if inside(cur):
                if not inside(prev): out.append(inter(prev,cur))
                out.append(cur)
            elif inside(prev): out.append(inter(prev,cur))
            prev=cur
        return out
    def iy(y):
        return lambda a,b: (a[0]+(b[0]-a[0])*(y-a[1])/(b[1]-a[1]), y)
    p=clip(list(map(tuple,pts)), lambda q:q[1]>=y0, iy(y0))
    p=clip(p, lambda q:q[1]<=y1, iy(y1))
    return p

def clip_line_y(pts, y0, y1):
    """Split polyline into pieces inside y0<=y<=y1."""
    out=[]; cur=[]
    P=[tuple(x) for x in pts]
    ins=lambda q: y0<=q[1]<=y1
    for i,q in enumerate(P):
        if i==0:
            if ins(q): cur.append(q)
            continue
        a=P[i-1]
        if ins(a) and ins(q): cur.append(q); continue
        # crossing(s)
        for y in (y0,y1):
            if (a[1]-y)*(q[1]-y)<0:
                t=(y-a[1])/(q[1]-a[1]); x=a[0]+(q[0]-a[0])*t
                if ins(a): cur.append((x,y)); out.append(cur); cur=[]
                else: cur=[(x,y)]
        if ins(q) and not cur: cur=[q]
        elif ins(q) and cur and cur[-1]!=q: cur.append(q)
    if len(cur)>=2: out.append(cur)
    return [c for c in out if len(c)>=2]

class Sprite:
    def __init__(self, scale, origin=(0,0), eps=1.0, smooth=1):
        self.s=scale; self.o=origin; self.els=[]; self.eps=eps; self.smooth=smooth
    def U(self, pts):
        return [((x-self.o[0])*self.s,(y-self.o[1])*self.s) for x,y in pts]
    # ---- element adders (source coords) ----
    def stroke(self, part, pts, color=INK, width=9, closed=False, steady=None, src=True, cap='round', corner=65):
        u=self.U(pts) if src else [tuple(p) for p in pts]
        e=self.eps if steady is None else steady
        if e>0: u=rdp(u+([u[0]] if closed else []), e)
        if closed and len(u)>2 and math.dist(u[0],u[-1])<0.5: u=u[:-1]
        self.els.append(dict(part=part,kind='stroke',pts=u,color=color,width=width,closed=closed,corner=corner))
    def fill(self, part, pts, color, src=True, steady=0.6, corner=65):
        u=self.U(pts) if src else [tuple(p) for p in pts]
        if steady: u=rdp(u+[u[0]],steady)[:-1]
        self.els.append(dict(part=part,kind='fill',pts=u,color=color,closed=True,corner=corner))
    def dot(self, part, c, r, color=INK, src=True, n=10, wob=0.04, rx=None, ry=None, rot=0, seed=0):
        cx,cy=self.U([c])[0] if src else c
        rx=(rx if rx is not None else r)*(self.s if src else 1); ry=(ry if ry is not None else r)*(self.s if src else 1)
        rnd=np.random.RandomState(seed)
        pts=[]
        for i in range(n):
            t=2*math.pi*i/n; k=1+wob*rnd.uniform(-1,1)
            x=rx*k*math.cos(t); y=ry*k*math.sin(t)
            cr=math.cos(math.radians(rot)); sr=math.sin(math.radians(rot))
            pts.append((cx+x*cr-y*sr, cy+x*sr+y*cr))
        self.els.append(dict(part=part,kind='fill',pts=pts,color=color,closed=True,corner=179))
    # ---- seed fill from current strokes ----
    def barrier(self, R, pad, extra=(), only_parts=None):
        allp=[p for e in self.els for p in e['pts']]+[p for ex in extra for p in ex]
        xs=[p[0] for p in allp]; ys=[p[1] for p in allp]
        x0=min(xs)-pad; y0=min(ys)-pad; x1=max(xs)+pad; y1=max(ys)+pad
        W=int((x1-x0)*R)+1; H=int((y1-y0)*R)+1
        img=np.zeros((H,W),np.uint8)
        for e in self.els:
            if e['kind']!='stroke': continue
            if only_parts and e['part'] not in only_parts: continue
            P=np.array([((x-x0)*R,(y-y0)*R) for x,y in e['pts']],np.int32)
            cv2.polylines(img,[P],e['closed'],255,max(1,int(e['width']*R*1.0)),lineType=cv2.LINE_8)
        for ex in extra:
            P=np.array([((x-x0)*R,(y-y0)*R) for x,y in self.U(ex)],np.int32)
            cv2.polylines(img,[P],False,255,max(1,int(7*R)))
        return img,x0,y0
    def seed_fill(self, part, seed, color, extra=(), R=3, grow=None, only_parts=None, maxfrac=0.6, within=None):
        img,x0,y0=self.barrier(R,20,extra,only_parts)
        sx,sy=self.U([seed])[0]
        X=int((sx-x0)*R); Y=int((sy-y0)*R)
        if img[Y,X]:
            free=np.argwhere(img[max(0,Y-25):Y+26,max(0,X-25):X+26]==0)
            if len(free)==0: raise RuntimeError(f'seed {seed} on a line ({part})')
            d=np.hypot(free[:,0]-min(25,Y),free[:,1]-min(25,X)); j=free[np.argmin(d)]
            Y=max(0,Y-25)+j[0]; X=max(0,X-25)+j[1]
        m=np.zeros((img.shape[0]+2,img.shape[1]+2),np.uint8)
        cv2.floodFill(img.copy(),m,(X,Y),128,flags=4|(255<<8)|cv2.FLOODFILL_MASK_ONLY)
        reg=m[1:-1,1:-1]
        frac=reg.mean()/255
        if reg[0].any() or reg[-1].any() or reg[:,0].any() or reg[:,-1].any() or frac>maxfrac:
            raise RuntimeError(f'fill leaked: {part} seed {seed}')
        if within:
            ys,xs=np.where(reg>0)
            bx0=xs.min()/R+x0; bx1=xs.max()/R+x0; by0=ys.min()/R+y0; by1=ys.max()/R+y0
            w=self.U([within[:2],within[2:]])
            if bx0<w[0][0] or by0<w[0][1] or bx1>w[1][0] or by1>w[1][1]:
                raise RuntimeError(f'fill out of bounds: {part} seed {seed} bbox src {[round(v/self.s+o) for v,o in ((bx0,self.o[0]),(by0,self.o[1]),(bx1,self.o[0]),(by1,self.o[1]))]}')
        g=int((grow if grow is not None else 3.6)*R)
        reg=cv2.dilate(reg,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*g+1,)*2))
        reg=cv2.morphologyEx(reg,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)))
        cs,_=cv2.findContours(reg,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
        c=max(cs,key=cv2.contourArea)[:,0,:].astype(float)
        pts=[(x/R+x0,y/R+y0) for x,y in c]
        pts=rdp(pts+[pts[0]],0.7)[:-1]
        self.els.append(dict(part=part,kind='fill',pts=pts,color=color,closed=True,corner=80))
        return pts
    # ---- output ----
    def svg(self, parts, path=None, bands=None, extra_strokes=None, viewbox=None, title=''):
        """parts: ordered list of (part_id, [element-part-names]) or part names.
        bands: optional {part_id: (y0,y1,dy)} in unit coords to clip+translate for folded forms."""
        groups=[]
        for spec in parts:
            pid,names=(spec if isinstance(spec,tuple) else (spec,[spec]))
            band=bands.get(pid) if bands else None
            body=[]
            for nm,kind in [(nm,k) for nm in names for k in ('fill','stroke')]:
                els=[e for e in self.els if e['part']==nm]
                cur=None; buf=[]
                for e in els:
                    if e['kind']!=kind: continue
                    pieces=[e['pts']]
                    if band:
                        y0,y1,_=band
                        if kind=='fill' or e['closed']:
                            pc=clip_poly_y(e['pts'],y0,y1); pieces=[pc] if len(pc)>=3 else []
                            if kind=='stroke' and pieces:
                                # stroke of a closed outline cut by the fold: keep only original arcs
                                pieces=clip_line_y(e['pts']+[e['pts'][0]],y0,y1)
                                kind_closed=False
                        else:
                            pieces=clip_line_y(e['pts'],y0,y1)
                    for pc in pieces:
                        closed=e['closed'] and (not band or kind=='fill')
                        d=path_d(pc,closed,e.get('corner',65))
                        if kind=='fill': body.append(f'<path d="{d}" fill="{e["color"]}" stroke="none"/>')
                        else:
                            attrs=''
                            if e['color']!=INK: attrs+=f' stroke="{e["color"]}"'
                            if e['width']!=9: attrs+=f' stroke-width="{fmt(e["width"])}"'
                            body.append(f'<path d="{d}"{attrs}/>')

            tr=f' transform="translate(0 {fmt(band[2])})"' if band and band[2] else ''
            groups.append(f'<g id="{pid}"{tr}>'+''.join(body)+'</g>')
        inner=''.join(groups)
        head='<g fill="none" stroke="#1a1a1a" stroke-width="9" stroke-linecap="round" stroke-linejoin="round">'
        vb=viewbox or (0,0,2000,2000)
        doc=(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{" ".join(fmt(v) for v in vb)}" '
             f'width="{fmt(vb[2])}" height="{fmt(vb[3])}">' + (f'<title>{title}</title>' if title else '') + head+inner+'</g></svg>')
        if path: open(path,'w').write(doc)
        return doc

def render(svg_path, png_path, long_side=1024, bg=None):
    import re
    s=open(svg_path).read()
    vb=[float(v) for v in re.search(r'viewBox="([^"]+)"',s).group(1).split()]
    w,h=vb[2],vb[3]; k=long_side/max(w,h)
    args=['rsvg-convert','-w',str(round(w*k)),'-h',str(round(h*k))]
    if bg: args+=['-b',bg]
    subprocess.run(args+['-o',png_path,svg_path],check=True)

def autocrop(sprite, parts, path, bands=None, pad=12, title=''):
    """Write svg with a viewBox tight to the art (+pad)."""
    import tempfile
    from PIL import Image
    big=(-500,-500,3000,3000)
    tmp=tempfile.mktemp(suffix='.svg'); sprite.svg(parts,tmp,bands,viewbox=big)
    png=tmp+'.png'
    subprocess.run(['rsvg-convert','-w','3500','-h','3500','-o',png,tmp],check=True)
    a=np.asarray(Image.open(png))[...,3]
    ys,xs=np.where(a>8)
    k=3500/big[2]
    x0=big[0]+xs.min()/k; y0=big[1]+ys.min()/k; x1=big[0]+(xs.max()+1)/k; y1=big[1]+(ys.max()+1)/k
    vb=(math.floor(x0-pad),math.floor(y0-pad),math.ceil(x1-x0+2*pad),math.ceil(y1-y0+2*pad))
    sprite.svg(parts,path,bands,viewbox=vb,title=title)
    os.remove(tmp); os.remove(png)
    return vb

def shift(sprite, dx, dy):
    for e in sprite.els:
        e['pts']=[(x+dx,y+dy) for x,y in e['pts']]
    sprite.o=(sprite.o[0]-dx/sprite.s, sprite.o[1]-dy/sprite.s)

OUT='/home/claude/game/assets'
def write_pair(sp, parts_unf, name, folded_parts=None, bands=None, title=''):
    """Write <name>_unfolded.svg (viewBox origin 0,0) and optional <name>_folded.svg; returns viewBoxes."""
    vb=autocrop(sp, parts_unf, '/tmp/_t.svg')
    shift(sp, -vb[0]+1, -vb[1]+1)
    res={}
    fn=f'{name}_unfolded' if folded_parts else name
    v=autocrop(sp, parts_unf, f'{OUT}/svg/{fn}.svg', title=title)
    v=(0,0,v[0]+v[2],v[1]+v[3]); sp.svg(parts_unf, f'{OUT}/svg/{fn}.svg', viewbox=v, title=title); res[fn]=v
    render(f'{OUT}/svg/{fn}.svg', f'{OUT}/png/{fn}.png')
    if folded_parts:
        dy0=-vb[1]+1
        ub={k:(v[0]+dy0 if v[0]>-1e8 else v[0], v[1]+dy0 if v[1]<1e8 else v[1], v[2]) for k,v in bands.items()}
        res[f'{name}_folded']=autocrop(sp, folded_parts, f'{OUT}/svg/{name}_folded.svg', bands=ub, title=title+' (folded)')
        render(f'{OUT}/svg/{name}_folded.svg', f'{OUT}/png/{name}_folded.png')
        res['_bands']=ub
    return res

def poly_and(A, B, R=3, op='and'):
    """Raster boolean of two unit-space polygons; returns largest resulting polygon list."""
    allp=list(A)+list(B); xs=[p[0] for p in allp]; ys=[p[1] for p in allp]
    x0=min(xs)-5; y0=min(ys)-5; W=int((max(xs)-x0+5)*R); H=int((max(ys)-y0+5)*R)
    def ras(P):
        m=np.zeros((H,W),np.uint8); cv2.fillPoly(m,[np.array([((x-x0)*R,(y-y0)*R) for x,y in P],np.int32)],255); return m
    a,b=ras(A),ras(B)
    m={'and':a&b,'sub':a&~b,'or':a|b}[op]
    cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    out=[]
    for c in sorted(cs,key=cv2.contourArea,reverse=True):
        if cv2.contourArea(c)<4*R*R: continue
        pts=[(x/R+x0,y/R+y0) for x,y in c[:,0,:]]
        out.append(rdp(pts+[pts[0]],0.6)[:-1])
    return out

def enclosed_fill(sp, part, color, only_parts, box=None, R=3, grow=2.5, min_area=30):
    """Fill every region fully enclosed by the given parts' strokes (like painting all closed shapes)."""
    img,x0,y0=sp.barrier(R,20,(),only_parts)
    m=np.zeros((img.shape[0]+2,img.shape[1]+2),np.uint8)
    cv2.floodFill(img.copy(),m,(0,0),128,flags=4|(255<<8)|cv2.FLOODFILL_MASK_ONLY)
    outside=m[1:-1,1:-1]>0
    enc=((~outside)&(img==0)).astype(np.uint8)*255
    if box is not None:
        (bx0,by0),(bx1,by1)=sp.U([box[:2],box[2:]])
        lim=np.zeros_like(enc); cv2.rectangle(lim,(int((bx0-x0)*R),int((by0-y0)*R)),(int((bx1-x0)*R),int((by1-y0)*R)),255,-1); enc&=lim
    g=int(grow*R); enc=cv2.dilate(enc,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*g+1,)*2))
    cs,_=cv2.findContours(enc,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    n=0
    for c in cs:
        if cv2.contourArea(c)<min_area*R*R: continue
        pts=[(x/R+x0,y/R+y0) for x,y in c[:,0,:]]
        pts=rdp(pts+[pts[0]],0.7)[:-1]
        sp.els.append(dict(part=part,kind='fill',pts=pts,color=color,closed=True,corner=80)); n+=1
    return n
