# wbsample.py KEY mode x0 y0 x1 y1 : median white-balanced colour of mask pixels in region
import sys, numpy as np
from trace import load
import colorspec
k,mode=sys.argv[1],sys.argv[2]; x0,y0,x1,y1=map(float,sys.argv[3:7])
# white balance against a bigger surrounding window
img=colorspec.white_balance(load(k,max(0,x0-150),max(0,y0-150),x1+150,y1+150,1.0))
ox=int(min(150,x0)); oy=int(min(150,y0))
sub=img[oy:oy+int(y1-y0), ox:ox+int(x1-x0)]
m=colorspec.mask2(sub,mode).astype(bool) if mode!='all' else np.ones(sub.shape[:2],bool)
p=sub[m]
for q in (50,25):
    med=np.percentile(p,q,axis=0) if q!=50 else np.median(p,0)
    print(mode,q,'#%02x%02x%02x'%tuple(int(v) for v in np.clip(med,0,255)), m.mean().round(2))
