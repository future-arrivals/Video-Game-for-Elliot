import sys, subprocess
sys.path.insert(0,'/home/claude/game/tools/fic')
import compare
from PIL import Image, ImageDraw
compare.load_rows()
def sheet(out, bg=(255,255,255)):
    chars=['fish_folded','fish_unfolded','icecream_folded','icecream_unfolded','flowerpot_folded','flowerpot_unfolded']
    doods=['doodle_pink_heart','doodle_green_square','doodle_green_circle','doodle_green_heart','doodle_green_sprigs','doodle_bulb_small','doodle_bulb_big']
    rows=[]
    for i in range(0,6,2):
        a=compare.tile(chars[i],560,bg); b=compare.tile(chars[i+1],560,bg)
        r=Image.new('RGB',(a.width+b.width+40,max(a.height,b.height)),'white'); r.paste(a,(0,0)); r.paste(b,(a.width+40,0)); rows.append(r)
    ts=[compare.tile(n,200,bg) for n in doods]
    x=0; dr=[]; cur=[]
    W=max(r.width for r in rows)
    for t in ts:
        if x+t.width>W and cur: dr.append(cur); cur=[]; x=0
        cur.append(t); x+=t.width+20
    dr.append(cur)
    for c in dr:
        r=Image.new('RGB',(W,max(t.height for t in c)),'white'); x=0
        for t in c: r.paste(t,(x,0)); x+=t.width+20
        rows.append(r)
    H=sum(r.height+20 for r in rows); im=Image.new('RGB',(W,H),'white'); y=0
    for r in rows: im.paste(r,(0,y)); y+=r.height+20
    im.save(out); print(im.size)
if __name__=='__main__':
    sheet('/home/claude/game/assets/compare_fish_icecream_flowerpot.png')
