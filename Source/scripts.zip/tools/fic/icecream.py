import json, math, numpy as np
from build import Sprite, write_pair, INK
from shapes import color_blobs, dashes
K='3524'
S=0.62
T=json.load(open('/home/claude/game/tools/fic/traces/icU.json')); B=T['blobs']; T=T['strokes']
RED='#d03c37'; CHERRY='#c8342f'; STALK='#963a19'; BROWN='#7a260c'; CONE='#74230a'
TEAL_D='#0a8196'; TEAL_L='#2fadaa'; WHITE='#ffffff'; GREY='#4b524f'; PINK='#ef96c0'
SPR_P='#eb9fc4'; SPR_T='#3fb0ad'; HEARTRED='#d9443c'
sp=Sprite(S, origin=(80,0), eps=1.2)
def st(part,ids,width=9,**kw):
    for i in ids: sp.stroke(part,T[i],width=width,**kw)
# ---------- outlines ----------
st('scoop-5',[3,5,24]); sp.stroke('scoop-5',T[23][:36])
sp.stroke('scoop-5',T[4][19:][::-1]+T[6][8:])
sp.stroke('scoop-5',T[2][:7])
sp.stroke('scoop-4',T[23][35:]); st('scoop-4',[39,44,26,41])
st('scoop-3',[45,42])
st('scoop-2',[82,61,93,101])
st('scoop-1',[97,95,130])
# scoop-1 bottom edge = top of the cone (his line, re-joined where marker pooled)
CONE_TOP=[(366,1096),(372,1104),(393,1103),(413,1105),(434,1117),(445,1120),(463,1113),(480,1111),(499,1117),(520,1119),(542,1118),(558,1110),(574,1108),(586,1099),(603,1094),(635,1100),(655,1101)]
sp.stroke('scoop-1',CONE_TOP)
st('cone',[133,153,131])
# ---------- fills ----------
BND={'scoop-5':(340,140,700,410),'scoop-4':(330,340,700,640),'scoop-3':(330,540,700,800),
     'scoop-2':(340,690,700,1030),'scoop-1':(340,880,720,1130),'cone':(340,1080,720,1290)}
for part,seed,col in [('scoop-5',(500,200),RED),('scoop-4',(380,520),WHITE),('scoop-3',(380,680),WHITE),
                      ('scoop-2',(520,800),TEAL_D),('scoop-1',(520,1010),TEAL_L),('cone',(480,1180),CONE)]:
    sp.seed_fill(part,seed,col,within=BND[part])
from build import poly_and
import subprocess
def U(pts): return sp.U(pts)
def fill_part(part): return [e for e in sp.els if e['part']==part and e['kind']=='fill'][0]['pts']
# ---------- scoop-3 chocolate top (his brown band, kept inside the scoop) ----------
for poly in color_blobs(K,(325,540,705,700),'brown',min_area=150,blur=2.5):
    for q in poly_and(U(poly),fill_part('scoop-3')):
        sp.fill('scoop-3',q,BROWN,src=False)
# ---------- cherries + stalks (no black outline in his drawing) ----------
DOME=[(330,400),(345,300),(380,220),(440,170),(510,150),(580,158),(640,190),(680,250),(700,400)]
import cv2
for box,ins,seed in [((255,110,415,265),[(255,110),(415,110),(415,160),(395,200),(372,265),(255,265)],11),
                ((585,55,705,215),[(585,55),(705,55),(705,215),(655,215),(625,180),(585,165)],12)]:
    poly=color_blobs(K,box,'redfill',min_area=600,blur=3,keep=1,inside=ins)[0]
    (cx,cy),(w,h),ang=cv2.fitEllipse(np.array(poly,np.float32))
    sp.dot('cherries',(cx,cy),0,rx=w/2*0.97,ry=h/2*0.97,rot=ang+90,n=14,wob=0.035,color=CHERRY,seed=seed)
# stalk: his broad brown bundle plus two branches out to the cherries
sp.fill('cherries',[(470,30),(503,24),(546,26),(549,52),(542,110),(538,160),(505,168),(468,158),(466,95)],STALK,steady=0)
sp.stroke('cherries',[(474,84),(430,113),(392,146)],color=STALK,width=22*S,steady=0)
sp.stroke('cherries',[(544,52),(592,113),(637,176)],color=STALK,width=22*S,steady=0)
# ---------- faces ----------
def blob(part,i,col=INK): sp.fill(part,B[i],col,steady=0.8)
# scoop-5 (red cherry scoop): big black eyes with white shines, angry brows, zigzag mouth
sp.dot('scoop-5',(443,280),0,rx=26,ry=31,rot=-8,n=14,seed=1)
sp.dot('scoop-5',(433,270),0,rx=10,ry=9,rot=20,n=10,color=WHITE,seed=2)
sp.dot('scoop-5',(619,262),0,rx=37,ry=42,rot=-10,n=14,seed=3)
sp.dot('scoop-5',(601,272),0,rx=13,ry=15,rot=-20,n=10,color=WHITE,seed=4)
sp.stroke('scoop-5',[(505,305),(514,322),(528,300),(541,319),(553,302),(562,319),(576,304)],width=6,corner=40,steady=0)
# scoop-4 (white sprinkle scoop)
sp.dot('scoop-4',(416,449),0,rx=25,ry=29,rot=-5,n=14,seed=5)
sp.fill('scoop-4',[(410,477),(409,466),(415,457),(425,455),(434,461),(438,470),(437,477)],TEAL_L,steady=0)
sp.stroke('scoop-4',[(431,478),(428,484),(422,486)],width=5,steady=0)
sp.dot('scoop-4',(623,433),0,rx=23,ry=31,rot=-15,n=14,seed=6)
sp.dot('scoop-4',(617,446),0,rx=12,ry=12,n=10,color=TEAL_L,seed=7)
sp.stroke('scoop-4',[(604,465),(620,469),(640,462)],width=5,steady=0)
st('scoop-4',[38],width=7)
st('scoop-4',[35],width=7)
try: sp.seed_fill('scoop-4',(533,545),TEAL_L,within=(505,455,560,585),grow=2.5)
except RuntimeError as e: print('WARN',e)
WHITE_IN=[(368,402),(400,385),(640,388),(660,450),(655,540),(610,555),(500,590),(400,605),(352,560),(352,470)]
def excluded(c):
    return (385<c[0]<448 and 415<c[1]<490) or (592<c[0]<652 and 395<c[1]<472) or (512<c[0]<552 and 455<c[1]<585)
for mode,col in (('pinkfill',SPR_P),('tealfill',SPR_T)):
    for p0,p1,w in dashes(K,(330,380,690,640),mode,inside=WHITE_IN,min_area=20):
        c=((p0[0]+p1[0])/2,(p0[1]+p1[1])/2)
        if excluded(c): continue
        sp.stroke('scoop-4',[p0,p1],color=col,width=max(4.5,min(7,w*S*1.15)),steady=0)
# scoop-3: closed happy arches, black open mouth, heart cheeks with little faces
st('scoop-3',[55,54],width=7)
sp.fill('scoop-3',[(478,675),(492,662),(512,665),(535,660),(541,668),(535,690),(525,712),(505,722),(482,722),(470,708),(474,690)],INK,steady=0)
H=json.load(open('/home/claude/game/tools/fic/traces/icHearts.json'))['strokes']
LH=[(447.6,698.5),(441,694),(434.4,693.6),(426,698),(422.1,709.2),(424.6,720.7),(436.1,732.2),(456.6,742.1),(460,736),(464,724),(467.3,709.2),(468.1,699.4),(465.6,695.2),(457.4,694.4),(447.6,698.5)]
sp.stroke('scoop-3',LH,color=HEARTRED,width=4.5,steady=0.5,corner=50)
sp.stroke('scoop-3',[(432,706.7),(438,704),(444.3,703.5)],color=HEARTRED,width=4,steady=0)
sp.stroke('scoop-3',[(463,706),(470.6,702.6)],color=HEARTRED,width=4,steady=0)
sp.stroke('scoop-3',[(444,712.5),(449,720),(460.3,712.3)],color=HEARTRED,width=4.5,steady=0,corner=40)
sp.stroke('scoop-3',[(449,720),(447.7,725)],color=HEARTRED,width=4,steady=0)
sp.stroke('scoop-3',H[1]+H[2][::-1],color=HEARTRED,width=4.5,steady=0.6,corner=50)
for i in (3,4,7): sp.stroke('scoop-3',H[i],color=HEARTRED,width=4.5,steady=0.3)
# scoop-2 (dark teal): scrunched >< eyes and gritted mouth
st('scoop-2',[85,88,86,87],width=7); st('scoop-2',[89,90,91,92,94],width=6)
# scoop-1 (light teal, sleepy): pink-lidded half-shut eyes, smile with dark drool/tongue
# left eye: pink lid on top, dark hatched eye under it
LE=[(403,1006),(436,1000),(468,997),(480,1018),(489,1042),(470,1049),(440,1046),(410,1040)]
sp.fill('scoop-1',LE,INK,steady=0); sp.stroke('scoop-1',LE,closed=True,width=6,steady=0,corner=50)
CAP=[(417,1003),(421,990),(433,983),(447,984),(459,993),(462,1001),(440,1002)]
sp.fill('scoop-1',CAP,PINK,steady=0); sp.stroke('scoop-1',CAP,closed=True,width=4,steady=0,corner=60)
# right eye: dark dome with a pink peek inside, flat lower lid
RE=[(576,1036),(575,1005),(580,980),(598,964),(626,963),(650,982),(664,1012),(666,1023)]
sp.fill('scoop-1',RE,INK,steady=0); sp.stroke('scoop-1',RE,closed=True,width=6,steady=0,corner=50)
sp.fill('scoop-1',[(603,1029),(611,1005),(621,996),(631,1003),(640,1021),(633,1027)],PINK,steady=0)
blob('scoop-1',5); st('scoop-1',[128],width=7); st('scoop-1',[127],width=6); st('scoop-1',[124],width=6)
# ---------- cone waffle lines ----------
st('cone',[146,149,151,147,156,160,161,154,157,159,145,144,155,135,148,141,140,158,152,134,143,137,139],width=5)
# ---------- action lines ----------
st('fx',[16,17,33,28,43,40,142,136,163,162])
# ---------- arms + dumbbells ----------
st('arms',[83]); sp.stroke('arms',[(786,699),(751,746)]+T[84])
def dumbbell(weights_first, bar, weights_last, marks):
    for w in weights_first: sp.fill('arms',w,GREY,steady=0); sp.stroke('arms',w,closed=True,width=8,steady=0)
    sp.fill('arms',bar,GREY,steady=0); sp.stroke('arms',bar,closed=True,width=8,steady=0,corner=50)
    for w in weights_last: sp.fill('arms',w,GREY,steady=0); sp.stroke('arms',w,closed=True,width=8,steady=0)
    for m in marks: sp.stroke('arms',m,width=5,steady=0,corner=50)
dumbbell([[(162,694),(140,688),(117,694),(105,712),(108,735),(120,752),(140,758),(162,752)]],
         [(161,690),(215,684),(272,683),(276,752),(215,752),(159,749)],
         [[(276,688),(287,667),(306,657),(331,661),(345,682),(347,715),(340,740),(320,750),(296,748),(279,731)]],
         [[(218,704),(240,702)],[(220,705),(223,734),(238,712),(253,735)]])
dumbbell([[(745,690),(737,662),(716,652),(694,657),(684,675),(684,700),(694,718),(714,728),(735,724),(745,708)]],
         [(744,661),(790,659),(836,661),(837,697),(790,700),(744,700)],
         [[(835,668),(848,650),(870,642),(892,646),(904,665),(903,695),(890,715),(866,725),(845,720),(836,700)]],
         [[(812,669),(794,669),(792,690)],[(792,686),(806,679),(818,684),(820,696),(811,703)]])
ORDER=['fx','arms','cone','scoop-1','scoop-2','scoop-3','scoop-4','cherries','scoop-5']
PARTS=[('part-fx',['fx']),('part-arms',['arms']),('part-cone',['cone'])]+[(f'part-scoop-{k}',[f'scoop-{k}']) for k in (1,2,3,4)]+\
      [('part-cherries',['cherries']),('part-scoop-5',['scoop-5'])]
if __name__=='__main__':
    print(write_pair(sp,PARTS,'icecream_unfolded',title='Ice cream (unfolded)'))
