"""Side-by-side photo crop vs redraw sheet."""
import sys, subprocess, json
from PIL import Image, ImageDraw
Image.MAX_IMAGE_PIXELS=None
ROWS={
 'fish_folded':('3521',(170,500,780,1070)),
 'fish_unfolded':('3522',(190,80,870,1290)),
 'icecream_folded':('3523',(95,150,900,1110)),
 'icecream_unfolded':('3524',(90,15,925,1345)),
 'flowerpot_folded':('3528',(230,370,895,1045)),
 'flowerpot_unfolded':('3529',(190,30,880,1345)),
}
def load_rows():
    try: ROWS.update({k:tuple(v) for k,v in json.load(open('/home/claude/game/tools/fic/compare_rows.json')).items()})
    except FileNotFoundError: pass
def tile(name, H=700, bg=(255,255,255)):
    key,box=ROWS[name]
    full=Image.open(f'/home/claude/game/tools/fic/ref/{key}_full.png'); s=full.width/1050
    ph=full.crop(tuple(int(v*s) for v in box)); ph=ph.resize((int(ph.width*H/ph.height),H))
    svg=f'/home/claude/game/assets/svg/{name}.svg'
    subprocess.run(['rsvg-convert','-h',str(H),'-b','#%02x%02x%02x'%bg,'-o','/tmp/_c.png',svg],check=True)
    rd=Image.open('/tmp/_c.png').convert('RGB')
    im=Image.new('RGB',(ph.width+rd.width+30,H+30),'white')
    im.paste(ph,(0,30)); im.paste(rd,(ph.width+30,30))
    ImageDraw.Draw(im).text((5,5),name+'  (photo | redraw)',fill='black')
    return im
if __name__=='__main__':
    load_rows()
    names=sys.argv[2:] ; out=sys.argv[1]
    H=int(700 if len(names)<=2 else 520)
    tiles=[tile(n,H) for n in names]
    W=max(t.width for t in tiles); im=Image.new('RGB',(W,sum(t.height for t in tiles)),'white'); y=0
    for t in tiles: im.paste(t,(0,y)); y+=t.height
    im.save(out)
