import numpy as np, cv2
from trace import load
import colorspec
def color_blobs(key, box, mode, min_area=40, blur=2.0, close=7, open_=5, f=1.5, inside=None, eps=0.8, keep=None):
    """Return smoothed polygons (src coords) of colour regions. inside: polygon (src) to restrict."""
    x0,y0,x1,y1=box
    img=colorspec.white_balance(load(key,x0,y0,x1,y1,f))
    m=colorspec.mask2(img,mode).astype(np.uint8)*255
    if inside is not None:
        lim=np.zeros_like(m); P=np.array([((x-x0)*f,(y-y0)*f) for x,y in inside],np.int32)
        cv2.fillPoly(lim,[P],255); m&=lim
    if close: m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(close,close)))
    if open_: m=cv2.morphologyEx(m,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(open_,open_)))
    if blur: m=(cv2.GaussianBlur(m.astype(np.float32),(0,0),blur*f)>127).astype(np.uint8)*255
    cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    out=[]
    for c in sorted(cs,key=cv2.contourArea,reverse=True):
        if cv2.contourArea(c)<min_area*f*f: continue
        c=cv2.approxPolyDP(c,eps*f,True)[:,0,:].astype(float)
        out.append([(x0+x/f,y0+y/f) for x,y in c])
    return out[:keep] if keep else out
def dashes(key, box, mode, inside=None, min_area=25, f=1.5):
    """Short marker dashes -> list of (p0,p1,width) in src coords."""
    x0,y0,x1,y1=box
    img=colorspec.white_balance(load(key,x0,y0,x1,y1,f))
    m=colorspec.mask2(img,mode).astype(np.uint8)*255
    if inside is not None:
        lim=np.zeros_like(m); P=np.array([((x-x0)*f,(y-y0)*f) for x,y in inside],np.int32)
        cv2.fillPoly(lim,[P],255); m&=lim
    m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n,lab,st,_=cv2.connectedComponentsWithStats(m)
    out=[]
    for i in range(1,n):
        if st[i,4]<min_area*f*f: continue
        ys,xs=np.where(lab==i)
        (cx,cy),(w,h),ang=cv2.minAreaRect(np.stack([xs,ys],1).astype(np.float32))
        if w<h: w,h=h,w; ang+=90
        L=max(0,w-h)/2; t=np.radians(ang)
        p0=(x0+(cx-L*np.cos(t))/f, y0+(cy-L*np.sin(t))/f); p1=(x0+(cx+L*np.cos(t))/f, y0+(cy+L*np.sin(t))/f)
        out.append((p0,p1,h/f))
    return out
