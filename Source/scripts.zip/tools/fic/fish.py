import json, math, numpy as np
from build import Sprite, autocrop, render, INK
S=0.835   # units per 3522-small px
T=json.load(open('/home/claude/game/tools/fic/traces/fishU.json'))['strokes']
PINK='#f0aacb'; HEART='#ec86b6'; SCRIB='#4a4648'; PAPER='#ffffff'
sp=Sprite(S, origin=(190,85), eps=1.3)

def linefit(pts):
    a=np.array(pts); A=np.vstack([a[:,0],np.ones(len(a))]).T
    m,c=np.linalg.lstsq(A,a[:,1],rcond=None)[0]; return lambda x:m*x+c
sep_ids=[11,25,32,44,87]
seps=[linefit(T[i]) for i in sep_ids]
seps.append(linefit([p for p in T[98] if p[0]>335]))
_L=sorted([p for p in T[1] if p[1]>275]+T[95],key=lambda p:p[1])
def ledge(y): return float(np.interp(y,[p[1] for p in _L],[p[0] for p in _L]))
def redge(y): return 648
def region(x,y):
    if x<ledge(y)-5 and 845<y<1010: return 'fin-left'
    if x>redge(y)+6 and 690<y<1010: return 'fin-right'
    k=sum(1 for f in seps if y>f(x)+1)
    return ['head','seg-1','seg-2','seg-3','seg-4','seg-5','tail'][k]

skip={0,2,3,4,111,113,115,114,47,57,60,71,78,9,28,96}
scrib=set(range(45,87))-{58,83}
override={6:'head',10:'seg-1',17:'seg-1'}
for i,s in enumerate(sep_ids): override[s]=f'seg-{i+1}'
# close small gaps between his divider lines and the body edges
for i in sep_ids:
    p=T[i]
    if p[0][0]>p[-1][0]: p=p[::-1]
    if p[0][0]>ledge(p[0][1])+1: p=[[ledge(p[0][1])-1,p[0][1]]]+p
    if p[-1][0]<644: p=p+[[647,p[-1][1]]]
    T[i]=p
hand=set([12,13,14,15,16,18,19,20,21,22,23,24,33,35,36,37,38,39,40,41,42,43,89,90])
hearts=[26,27,29,30,31]

def add_split(i,pts,width=9):
    if i in override:
        sp.stroke(override[i],pts,width=width); return
    run=[pts[0]]; cur=region(*pts[0]) if i!=98 else ('fin-left' if pts[0][0]<ledge(pts[0][1])-5 else 'seg-5')
    def reg(p):
        if i==98: return 'fin-left' if p[0]<ledge(p[1])-5 else 'seg-5'
        return region(*p)
    # densify so cuts land near boundaries
    dense=[pts[0]]
    for a,b in zip(pts,pts[1:]):
        n=max(1,int(math.dist(a,b)/3))
        for t in range(1,n+1): dense.append((a[0]+(b[0]-a[0])*t/n,a[1]+(b[1]-a[1])*t/n))
    for p in dense[1:]:
        r=reg(p)
        run.append(p)
        if r!=cur:
            if len(run)>=2: sp.stroke(cur,run,width=width)
            run=[p]; cur=r
    if len(run)>=2: sp.stroke(cur,run,width=width)

for i,s in enumerate(T):
    if i in skip or i in scrib: continue
    if i in hand or i in hearts: continue
    add_split(i,s)

# tail closure where his line had a gap
sp.stroke('tail',[(328.7,1024),(336,1026),(344,1030)])
# hearts (seg-2) and handwriting
for i in hearts: sp.stroke('seg-2',T[i],width=7)
sp.stroke('seg-5',T[92],width=7); sp.stroke('seg-5',T[93],width=7)
B={'head':(200,90,760,300),'seg-1':(300,280,700,420),'seg-2':(300,360,700,560),'seg-3':(300,520,700,670),
   'seg-4':(300,630,700,790),'seg-5':(300,740,700,1000),'tail':(300,880,700,1200),'fin-left':(195,840,345,1010),'fin-right':(640,680,860,1010)}
fills=[('head',(450,150),PINK),('head',(600,150),PINK),('head',(520,262),PINK),
       ('seg-1',(360,340),PINK),('seg-2',(470,470),PINK),('seg-2',(600,480),PINK),
       ('seg-3',(620,600),PINK),('seg-4',(636,690),PINK),('seg-5',(620,850),PINK),
       ('tail',(480,1030),PAPER),('fin-left',(240,920),PINK),('fin-left',(250,975),PINK),('fin-left',(270,882),PINK),
       ('fin-right',(780,780),PINK),('fin-right',(700,720),PINK),('fin-right',(720,870),PINK),('fin-right',(720,950),PINK),
       ('seg-2',(400,420),HEART),('seg-2',(530,440),HEART),('seg-5',(440,825),HEART)]
for part,seed,col in fills:
    try: sp.seed_fill(part,seed,col,grow=3.6,within=B[part])
    except RuntimeError as e: print('WARN',e)
for i in hand:
    p=T[i]; y=np.mean([q[1] for q in p])
    part='seg-1' if y<375 else ('seg-3' if y<640 else 'seg-5')
    sp.stroke(part,p,width=7)
# scribble: continuous back-and-forth zigzag loops over the word, like his pen
rng=np.random.RandomState(4)
def scribble(xa,xb,yc,amp,passes,seed,tilt=0.0):
    r=np.random.RandomState(seed); pts=[]
    for k in range(passes):
        x0,x1=(xa,xb) if k%2==0 else (xb,xa)
        xa_=xa+r.uniform(0,25); xb_=xb-r.uniform(0,25)
        x0,x1=(xa_,xb_) if k%2==0 else (xb_,xa_)
        y=yc+amp*math.sin(k*1.7+seed)+r.uniform(-4,4)
        for t in np.linspace(0,1,7):
            x=x0+(x1-x0)*t
            env=math.sin(math.pi*min(1,max(0,(x-xa)/(xb-xa))))  # lens shape
            pts.append((x, y+tilt*(x-xa)+ (r.uniform(-2,2)) + (k%2*2-1)*6*env))
    return pts
sp.stroke('seg-4',scribble(322,655,706,12,9,1,0.03),color=SCRIB,width=3.5,steady=0.6,corner=100)
sp.stroke('seg-4',scribble(330,645,722,10,7,5,0.02),color=SCRIB,width=3.5,steady=0.6,corner=100)
sp.stroke('seg-4',scribble(345,630,738,6,5,9,-0.01),color=SCRIB,width=3.5,steady=0.6,corner=100)
for a,b in [((470,722),(562,763)),((520,720),(578,757)),((560,716),(592,740)),((420,730),(468,752))]:
    sp.stroke('seg-4',[a,((a[0]+b[0])/2,(a[1]+b[1])/2+3),b],color=SCRIB,width=3.5)
# --- scribbled-out "Mom" (seg-4), letters as he wrote them ---
sp.stroke('seg-4',[(352.6,727),(373.4,659),(399.4,718),(430.7,666),(453.3,741)],width=7,corner=40)
sp.stroke('seg-4',[(488,737),(474,726),(467,710),(470,697),(483,691),(497,700),(501,718),(488,737)],width=7)
sp.stroke('seg-4',[(510.6,734),(514,709.7),(524.4,701),(533.1,706.2),(538.3,718.3),(543.5,709.7),(552.2,708.7),(557.4,720),(564.4,711.4),(573,710.4),(577.2,720),(585.2,709.7),(595.6,710.4),(604.3,722)],width=7,corner=50)
# I-dot
sp.dot('seg-5',(373,778),0,rx=10,ry=15,rot=10,n=12)

# ---- fills (added after strokes so barriers exist), then reorder fills first ----
# eyes
sp.stroke('head',[(437,176),(442,182),(442,194),(438,201),(433,195),(433,182)],width=5,closed=True,steady=0)
sp.dot('head',(630,169),0,rx=6.5,ry=9.5,rot=25,n=12,seed=2)

ORDER=['fin-left','fin-right','tail','seg-5','seg-4','seg-3','seg-2','seg-1','head']
PARTS=[('part-fin-left',['fin-left']),('part-fin-right',['fin-right']),('part-head',['head'])]+\
      [(f'part-seg-{k}',[f'seg-{k}']) for k in (1,2,3,4)]+[('part-tail',['tail']),('part-seg-5',['seg-5'])]

def unit_y(y): return (y-sp.o[1])*S
if __name__=='__main__':
    import json as _j
    from build import write_pair
    # move handwriting letters of the crossed-out word above the scribble so they stay readable
    YH,YT=278,1030
    yh,yt=unit_y(YH),unit_y(YT)
    bands={'part-head':(-1e9,yh,0),'part-tail':(yt,1e9,-(yt-yh))}
    res=write_pair(sp,PARTS,'fish',folded_parts=[('part-head',['head']),('part-tail',['tail'])],bands=bands,title='Pink fish')
    print(res)
    _j.dump({k:v for k,v in res.items()},open('/home/claude/game/tools/fic/fish_res.json','w'))
