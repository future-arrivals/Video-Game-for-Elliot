import sys, pickle
from build import autocrop, render
mod=__import__(sys.argv[1])
sp=mod.sp
vb=autocrop(sp, mod.PARTS, '/tmp/prev.svg')
render('/tmp/prev.svg','/tmp/prev.png',1400,bg='#ffffff')
print(vb)
