# dbgtile.py TRACEJSON KEY x0 y0 x1 y1 out  : zoomed view of traced strokes with ids
import sys, json, numpy as np
from PIL import Image, ImageDraw
Image.MAX_IMAGE_PIXELS=None
d=json.load(open(sys.argv[1])); key=sys.argv[2]; x0,y0,x1,y1=map(float,sys.argv[3:7]); out=sys.argv[7]
full=Image.open(f'/home/claude/game/tools/fic/ref/{key}_full.png'); s=full.width/1050
f=1300/max(x1-x0,y1-y0)
im=full.crop((int(x0*s),int(y0*s),int(x1*s),int(y1*s))).resize((int((x1-x0)*f),int((y1-y0)*f)))
im=Image.blend(im,Image.new('RGB',im.size,'white'),0.55); dr=ImageDraw.Draw(im)
rng=np.random.RandomState(3)
for i,st in enumerate(d['strokes']):
    a=np.array(st)
    if a[:,0].max()<x0 or a[:,0].min()>x1 or a[:,1].max()<y0 or a[:,1].min()>y1: continue
    col=tuple(int(c) for c in rng.randint(0,200,3))
    P=[((x-x0)*f,(y-y0)*f) for x,y in st]
    dr.line(P,fill=col,width=3)
    dr.ellipse([P[0][0]-4,P[0][1]-4,P[0][0]+4,P[0][1]+4],outline=col)
    m=P[len(P)//2]; dr.text((m[0]+4,m[1]-10),str(i),fill=col,font_size=20)
for i,b in enumerate(d.get('blobs',[])):
    P=[((x-x0)*f,(y-y0)*f) for x,y in b]
    if len(P)>2: dr.polygon(P,outline=(255,0,0))
    dr.text(P[0],'B%d'%i,fill=(255,0,0),font_size=18)
im.save(out)
