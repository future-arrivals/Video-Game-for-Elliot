import json, math, numpy as np, cv2
from build import Sprite, write_pair, INK, poly_and
from shapes import color_blobs
K='3529'; S=0.645
D=json.load(open('/home/claude/game/tools/fic/traces/potU.json')); T=D['strokes']; B=D['blobs']
POT='#c4282d'; SOIL='#85300f'; STEM='#1f8a45'; STRIPE='#9cbc45'; BULB='#7ca62e'; SHOOTF='#1f5c38'
SCRIB='#66c088'; WHITE='#ffffff'; LTG='#8fbf3c'; PINKD='#f07cc3'
sp=Sprite(S, origin=(150,20), eps=1.2)
def st(part,ids,width=9,**kw):
    for i in ids: sp.stroke(part,T[i],width=width,**kw)
def bb(i): a=np.array(T[i]); return a.min(0),a.max(0)
# ---------------- pot ----------------
st('pot',[145,132,137,175])
POT_FILL_PENDING=True
# soil: his brown band (no black outline on top), then the red pot body over it
soil=color_blobs(K,(305,985,730,1100),'brown',min_area=500,blur=3,keep=1)[0]
sp.fill('pot',soil,SOIL,steady=1.0)
sp.seed_fill('pot',(660,1200),POT,within=(300,1050,730,1300))
sp.fill('pot',[(450,1212),(595,1210),(597,1262),(450,1268)],POT,steady=0)
st('pot',[114,116,119,115,113,117,118,120,121,123,124,125,126,129,131,128,134],width=6)   # soil scribble lines
# soil top edge (the brown band's upper boundary, his wavy line) closes the soil
SOIL_TOP=[(322,1085),(330,1040),(345,1028),(380,1016),(420,1012),(470,1010),(520,1013),(560,1022),(600,1030),(640,1040),(680,1050),(700,1058),(712,1068)]
st('pot',[140,150,146,148],width=6)
mouth=[162,163,164,165,166,167,168,169,170,171,172,174,178,161]
st('pot',mouth,width=6)
for bi in (2,3,4,5): sp.fill('pot',B[bi],INK,steady=0.8)
hands=[127,133,136,142,149,151,153,154,155,156,157,158,122,130,135,138,139,141,143,144,147,152]
st('pot',hands,width=7)
legs=[(353,1281,354,1305,[(342,1324),(368,1324)]),(404,1283,406,1305,[(392,1325),(422,1324)]),
      (470,1267,470.6,1304,[(457,1324),(488,1323)]),(539,1265,540,1304,[(530,1325),(563,1323)]),
      (593.7,1254,600.8,1300,[(590,1325),(608,1325),(621,1312)]),(645,1254,654,1300,[(647,1325),(661,1325),(676,1313)]),
      (691,1254,692.8,1303,[(683,1325),(705,1322)])]
for x0,y0,x1,y1,toes in legs:
    sp.stroke('pot',[(x0,y0),((x0+x1)/2+1,(y0+y1)/2),(x1,y1)],width=7,steady=0)
    for t in toes: sp.stroke('pot',[(x1,y1),t],width=6,steady=0)
# eyes: big black eyes with a red glint at the bottom, angled brows from the rim
sp.dot('pot',(405,1143),0,rx=36,ry=41,rot=-5,n=14,seed=1)
sp.dot('pot',(581,1134),0,rx=36,ry=37,rot=5,n=14,seed=2)
sp.fill('pot',[(396,1182),(398,1172),(406,1167),(415,1170),(418,1180)],POT,steady=0)
sp.fill('pot',[(576,1170),(578,1162),(586,1158),(593,1163),(594,1170)],POT,steady=0)
sp.stroke('pot',[(374,1072),(392,1088),(410,1108)],width=7,steady=0)
sp.stroke('pot',[(612,1067),(594,1083),(578,1101)],width=7,steady=0)
# ---------------- stem ----------------
def clipy(pts,y0,y1):
    from build import clip_line_y
    return clip_line_y(pts,y0,y1)
for i in (59,80,108):
    for pc in clipy(T[i],292,1016): sp.stroke('stem',pc)
for pc in clipy(T[58][2:],300,1016): sp.stroke('stem',pc)
for pc in clipy(T[33],300,1016): sp.stroke('stem',pc)
sp.stroke('stem',[(452,332),(455,309),(466,293),(484,286),(502,289),(512,300),(513,312)])
for pc in clipy(T[53],292,1016): sp.stroke('stem',pc)
# stem face: scrunched eyes, dot eye, toothy box mouth
st('stem',[82,88],width=6); sp.fill('stem',B[17],INK,steady=0.6)
st('stem',[95,96,97,99,103,104,107],width=5)
for bi in (13,14,15): sp.fill('stem',B[bi],INK,steady=0.6)
sp.stroke('stem',[p for p in T[79] if p[0]<=636],width=6); st('stem',[105],width=6)
sp.fill('stem',B[9],INK,steady=0.8)
# ---------------- side shoot ----------------
sp.stroke('shoot',[p for p in T[79] if p[0]>=630],width=6)
st('shoot',[65,68,71,84,83,86,87,89,91,93,98,102,109,110,106,74,73,75,72],width=6)
st('shoot',[62]); st('shoot',[63,64,66,67,69,70],width=5)
# ---------------- smiley bulbs ----------------
SB=[(222,728),(236,725),(248,733),(250,748),(246,765),(239,779),(227,786),(215,779),(210,760),(212,742)]
BB=[(268,815),(282,825),(289,848),(291,878),(285,903),(270,915),(248,912),(229,896),(218,870),(224,842),(244,822)]
def outside(p): return not (205<=p[0]<=252 and 722<=p[1]<=790) and not (215<=p[0]<=293 and 812<=p[1]<=918)
from build import clip_line_y
def runs(pts):
    out=[];cur=[]
    dense=[pts[0]]
    for a_,b_ in zip(pts,pts[1:]):
        n=max(1,int(math.dist(a_,b_)/1.5))
        for t in range(1,n+1): dense.append((a_[0]+(b_[0]-a_[0])*t/n,a_[1]+(b_[1]-a_[1])*t/n))
    for q in dense:
        if outside(q): cur.append(q)
        else:
            if len(cur)>1: out.append(cur)
            cur=[]
    if len(cur)>1: out.append(cur)
    return out
for i in (76,78,90,100,92,101):
    for r in runs(T[i]): sp.stroke('bulbs',r,width=7)
sp.fill('bulbs',SB,BULB,steady=0); sp.stroke('bulbs',SB,closed=True,width=7,steady=0)
sp.fill('bulbs',BB,BULB,steady=0); sp.stroke('bulbs',BB,closed=True,width=7,steady=0)
sp.dot('bulbs',(225,755),0,rx=3.5,ry=4,n=8,seed=3)
sp.stroke('bulbs',[(235,750),(242,749)],width=4.5,steady=0)
sp.stroke('bulbs',[(222,764),(229,771),(240,764)],width=4.5,steady=0,corner=40)
sp.dot('bulbs',(241,846),0,rx=4.5,ry=5.5,n=8,seed=5); sp.dot('bulbs',(257,840),0,rx=4.5,ry=5.5,n=8,seed=6)
sp.stroke('bulbs',[(237,860),(242,873),(252,881),(265,880),(273,868),(274,856)],width=5.5,steady=0)
# ---------------- flower cluster ----------------
fl=[i for i in range(0,58) if i not in (33,39,43,53,58,59) and np.array(T[i])[:,1].max()<330]
st('flower',fl,width=5.5)
for pc in clipy(T[33],0,286): sp.stroke('flower',pc,width=5.5)
for pc in clipy(T[53],0,292): sp.stroke('flower',pc,width=5.5)
# ---------------- fills ----------------
def F(part,seed,col,extra=(),within=None,grow=None):
    try: return sp.seed_fill(part,seed,col,extra=extra,within=within,grow=grow)
    except RuntimeError as e: print('WARN',e)
TOPL=[(426,313),(442,300),(458,292)]; TOPR=[(512,300),(534,292),(556,292)]
BOT=[(380,1008),(460,1012),(520,1014),(575,1015)]; RGAP=[(637,773),(631,785),(626,795)]
F('stem',(380,700),STEM,extra=[TOPL,TOPR,BOT,RGAP],within=(330,280,660,1040))
F('stem',(480,600),STRIPE,extra=[TOPL,TOPR,BOT,RGAP],within=(330,280,660,1040))
for sd in [(560,500),(560,900),(615,740),(410,950)]:
    F('stem',sd,STEM,extra=[TOPL,TOPR,BOT,RGAP],within=(330,280,660,1040))
F('shoot',(700,745),WHITE,extra=[RGAP],within=(600,590,860,860))
face=color_blobs(K,(730,585,860,700),'dkgreen',min_area=200,blur=2,keep=1)[0]
sp.fill('shoot',face,SHOOTF,steady=0.8)
for bi in (19,20,21,22,23): sp.fill('shoot',B[bi],INK,steady=0.6)

from build import enclosed_fill
print('cluster shapes filled:',enclosed_fill(sp,'flower',WHITE,['flower'],box=(355,60,670,300)))
for bi in (25,27,28,30,31): sp.fill('flower',B[bi],INK,steady=0.6)
sp.dot('flower',(490,74),0,rx=21,ry=19,n=12,seed=9)

# ---------------- scribble behind the cluster (his looping green pencil) ----------------
rng=np.random.RandomState(7); pts=[]
NL=22; N=NL*22
rads=[rng.uniform(50,100) for _ in range(NL+1)]
for k in range(N):
    t=k/22*2*math.pi; li=k//22; f=(k%22)/22
    r=rads[li]*(1-f)+rads[li+1]*f
    cx=515+75*math.cos(k/N*2*math.pi*1.7+0.4)+rng.uniform(-2,2); cy=192+50*math.sin(k/N*2*math.pi*2.3+1.1)
    pts.append((cx+r*1.1*math.cos(t), cy+r*0.95*math.sin(t)))
sp.stroke('scrib',pts,color=SCRIB,width=3,steady=0.8)
PARTS=[('part-bulbs',['bulbs']),('part-shoot',['shoot']),('part-pot',['pot']),('part-stem',['stem']),('part-flower',['scrib','flower'])]
if __name__=='__main__':
    YH,YT=333,1000
    yh=(YH-sp.o[1])*S; yt=(YT-sp.o[1])*S
    bands={'part-flower':(-1e9,yh,0),'part-stem':(-1e9,yh,0),'part-pot':(yt,1e9,-(yt-yh))}
    res=write_pair(sp,PARTS,'flowerpot',folded_parts=[('part-pot',['pot']),('part-stem',['stem']),('part-flower',['scrib','flower'])],bands=bands,title='Red flowerpot monster')
    res['_origin']=sp.o; res['_S']=S; res['_YH_YT_src']=(YH,YT)
    print(res); json.dump(res,open('/home/claude/game/tools/fic/pot_res.json','w'))
