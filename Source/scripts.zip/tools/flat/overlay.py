# overlay.py char name W H ppu out : photo (unit space 0..W,0..H) | svg | blend
import sys, json, subprocess
from PIL import Image
from uview import photo_units
ch,name=sys.argv[1:3]; W,H=float(sys.argv[3]),float(sys.argv[4]); ppu=float(sys.argv[5]); out=sys.argv[6]
im,x0,y0,s=photo_units(ch)
tp=lambda u,o: (u-12)/s+o
cr=im.crop((int(tp(0,x0)),int(tp(0,y0)),int(tp(W,x0)),int(tp(H,y0)))).resize((int(W*ppu),int(H*ppu)),Image.LANCZOS)
subprocess.run(['rsvg-convert','-w',str(int(W*ppu)),'-h',str(int(H*ppu)),'/tmp/flat_%s_ws.svg'%name,'-o','/tmp/flat_ov.png'],check=True)
sv=Image.open('/tmp/flat_ov.png').convert('RGBA')
bg=Image.new('RGBA',sv.size,(255,255,255,255)); bg.alpha_composite(sv); sv=bg.convert('RGB')
bl=Image.blend(cr,sv,0.5)
o=Image.new('RGB',(cr.width*3+20,cr.height),'white')
o.paste(cr,(0,0)); o.paste(sv,(cr.width+10,0)); o.paste(bl,(2*cr.width+20,0)); o.save(out)
