# uview.py char ux0 uy0 ux1 uy1 ppu out   -- photo region in SVG unit coords with unit grid
import sys, json, cv2, numpy as np
from PIL import Image, ImageDraw
CH=json.load(open('/home/claude/game/tools/flat/chars.json'))
def photo_units(char):
    c=CH[char]; im=Image.open(c['src']).convert('RGB')
    x0,y0,x1,y1=c['bbox']; s=c.get('long',400)/max(x1-x0,y1-y0); return im,x0,y0,s
if __name__=='__main__':
    ch=sys.argv[1]; ux0,uy0,ux1,uy1=map(float,sys.argv[2:6]); ppu=float(sys.argv[6]); out=sys.argv[7]
    im,x0,y0,s=photo_units(ch)
    tp=lambda u,o: (u-12)/s+o
    cr=im.crop((int(tp(ux0,x0)),int(tp(uy0,y0)),int(tp(ux1,x0)),int(tp(uy1,y0))))
    W,H=int((ux1-ux0)*ppu),int((uy1-uy0)*ppu)
    cr=cr.resize((W,H),Image.LANCZOS); d=ImageDraw.Draw(cr)
    step=10 if ppu>=3 else 20
    import math
    for u in range(int(math.ceil(ux0/step))*step,int(ux1)+1,step):
        X=(u-ux0)*ppu; d.line([(X,0),(X,H)],fill=(0,140,255) if u%50==0 else (150,210,255)); d.text((X+2,2),str(u),fill=(255,0,0))
    for u in range(int(math.ceil(uy0/step))*step,int(uy1)+1,step):
        Y=(u-uy0)*ppu; d.line([(0,Y),(W,Y)],fill=(0,140,255) if u%50==0 else (150,210,255)); d.text((2,Y+2),str(u),fill=(255,0,0))
    cr.save(out)
