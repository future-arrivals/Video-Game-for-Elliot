import sys, numpy as np, cv2
im=cv2.imread(sys.argv[1]); hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
m=((hsv[...,2]<110)|(hsv[...,1]>90)).astype(np.uint8)
m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
n,lab,st,_=cv2.connectedComponentsWithStats(m)
for i in np.argsort(-st[:,4])[:12]:
    if i==0: continue
    print(i, st[i])
