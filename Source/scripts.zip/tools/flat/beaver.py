from svgkit import *
import math
BODY='#e5713f'; LOG='#9a5a3b'; TAIL='#7e4a31'; WHITE='#fbfaf6'; BLACK='#1a1a1a'
# tail: ellipse-ish, hatch lines clipped analytically
TC=(70,332); TRX,TRY,TROT=57,41,-6
def tail_pt(a):
    w=1+0.03*math.sin(3*a+0.7)
    x,y=TRX*w*math.cos(a),TRY*w*math.sin(a); r=math.radians(TROT)
    return (TC[0]+x*math.cos(r)-y*math.sin(r), TC[1]+x*math.sin(r)+y*math.cos(r))
tail_outline=[tail_pt(2*math.pi*i/10) for i in range(10)]
def clip_line(p,q):
    # intersect segment line p->q (extended) with rotated ellipse, return chord shrunk 1 unit
    r=math.radians(-TROT)
    def loc(P): x,y=P[0]-TC[0],P[1]-TC[1]; return (x*math.cos(r)-y*math.sin(r), x*math.sin(r)+y*math.cos(r))
    (x1,y1),(x2,y2)=loc(p),loc(q); dx,dy=x2-x1,y2-y1
    A=(dx/TRX)**2+(dy/TRY)**2; B=2*(x1*dx/TRX**2+y1*dy/TRY**2); C=(x1/TRX)**2+(y1/TRY)**2-1
    D=B*B-4*A*C; t1=(-B-math.sqrt(D))/(2*A); t2=(-B+math.sqrt(D))/(2*A)
    P1=(p[0]+(q[0]-p[0])*t1,p[1]+(q[1]-p[1])*t1); P2=(p[0]+(q[0]-p[0])*t2,p[1]+(q[1]-p[1])*t2)
    m=((P1[0]+P2[0])/2,(P1[1]+P2[1])/2)
    return [P1,m,P2]
hatch=[]
for x,lean in [(30,3),(48,4),(67,5),(85,5),(102,5)]:
    hatch.append(clip_line((x,300),(x+lean,370)))
for y,rise in [(306,-8),(320,-9),(336,-10),(351,-10)]:
    hatch.append(clip_line((10,y-rise/2),(130,y+rise/2)))
body=[(78,173),(80,133),(90,97),(102,77),(120,60),(137,45),(165,31),(190,29),(210,32),(230,42),(245,51),(260,65),(270,77),(282,97),(290,120),(294,150),
      (295,200),(295,247),(290,280),(280,313),(267,343),(250,365),(233,378),(211,382),(187,378),(167,367),(150,350),(137,330),
      (123,307),(110,287),(100,268),(94,240)]
ear_l=[(92,82),(80,55),(81,33),(95,25),(110,27),(122,37),(129,49),(122,66),(102,86)]
ear_l_in=[(100,76),(96,52),(102,46),(112,49),(115,57)]
ear_r=[(230,40),(235,25),(250,15),(262,12),(272,20),(276,35),(272,55),(265,68),(248,62)]
ear_r_in=[(240,46),(245,36),(255,34),(261,42),(260,60)]
log=[(55,184,'c'),(80,178),(124,170),(194,151),(233,145),(293,140),(320,135),(338,140),(350,156),(355,175),(350,195),(340,210),(327,219),
     (300,219),(267,223),(213,233),(140,248),(100,256),(67,259,'c'),(55,250),(51,220),(52,195)]
log_end=[(59,187),(72,198),(79,218),(79,243),(70,257)]
paw_l=[(97,243),(99,226),(108,213),(123,208),(137,216),(143,234),(139,248),(126,253),(110,250)]
paw_r=[(218,240),(213,218),(214,200),(227,190),(244,192),(256,207),(260,226),(248,242),(231,245)]
foot_l=[(144,350),(128,362),(118,379),(115,397),(123,410),(137,410),(150,397),(162,372)]
foot_r=[(254,362),(266,344),(283,343),(293,356),(297,380),(287,394),(268,398),(257,384)]
muzzle=[(133,159),(141,147),(153,141),(166,150),(180,127),(196,131),(195,158),(191,197),(166,203),(159,174),(150,176),(140,170)]
tooth_l=[(159,174,'c'),(173,156,'c'),(183,197,'c'),(166,203,'c')]
tooth_r=[(173,156,'c'),(190,159,'c'),(191,197,'c'),(183,197,'c')]
nose=[(167,123),(178,126),(182,136),(178,146),(168,150),(157,147),(152,137),(156,127)]
parts=[]
parts.append('<g id="part-tail">'+shape(tail_outline,TAIL)+''.join(line(h,sw=7) for h in hatch)+'</g>')
b=shape(ear_l,BODY,closed=True)+shape(ear_l_in+[(114,68),(104,80)],WHITE,stroke=None)+line(ear_l_in,sw=7)
b+=shape(ear_r,BODY)+shape(ear_r_in+[(255,64),(243,54)],WHITE,stroke=None)+line(ear_r_in,sw=7)
b+=shape(foot_l,BODY)+shape(foot_r,BODY)
b+=shape(body,BODY)
b+=line([(120,400),(129,387)],5)+line([(128,404),(137,389)],5)+line([(136,404),(144,392)],5)
b+=line([(270,373),(271,393)],5)+line([(278,369),(280,393)],5)+line([(286,370),(288,388)],5)
# face
b+=ellipse(112,144,17.5,16.5,BLACK,sw=4,rot=20)+ellipse(102.5,136,6.5,4,WHITE,sw=3,rot=-10)
b+=ellipse(214,116,16.5,19,BLACK,sw=4,rot=-10)+ellipse(212,107,5,3.5,WHITE,sw=2.5,rot=-10)
b+=ellipse(223,137,2.5,3,BLACK,sw=2)
parts.append('<g id="part-body">'+b+'</g>')
lg=shape(log,LOG)+line(log_end,sw=7)
mz=shape(muzzle,WHITE,stroke=None)+shape(tooth_l,WHITE,sw=7)+shape(tooth_r,WHITE,sw=7)+line([(133,159),(140,170),(150,176),(159,174)],sw=7)
mz+=line([(196,131),(195,158),(190,159)],sw=7)+shape(nose,WHITE,sw=7)
parts.append('<g id="part-log">'+lg+'</g>')
parts.append('<g id="part-face">'+mz+'</g>')
pw=shape(paw_l,BODY)+line([(112,216),(112,232)],5.5)+line([(120,214),(120,233)],5.5)+line([(128,215),(128,232)],5.5)
pw+=shape(paw_r,BODY)+line([(223,195),(222,213)],5.5)+line([(232,193),(232,213)],5.5)+line([(241,195),(241,213)],5.5)
parts.append('<g id="part-paws">'+pw+'</g>')
print(finalize('beaver','\n'.join(parts),(380,424)))
