import math, subprocess, os
OUT='#1a1a1a'
def _pts(P): return [(p[0],p[1],len(p)>2 and p[2]=='c') for p in P]
def path(P, closed=True, t=0.5):
    """Catmull-Rom through points -> cubic beziers. A point (x,y,'c') is a sharp corner."""
    P=_pts(P); n=len(P)
    def get(i):
        if closed: return P[i%n]
        return P[max(0,min(n-1,i))]
    d='M%.1f %.1f'%(P[0][0],P[0][1])
    segs=n if closed else n-1
    for i in range(segs):
        p0,p1,p2,p3=get(i-1),get(i),get(i+1),get(i+2)
        k=t/3*2/1  # scale
        if p1[2]: c1=(p1[0],p1[1])
        else: c1=(p1[0]+(p2[0]-p0[0])*t/3, p1[1]+(p2[1]-p0[1])*t/3)
        if p2[2]: c2=(p2[0],p2[1])
        else: c2=(p2[0]-(p3[0]-p1[0])*t/3, p2[1]-(p3[1]-p1[1])*t/3)
        d+=' C%.1f %.1f %.1f %.1f %.1f %.1f'%(c1[0],c1[1],c2[0],c2[1],p2[0],p2[1])
    if closed: d+=' Z'
    return d
def shape(P, fill, sw=9, closed=True, stroke=OUT, extra=''):
    s='stroke="%s" stroke-width="%s"'%(stroke,sw) if stroke else 'stroke="none"'
    return '<path d="%s" fill="%s" %s %s/>'%(path(P,closed),fill if closed else 'none',s,extra)
def line(P, sw=9, stroke=OUT):
    return '<path d="%s" fill="none" stroke="%s" stroke-width="%s"/>'%(path(P,False),stroke,sw)
def ellipse(cx,cy,rx,ry,fill,sw=9,rot=0,wob=0.04,stroke=OUT,n=8):
    pts=[]
    for i in range(n):
        a=2*math.pi*i/n
        w=1+wob*math.sin(3*a+1.3)
        x,y=rx*w*math.cos(a),ry*w*math.sin(a)
        r=math.radians(rot)
        pts.append((cx+x*math.cos(r)-y*math.sin(r), cy+x*math.sin(r)+y*math.cos(r)))
    return shape(pts,fill,sw,stroke=stroke)
def bbox_of(svgfile):
    pass
def doc(body, vb):
    x,y,w,h=vb
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="%.0f %.0f %.0f %.0f" width="%.0f" height="%.0f">\n'
            '<g stroke-linecap="round" stroke-linejoin="round">\n%s\n</g>\n</svg>\n')%(x,y,w,h,w,h,body)
def render(svg, png, long=1024):
    import re
    m=re.search(r'viewBox="([\d\.\- ]+)"',open(svg).read()); x,y,w,h=map(float,m.group(1).split())
    if w>=h: a=['-w',str(long)]
    else: a=['-h',str(long)]
    subprocess.run(['rsvg-convert',*a,'-a','-b','none',svg,'-o',png],check=True)

ASSET='/home/claude/game/assets'
def finalize(name, body, work_wh=(600,600)):
    """write work svg (photo-unit space), compute tight bbox, write final svg + png."""
    import numpy as np
    from PIL import Image
    W,H=work_wh
    tmp='/tmp/flat_%s_work.svg'%name
    open(tmp,'w').write(doc(body,(-50,-50,W+100,H+100)))
    subprocess.run(['rsvg-convert','-z','4','-b','none',tmp,'-o','/tmp/flat_%s_work.png'%name],check=True)
    a=np.array(Image.open('/tmp/flat_%s_work.png'%name))[...,3]
    ys,xs=np.nonzero(a>0)
    x0,x1=xs.min()/4-50,(xs.max()+1)/4-50; y0,y1=ys.min()/4-50,(ys.max()+1)/4-50
    vb=(math.floor(x0-12),math.floor(y0-12),math.ceil(x1-x0+24),math.ceil(y1-y0+24))
    f='%s/svg/%s.svg'%(ASSET,name)
    open(f,'w').write(doc(body,vb))
    render(f,'%s/png/%s.png'%(ASSET,name))
    # work-space render for overlays
    open('/tmp/flat_%s_ws.svg'%name,'w').write(doc(body,(0,0,W,H)))
    return vb
