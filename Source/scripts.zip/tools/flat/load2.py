import pillow_heif; pillow_heif.register_heif_opener()
from PIL import Image, ImageOps
D='/mnt/user-data/uploads/Video Game for Elliot/'
for n,rot in [('IMG_3531',-90),('IMG_3532',-90),('IMG_3533',90)]:
    im=ImageOps.exif_transpose(Image.open(D+n+'.HEIC')).convert('RGB')
    print(n, im.size)
    up=im.rotate(rot,expand=True)
    up.save(f'/home/claude/game/assets/crops/{n}_up.png')
    t=up.copy(); t.thumbnail((900,1200)); t.save(f'/home/claude/game/assets/crops/{n}_upview.jpg',quality=88)
