import re, subprocess, sys
sys.path.insert(0,'/home/claude/game/tools/flat')
from PIL import Image, ImageDraw
from uview import photo_units
A='/home/claude/game/assets'
items=[('frank_f','frankenstein_folded'),('frank_u','frankenstein_unfolded'),('crab','crab'),('frank_u','fx_bat1'),('frank_u','fx_bat2'),
       ('frank_u','fx_candy1'),('frank_u','fx_candy2'),('crab','fx_crab_scribble')]
H=520; rows=[]
for ch,name in items:
    x,y,w,h=map(float,re.search(r'viewBox="([^"]+)"',open(f'{A}/svg/{name}.svg').read()).group(1).split())
    if name=='frankenstein_folded':
        im=Image.open('/home/claude/game/assets/crops/IMG_3531_up.png'); f=4284/900
        ph=im.crop(tuple(int(v*f) for v in (190,375,575,905)))
    else:
        im,x0,y0,s=photo_units(ch); tp=lambda u,o: (u-12)/s+o
        ph=im.crop((int(tp(x,x0)),int(tp(y,y0)),int(tp(x+w,x0)),int(tp(y+h,y0))))
    hh=H if name!='frankenstein_unfolded' else 900
    sc=hh/max(ph.height, ph.width*0.8); ph=ph.resize((int(ph.width*sc),int(ph.height*sc)))
    subprocess.run(['rsvg-convert','-h',str(ph.height),f'{A}/svg/{name}.svg','-o','/tmp/flat_cmp2.png'],check=True)
    sv=Image.open('/tmp/flat_cmp2.png').convert('RGBA')
    wbg=Image.new('RGBA',sv.size,'white'); wbg.alpha_composite(sv)
    dbg=Image.new('RGBA',sv.size,(30,34,48,255)); dbg.alpha_composite(sv)
    rows.append((name,ph,wbg.convert('RGB'),dbg.convert('RGB')))
def sheet(cols,out,labels):
    W=max(sum(r[c].width for c in cols)+20*len(cols)+20 for r in rows)
    Ht=sum(max(r[c].height for c in cols)+40 for r in rows)
    S=Image.new('RGB',(W,Ht),(235,235,235)); d=ImageDraw.Draw(S); yy=0
    for r in rows:
        d.text((10,yy+5),r[0]+'   '+labels,fill='black'); xx=10
        for c in cols: S.paste(r[c],(xx,yy+25)); xx+=r[c].width+20
        yy+=max(r[c].height for c in cols)+40
    S.save(out)
sheet([1,2],f'{A}/compare_frankenstein_crab.png','(photo | redraw)')
sheet([2,3],f'{A}/crops/dark_check_frank_crab.png','(white | dark bg)')
