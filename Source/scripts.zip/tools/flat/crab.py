import sys, math; sys.path.insert(0,'/home/claude/game/tools/flat')
from svgkit import *
RED='#c42a2f'; HAT='#8f4a22'; CROWN='#a65f2e'; BLACK='#1a1a1a'; WHITE='#fbfaf6'
def seg(a,b,w,tip=False,bulge=0.0):
    """hand-ish oval (or teardrop if tip) from point a to point b, width w"""
    ax,ay=a; bx,by=b; L=math.hypot(bx-ax,by-ay); ux,uy=(bx-ax)/L,(by-ay)/L; nx,ny=-uy,ux
    prof=[(0,0.0),(0.12,0.38),(0.35,0.5),(0.6,0.48),(0.85,0.32),(1,0.0)] if not tip else [(0,0.0),(0.1,0.42),(0.3,0.5),(0.55,0.42),(0.8,0.2),(1,0)]
    pts=[]
    for t,h in prof:  # one side
        pts.append((ax+ux*L*t+nx*w*h*(1+bulge),ay+uy*L*t+ny*w*h*(1+bulge)))
    for t,h in reversed(prof[1:-1]):
        pts.append((ax+ux*L*t-nx*w*h,ay+uy*L*t-ny*w*h))
    if tip: pts[5]=(bx,by,'c')
    return pts
def star(cx,cy,R,r,rot=-90):
    P=[]
    for k in range(10):
        a=math.radians(rot+36*k); rr=R if k%2==0 else r
        P.append((cx+rr*math.cos(a),cy+rr*math.sin(a),'c'))
    return P
def leg(gid,upper,lower):
    return '<g id="%s">'%gid+shape(lower[0],RED)+shape(upper,RED)+'</g>'
legs=[]
legs.append(('leg-l1',seg((118,214),(86,238),24),(seg((90,236),(20,300),18,tip=True),)))
legs.append(('leg-l2',seg((125,222),(98,250),26),(seg((100,242),(48,292),24),)))
legs.append(('leg-l3',seg((150,240),(118,262),30),(seg((140,262),(117,335),48,tip=True),)))
legs.append(('leg-r1',seg((222,215),(250,258),40),(seg((250,256),(242,337),52,tip=True),)))
legs.append(('leg-r2',seg((243,200),(262,228),26),(seg((268,220),(283,278),22,tip=True),)))
legs.append(('leg-r3',seg((288,212),(312,252),36),(seg((312,246),(316,290),24,tip=True),)))
parts=[]
for gid,u,l in legs: parts.append(leg(gid,u,l))
# claws
cl='<g id="claw-left">'+shape(seg((108,214),(108,178),34),RED)+shape(seg((96,206),(68,172),36),RED)
pin=seg((84,174),(62,106),38); cl+=shape(pin,RED)+line([(62,108),(67,121)],6)+'</g>'
cr='<g id="claw-right">'+shape(seg((262,206),(292,178),36),RED)+shape(seg((285,200),(325,172),38),RED)+shape(seg((298,176),(297,128),30),RED)
cr+=ellipse(294,112,7,7,RED,sw=7)
pin=seg((330,195),(346,119),40); cr+=shape(pin,RED)+line([(346,121),(341,135)],6)+'</g>'
parts+= [cl,cr]
body=[(137,83),(121,108),(112,142),(115,175),(125,196),(150,217),(179,227),(212,225),(242,208),(267,183),(283,154),(292,125),(290,100),(270,92),(220,100),(170,95)]
bd=shape(body,RED)+line([(125,175),(150,181),(172,186),(179,179,'c'),(185,188),(205,182),(233,167),(267,146),(292,125)],7)
bd+=ellipse(148,129,15.5,17.5,BLACK,sw=4,rot=10,wob=0.04)+ellipse(143,120,4,3,WHITE,stroke=None,rot=-20)
bd+=ellipse(229,129,22,18,BLACK,sw=4,rot=-5,wob=0.04)+ellipse(218,119,4,3.2,WHITE,stroke=None,rot=-20)
bd+=line([(176,155),(178,161),(185,164),(194,157)],5)
parts.append('<g id="part-body">'+bd+'</g>')
hat=shape([(130,92),(128,70),(134,58),(142,55),(152,60),(160,72),(162,88)],HAT)
hat+=shape([(258,86),(262,66),(275,57),(290,53),(298,62),(298,84),(290,100),(276,104)],HAT)
hat+=shape([(164,71,'c'),(173,58),(187,36),(197,16,'c'),(203,25,'c'),(211,16,'c'),(218,25),(229,38),(244,56),(258,72,'c'),(230,72),(200,76)],CROWN)
hat+=shape([(158,84,'c'),(185,77),(215,74),(250,71),(262,80,'c'),(253,94),(220,103),(187,101)],HAT)
hat+=line([(182,52),(203,49),(224,47)],5)
hat+=shape(star(208,63,14,6),BLACK,3)
parts.append('<g id="part-hat">'+hat+'</g>')
print(finalize('crab','\n'.join(parts),(380,400)))
