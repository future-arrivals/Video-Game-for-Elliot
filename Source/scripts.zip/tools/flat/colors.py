import json, numpy as np
from PIL import Image
from uview import photo_units
def samp(ch, pts, paper):
    im,x0,y0,s=photo_units(ch); a=np.asarray(im).astype(float)
    tp=lambda u,o: int((u-12)/s+o)
    def med(u,v,r):
        X,Y=tp(u,x0),tp(v,y0); R=int(r/s)
        return np.median(a[Y-R:Y+R,X-R:X+R].reshape(-1,3),axis=0)
    p=med(*paper)
    for n,(u,v,r) in pts.items():
        c=med(u,v,r); wb=np.clip(c*245/p,0,255)
        print(ch,n,'raw #%02x%02x%02x'%tuple(c.astype(int)),'wb #%02x%02x%02x'%tuple(wb.astype(int)))
samp('firecat',{'orange':(70,110,6),'orange2':(130,150,5),'yellow':(85,145,6),'grey':(100,360,5)},(170,300,8))
samp('beaver',{'body':(200,300,10),'body2':(150,80,8),'log':(260,190,8),'log2':(90,215,6),'tail':(58,345,4),'paw':(240,225,4)},(330,300,8))
samp('owl',{'body':(110,300,10),'body2':(190,140,6),'yellow':(110,200,6),'red':(150,185,5),'red2':(85,190,4),'beak':(112,160,2),'stalk':(100,45,3),'leaf':(137,25,3),'wing':(205,280,4),'slice':(180,368,3)},(30,380,8))
samp('juice',{'front':(120,270,10),'top':(150,115,6),'side':(225,250,8),'apple':(110,200,8),'straw':(87,90,4),'mouthfill':(115,372,2)},(250,60,8))
