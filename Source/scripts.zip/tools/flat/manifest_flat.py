import re, json
A='/home/claude/game/assets'
info={
 'firecat':('Fire cat (son\'s name). Best reading: a white block/marshmallow-like creature standing upright with its head on fire; two dot eyes, big glossy black nose/mouth, two grey curled cheeks/whiskers, grey bottom with a frown line and two stubby grey legs','front','Upright = flame on top (page orientation of the sheet, matching the Elliot signature). Flame part can flicker independently.',None),
 'beaver':('Beaver chewing a log','front','Tail sits on its left (viewer\'s left). Safe to mirror.',None),
 'orangeowl':('Orange owl: an orange fruit with an owl face mask, stalk and leaf, plus an orange-slice wheel at its bottom right','front','Wing (part-wing) on viewer\'s right, small wing nub on left. Safe to mirror.',None),
 'juicebox':('Green apple juice box with a bent blue straw','front-left','3/4 view: front panel faces the viewer, dark-green side panel visible on the right, straw bends to the left. Flip horizontally to face right.',None),
 'fx_flame':('Effect: the fire cat\'s flame on its own (same coordinates/scale as firecat part-flame)','none','Same scale as the characters.',1.0),
 'fx_orangeslice':('Effect: the orange-slice wheel from the orange owl','none','Drawn at 3x the owl\'s scale so outlines stay readable; draw at scale 0.33 to match the owl, or larger as a projectile.',0.33),
 'fx_woodchips':('Effect: wood chips / shavings from around the beaver (10 pieces, each its own group chip-1..chip-10 for scattering)','none','Drawn at 2x the beaver\'s scale; draw at scale 0.5 to match the beaver.',0.5),
}
out={'scale_note':'Characters are ~400 SVG units on their long side; stroke #1a1a1a, width 9 (characters) / 5-7 (small details and effects). PNGs are 1024 px on the long side, transparent.','sprites':[]}
for n,(ch,face,note,sc) in info.items():
    s=open(f'{A}/svg/{n}.svg').read()
    x,y,w,h=map(float,re.search(r'viewBox="([^"]+)"',s).group(1).split())
    e={'file':f'svg/{n}.svg','png':f'png/{n}.png','character':ch,'viewBox':[x,y,w,h],'viewBox_size':[w,h],
       'part_ids':re.findall(r'<g id="([^"]+)"',s),'facing':face,'notes':note}
    if sc: e['suggested_draw_scale_vs_characters']=sc
    out['sprites'].append(e)
json.dump(out,open(f'{A}/manifest_flat_characters.json','w'),indent=1)
print(json.dumps([(e['file'],e['viewBox_size'],e['part_ids']) for e in out['sprites']]))
