import cv2,sys,numpy as np
W='/home/claude/game/work'
n=sys.argv[1]; x0,y0,x1,y1=map(int,sys.argv[2].split(',')); step=int(sys.argv[3]); out=sys.argv[4]
im=cv2.imread(f'{W}/flat_{n}.png')[y0:y1,x0:x1].copy()
sc=min(1.0,1400/max(im.shape[:2])); im=cv2.resize(im,None,fx=sc,fy=sc,interpolation=cv2.INTER_AREA)
for x in range((x0//step+1)*step,x1,step):
    X=int((x-x0)*sc); cv2.line(im,(X,0),(X,im.shape[0]),(255,0,255) if x%(step*5)==0 else (255,150,255),1)
    cv2.putText(im,str(x),(X+2,12),cv2.FONT_HERSHEY_SIMPLEX,0.4,(200,0,200),1)
for y in range((y0//step+1)*step,y1,step):
    Y=int((y-y0)*sc); cv2.line(im,(0,Y),(im.shape[1],Y),(255,0,255) if y%(step*5)==0 else (255,150,255),1)
    cv2.putText(im,str(y),(2,Y-2),cv2.FONT_HERSHEY_SIMPLEX,0.4,(200,0,200),1)
cv2.imwrite(f'{W}/{out}.jpg',im)
