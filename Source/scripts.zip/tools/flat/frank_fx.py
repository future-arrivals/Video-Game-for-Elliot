import sys; sys.path.insert(0,'/home/claude/game/tools/flat')
from svgkit import *
BAT='#3a3a3a'
# bats: coordinates in the unfolded-sheet unit space (same scale as frankenstein)
bat1=[(303,348,'c'),(342,316,'c'),(366,343,'c'),(396,309,'c'),(405,347,'c'),(435,311,'c'),(446,345,'c'),(492,318,'c'),(508,373,'c'),(470,366,'c'),(478,416,'c'),(437,389,'c'),(383,450,'c'),(378,364,'c'),(317,405,'c'),(346,360,'c')]
bat2=[(287,548,'c'),(324,484,'c'),(360,543,'c'),(392,500,'c'),(394,550,'c'),(419,507,'c'),(426,559,'c'),(496,532,'c'),(510,602,'c'),(489,572,'c'),(485,636,'c'),(458,590,'c'),(426,582,'c'),(394,677,'c'),(340,610,'c')]
print('bat1',finalize('fx_bat1','<g id="part-bat">'+shape(bat1,BAT,7)+'</g>',(560,720)))
print('bat2',finalize('fx_bat2','<g id="part-bat">'+shape(bat2,BAT,7)+'</g>',(560,720)))
# candies: drawn by him in orange marker only, so outlined in darker orange (no black)
C='#f26a26'; CO='#c9461a'
def cshape(P): return shape(P,C,6,stroke=CO)
c1=cshape([(-25,67),(-2,60),(20,66),(33,76,'c'),(30,95),(32,108,'c'),(12,108),(-2,126),(-13,135),(-18,120),(-11,95),(-20,85)])
c1+=cshape([(71,76,'c'),(89,60),(116,63),(125,81),(110,90),(128,101),(121,110),(108,112),(110,124),(107,142),(94,138),(80,115),(71,99,'c')])
c1+=ellipse(52,84,20,22,C,sw=6,stroke=CO,wob=0.04)
print('candy1',finalize('fx_candy1','<g id="part-candy">'+c1+'</g>',(160,160)))
c2=cshape([(-38,406,'c'),(-6,447,'c'),(-52,490,'c')])+cshape([(75,406,'c'),(91,483,'c'),(46,447,'c')])
c2+=ellipse(21,448,27,19,C,sw=6,stroke=CO,wob=0.04)+line([(14,433),(24,447),(16,462)],5,stroke=CO)
print('candy2',finalize('fx_candy2','<g id="part-candy">'+c2+'</g>',(120,520)))
