import pillow_heif; pillow_heif.register_heif_opener()
from PIL import Image, ImageOps
import sys
for n in ['fc83bbd6-IMG_3525','e7b72cf5-IMG_3530']:
    im=ImageOps.exif_transpose(Image.open(f'/mnt/user-data/uploads/{n}.HEIC')).convert('RGB')
    print(n, im.size)
    im.save(f'/home/claude/game/assets/crops/{n.split("-")[1]}_full.png')
