from trace import *
im,s,pad=load('/home/claude/game/assets/crops/cat_up.png',(46,40,650,1363))
H=hsv(im); h,S,V=H[...,0],H[...,1],H[...,2]
dark=(V<95)
orange=(h<=18)&(S>110)&(V>120)
yellow=(h>18)&(h<=35)&(S>90)&(V>120)
grey=(S<45)&(V>95)&(V<185)
k=lambda r: cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*r+1,2*r+1))
anyink=(dark|orange|yellow|grey).astype(np.uint8)
anyink=cv2.morphologyEx(anyink,cv2.MORPH_CLOSE,k(6))
sil=ndi.binary_fill_holes(anyink)
sil=cv2.morphologyEx(sil.astype(np.uint8),cv2.MORPH_OPEN,k(8))
hw=int(3/s)
print('scale',s,'size',im.shape[1]*s,im.shape[0]*s)
res={}
res['sil']=contours(cv2.erode(sil,k(hw)),s,pad,eps=1.5,minarea=500)
fl=cv2.morphologyEx((orange|yellow).astype(np.uint8),cv2.MORPH_CLOSE,k(10))
res['flame']=contours(cv2.dilate(fl,k(hw)),s,pad,eps=1.5,minarea=200)
y=cv2.morphologyEx(yellow.astype(np.uint8),cv2.MORPH_CLOSE,k(10))
res['yellow']=contours(cv2.dilate(y,k(hw)),s,pad,eps=1.5,minarea=100)
g=cv2.morphologyEx(grey.astype(np.uint8),cv2.MORPH_OPEN,k(4))
g=cv2.morphologyEx(g,cv2.MORPH_CLOSE,k(10))
res['grey']=contours(g,s,pad,eps=1.5,minarea=60)
# dark interior blobs (filled)
d=cv2.morphologyEx(dark.astype(np.uint8),cv2.MORPH_OPEN,k(3))
n,lab,st,cen=cv2.connectedComponentsWithStats(d)
blobs=[]
for i in range(1,n):
    x,yy,w,hh,a=st[i]
    if a*s*s<4 or a*s*s>400: continue
    blobs.append(dict(cx=round(cen[i][0]*s+pad,1),cy=round(cen[i][1]*s+pad,1),w=round(w*s,1),h=round(hh*s,1),a=round(a*s*s,1)))
res['blobs']=blobs
res['col']=dict(orange=sample(im,orange),yellow=sample(im,yellow),grey=sample(im,grey&~dark),white=sample(im,sil.astype(bool)&(S<25)&(V>185)),dark=sample(im,dark))
for kk,v in res.items(): print(kk, json.dumps(v))
