import sys, math; sys.path.insert(0,'/home/claude/game/tools/flat')
from svgkit import *
OR='#d98a45'; BR='#b5602a'
def ln(P,col,w): return '<path d="%s" fill="none" stroke="%s" stroke-width="%s"/>'%(path(P,False),col,w)
def loops(cx,cy,rx,ry,n,drift,rot=0,ph=0):
    P=[]
    for k in range(n*8+1):
        a=2*math.pi*k/8+ph; t=k/(n*8)
        x=rx*math.cos(a)+drift[0]*t; y=ry*math.sin(a)+drift[1]*t
        r=math.radians(rot); P.append((cx+x*math.cos(r)-y*math.sin(r),cy+x*math.sin(r)+y*math.cos(r)))
    return P
L=[]
# big sweeping outline loop around the crab's base
L.append([(58,192),(30,215),(17,242),(8,297),(25,347),(62,376),(125,397),(187,403),(250,388),(317,363),(367,317),(383,255),(375,200),(371,160)])
L.append(loops(42,232,20,30,3,(16,-18),rot=15))
L.append(loops(30,300,12,22,2,(8,10),rot=-20,ph=2))
L.append(loops(150,330,10,30,2,(14,-6),rot=10,ph=1))
L.append(loops(240,260,8,34,2,(6,4),rot=-6,ph=2))
L.append(loops(75,350,22,14,3,(40,6),rot=-10,ph=1))
L.append(loops(110,365,14,10,2,(22,0)))
L.append(loops(198,300,9,40,2,(10,0),rot=8,ph=0.5))
L.append(loops(95,360,26,13,3,(30,8),rot=-5,ph=0.3))
L.append(loops(160,370,16,11,3,(40,4),rot=5,ph=1.2))
L.append(loops(60,250,14,18,2,(12,20),rot=30,ph=2.2))
L.append(loops(290,330,12,28,2,(20,-8),rot=40,ph=0.7))
L.append([(250,350),(290,318),(262,345),(310,312),(278,343),(330,300),(300,334),(352,290)])
L.append([(150,385),(200,372),(170,388),(232,366),(205,384),(262,362)])
H=[]
for k in range(9): H.append([(128+7*k,332-6*(k%2)),(142+7*k,240+5*(k%3))])
for k in range(5): H.append([(332+7*k,278-4*(k%2)),(338+7*k,198+6*(k%2))])
for k in range(12): H.append([(168+14*k,384-3*k),(212+14*k,348-3*k-(k%3)*3)])
body='<g id="scribble-line">'+''.join(ln(p,OR,3.5) for p in L)+'</g>\n<g id="scribble-hatch">'+''.join(ln(p,BR,5) for p in H)+'</g>'
print(finalize('fx_crab_scribble',body,(400,420)))
