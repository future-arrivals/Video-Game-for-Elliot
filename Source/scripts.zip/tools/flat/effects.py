from svgkit import *
import math, re
src=open('/home/claude/game/tools/flat/firecat.py').read()
ns={}
exec(re.search(r"(WHITE=.*?\n)",src).group(1),ns)
exec(re.search(r"(flame_outer=\[.*?\]\n)",src,re.S).group(1),ns)
exec(re.search(r"(inner=\[.*?\]\n)",src,re.S).group(1),ns)
fl='<g id="part-flame">'+shape(ns['flame_outer'],ns['ORANGE'])+shape(ns['inner'],ns['YELLOW'])+'</g>'
print('flame',finalize('fx_flame',fl,(210,210)))

# ---- orange slice (from the orange owl), same scale as the owl ----
SLICE='#f8b23a'
# drawn at 3x the owl's scale so the outline doesn't swamp it
sl=ellipse(60,60,43.5,40.5,SLICE,sw=7,wob=0.03)
for k in range(4):
    a=math.pi*k/4+0.2; dx,dy=36*math.cos(a),33*math.sin(a)
    sl+=line([(60-dx,60-dy),(60,60),(60+dx,60+dy)],6)
print('slice',finalize('fx_orangeslice','<g id="part-slice">'+sl+'</g>',(120,120)))

# ---- wood chips (from the marks around the beaver), drawn at 2x the beaver's scale ----
OR='#e8743a'; BR='#8a5a3b'; RB='#b4532e'
def tube(P,col,w=7):  # outlined marker squiggle: black under-stroke + colour stroke
    d=path(P,False)
    return ('<path d="%s" fill="none" stroke="%s" stroke-width="%s"/>'%(d,OUT,w+10))+('<path d="%s" fill="none" stroke="%s" stroke-width="%s"/>'%(d,col,w))
chips=[]
# 1 tall orange squiggle (left of tail)
chips.append(tube([(30,22),(46,14),(34,34),(22,52),(40,48),(30,70),(18,86),(26,100),(42,96),(36,82),(22,98),(30,120),(44,140),(40,160),(26,186)],OR))
# 2 orange jagged sliver
chips.append(shape([(20,196),(30,186),(38,190),(46,176),(54,182),(60,168),(66,174),(52,226),(44,222),(36,236),(26,232),(18,246)],OR,sw=7))
# 3 orange rectangular chip
chips.append(shape([(84,180,'c'),(108,174,'c'),(100,264,'c'),(78,262,'c')],OR,sw=7))
# 4 brown zigzag
chips.append(shape([(136,312),(142,294),(150,306),(158,288),(166,304),(176,290),(184,306),(194,294),(200,308),(214,302),(216,316),(150,322)],BR,sw=7))
# 5 orange W curl
chips.append(shape([(250,276),(262,262),(270,286),(284,274),(296,290),(310,286),(306,300),(286,302),(272,300),(258,298)],OR,sw=7))
# 6 brown splinter
chips.append(shape([(316,230),(330,170),(338,166),(332,200),(326,236)],BR,sw=7))
# 7 red-brown jagged chip
chips.append(shape([(380,148),(392,140),(398,156),(394,176),(402,196),(398,226),(386,222),(378,196),(384,176)],RB,sw=7))
# 8 brown striped block
chips.append(shape([(330,110,'c'),(356,108,'c'),(362,154,'c'),(338,156,'c')],BR,sw=7)+line([(342,118),(348,150)],5))
# 9 orange V flick
chips.append(shape([(430,110),(438,112),(446,140),(458,158),(450,162),(438,146),(432,128)],OR,sw=7))
# 10 brown twig with a small branch
chips.append(shape([(420,214,'c'),(432,212),(426,270),(414,298,'c'),(404,296),(414,262)],BR,sw=7)+line([(424,226),(408,214)],6))
body='\n'.join('<g id="chip-%d">%s</g>'%(i+1,c) for i,c in enumerate(chips))
print('chips',finalize('fx_woodchips',body,(480,340)))
