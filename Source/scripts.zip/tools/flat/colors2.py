import sys; sys.path.insert(0,'/home/claude/game/tools/flat')
import numpy as np
from uview import photo_units
def samp(ch, pts, paper):
    im,x0,y0,s=photo_units(ch); a=np.asarray(im).astype(float)
    tp=lambda u,o: int((u-12)/s+o)
    def med(u,v,r):
        X,Y=tp(u,x0),tp(v,y0); R=max(2,int(r/s))
        return np.median(a[Y-R:Y+R,X-R:X+R].reshape(-1,3),axis=0)
    p=med(*paper)
    for n,(u,v,r) in pts.items():
        c=med(u,v,r); wb=np.clip(c*245/p,0,255)
        print(ch,n,'raw #%02x%02x%02x'%tuple(c.astype(int)),'wb #%02x%02x%02x'%tuple(wb.astype(int)))
samp('frank_u',{'head':(240,160,6),'inside':(115,450,4),'inside2':(260,500,6),'red':(150,500,5),'purple':(230,800,6),'stripe':(160,780,4),'grey':(105,186,3),'hand':(300,790,3),'neck':(200,670,8),'bat':(400,400,6),'candy':(51,82,6)},(40,300,6))
samp('crab',{'body':(200,205,6),'leg':(245,300,6),'hat':(200,92,4),'crown':(225,40,3),'scrib':(155,280,4)},(360,60,8))
