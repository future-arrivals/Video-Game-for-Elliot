# gentrace.py char  -> print colour-region contours (dilated to line centre) in unit coords
import sys, json
from trace import *
CH=json.load(open('/home/claude/game/tools/chars.json'))
ch=sys.argv[1]; c=CH[ch]
im,s,pad=load(c['src'],c['bbox'])
H=hsv(im); h,S,V=H[...,0],H[...,1],H[...,2]
k=lambda r: cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*r+1,2*r+1))
hw=max(1,int(3/s))
regions=eval(sys.argv[2])  # dict name -> boolean expr string
eps=float(sys.argv[3]) if len(sys.argv)>3 else 2.0
for name,expr in regions.items():
    m=eval(expr).astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_OPEN,k(3)); m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,k(int(4/s)))
    m=ndi.binary_fill_holes(m).astype(np.uint8)
    cs=contours(cv2.dilate(m,k(hw)),s,pad,eps=eps,minarea=40)
    print(name, sample(im,eval(expr)))
    for cc in cs: print('  ',len(cc),json.dumps([tuple(map(round,p)) for p in cc]))
