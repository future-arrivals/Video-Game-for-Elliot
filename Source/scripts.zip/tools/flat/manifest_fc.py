import re, json
A='/home/claude/game/assets'
info={
 'frankenstein_folded':('Frankenstein monster, folded (closed) state','front',None),
 'frankenstein_unfolded':('Frankenstein monster, unfolded: head and body pulled apart to reveal a long green inside with a giant open red mouth, rows of thin teeth top and bottom, a long red tongue and a black two-lobed shape at the back of the throat','front',None),
 'crab':('Red crab in a brown cowboy hat with a black star','front',None),
 'fx_bat1':('Doodle: black spiky bat (upper one on the Frankenstein sheet)','none',1.0),
 'fx_bat2':('Doodle: black spiky bat (lower one)','none',1.0),
 'fx_candy1':('Doodle: orange wrapped candy with lumpy crinkled wrapper ends (top-left of the sheet). Outlined in darker orange, not black, as he drew it in orange only','none',1.0),
 'fx_candy2':('Doodle: orange wrapped candy with triangular wrapper ends (mid-left of the sheet). Outlined in darker orange, not black','none',1.0),
 'fx_crab_scribble':('Effect: the loose orange line scribble and brown hatching around the crab (sand/dust kicked up). Coloured line only, no black outline. Groups: scribble-line (orange), scribble-hatch (brown)','none',1.0),
}
out={'scale_note':'Same unit system as the flat set: frankenstein_folded is ~430 units tall; the unfolded version is the same scale (~850 tall). Bats and candies are at the same scale as the Frankenstein monster; scribble at the crab\'s scale.',
 'frankenstein_hinge':{
   'hinge_line_y':205,'hinge_x_range':[97,315],
   'inside_span_y':[205,622],'inside_length':417,
   'description':'Hinge is the bottom edge of the head (y=205 in both files). In frankenstein_unfolded, part-inside spans y 205..622 and part-body starts at y 622. In frankenstein_folded, part-body has transform translate(0,-417) so its top edge meets the head at y=205, and part-inside is omitted. Geometry of part-head and part-body is identical in both files.',
   'animate':'To unfold by fraction t (0..1): scale part-inside by (1, t) about y=205 (or reveal/clip it from y=205 down to 205+417*t), and translate part-body by (0, -417*(1-t)). Draw order: part-inside, part-body, part-head.'},
 'sprites':[]}
for n,(ch,face,sc) in info.items():
    s=open(f'{A}/svg/{n}.svg').read()
    x,y,w,h=map(float,re.search(r'viewBox="([^"]+)"',s).group(1).split())
    e={'file':f'svg/{n}.svg','png':f'png/{n}.png','character':ch,'viewBox':[x,y,w,h],'viewBox_size':[w,h],
       'part_ids':re.findall(r'<g id="([^"]+)"',s),'facing':face}
    if n=='crab': e['notes']='Facing the viewer; symmetric enough to flip. Wiggle groups: claw-left, claw-right, leg-l1..l3, leg-r1..r3 (each leg = upper segment + pointed lower segment). part-hat sits on top of part-body.'
    if n.startswith('frankenstein'): e['notes']='Front-facing; flip-safe. See frankenstein_hinge.'
    if sc: e['suggested_draw_scale_vs_characters']=sc
    out['sprites'].append(e)
json.dump(out,open(f'{A}/manifest_frankenstein_crab.json','w'),indent=1)
print(json.dumps([(e['file'],e['viewBox_size'],e['part_ids']) for e in out['sprites']]))
