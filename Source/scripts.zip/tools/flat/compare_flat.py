import re, subprocess, sys
sys.path.insert(0,'/home/claude/game/tools/flat')
from PIL import Image, ImageDraw
from uview import photo_units
A='/home/claude/game/assets'
items=[('firecat','firecat'),('beaver','beaver'),('owl','orangeowl'),('juice','juicebox'),
       ('firecat','fx_flame'),('owl','fx_orangeslice'),('beaver','fx_woodchips')]
H=520; rows=[]
for ch,name in items:
    x,y,w,h=map(float,re.search(r'viewBox="([^"]+)"',open(f'{A}/svg/{name}.svg').read()).group(1).split())
    if name=='fx_orangeslice': x,y,w,h=185-31,374-30,61,59
    if name=='fx_woodchips': x,y,w,h=-60,280,400,280
    im,x0,y0,s=photo_units(ch)
    tp=lambda u,o: (u-12)/s+o
    ph=im.crop((int(tp(x,x0)),int(tp(y,y0)),int(tp(x+w,x0)),int(tp(y+h,y0))))
    sc=H/max(ph.height, ph.width*0.8); ph=ph.resize((int(ph.width*sc),int(ph.height*sc)))
    subprocess.run(['rsvg-convert','-h',str(ph.height),f'{A}/svg/{name}.svg','-o','/tmp/flat_cmp.png'],check=True)
    sv=Image.open('/tmp/flat_cmp.png').convert('RGBA')
    if sv.width>ph.width*1.6:
        subprocess.run(['rsvg-convert','-w',str(ph.width),f'{A}/svg/{name}.svg','-o','/tmp/flat_cmp.png'],check=True); sv=Image.open('/tmp/flat_cmp.png').convert('RGBA')
    wbg=Image.new('RGBA',sv.size,'white'); wbg.alpha_composite(sv)
    dbg=Image.new('RGBA',sv.size,(30,34,48,255)); dbg.alpha_composite(sv)
    rows.append((name,ph,wbg.convert('RGB'),dbg.convert('RGB')))
def sheet(cols,out,labels):
    W=max(sum(r[c].width for c in cols)+20*len(cols)+20 for r in rows)
    Ht=sum(max(r[c].height for c in cols)+40 for r in rows)
    S=Image.new('RGB',(W,Ht),(235,235,235)); d=ImageDraw.Draw(S); yy=0
    for r in rows:
        d.text((10,yy+5),r[0]+'   '+labels,fill='black'); xx=10
        for c in cols: S.paste(r[c],(xx,yy+25)); xx+=r[c].width+20
        yy+=max(r[c].height for c in cols)+40
    S.save(out)
sheet([1,2],f'{A}/compare_flat_characters.png','(photo | redraw)')
sheet([2,3],f'{A}/crops/dark_check_flat.png','(white | dark bg)')
