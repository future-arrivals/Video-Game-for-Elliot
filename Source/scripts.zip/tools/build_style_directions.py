"""Builds /home/claude/game/style/style-directions.html: three art directions, each with an
overworld mockup and a battle mockup at phone-landscape size (844x390), as inline SVG.
Child's drawings are embedded as base64 PNG stand-ins (rough crops from the photos).
Usage: python3 build_style_directions.py <crops_dir> <out_html>"""
import sys, os, base64, math, random
from PIL import Image

CROPS, OUT = sys.argv[1], sys.argv[2]
INK = "#1a1a1a"

# ---------------------------------------------------------------- helpers
LINEART = {"bat", "spider", "ghost", "candy", "lollipop"}
def b64(name, maxpx=260):
    from PIL import ImageFilter, ImageEnhance
    im = Image.open(os.path.join(CROPS, name + ".png")).convert("RGBA")
    im.thumbnail((maxpx, maxpx), Image.LANCZOS)
    if name in LINEART:
        # thin pen doodles: thicken + darken lines, closer to the planned redraw outlines
        a = im.split()[3]
        rgb = ImageEnhance.Contrast(im.convert("RGB")).enhance(1.8).filter(ImageFilter.MinFilter(3))
        im = rgb.convert("RGBA"); im.putalpha(a)
    import io
    buf = io.BytesIO(); im.save(buf, "PNG", optimize=True)
    return im.size, base64.b64encode(buf.getvalue()).decode()

SYMBOLS = []
SIZES = {}
def img_symbol(name, maxpx=260):
    (w, h), data = b64(name, maxpx)
    SIZES[name] = (w, h)
    SYMBOLS.append(f'<symbol id="im-{name}" viewBox="0 0 {w} {h}"><image width="{w}" height="{h}" href="data:image/png;base64,{data}"/></symbol>')

def use(name, cx, by, h, extra=""):
    """place symbol so its bottom-centre sits at (cx, by), height h"""
    w0, h0 = SIZES[name]
    w = h * w0 / h0
    return f'<use href="#im-{name}" x="{cx - w/2:.1f}" y="{by - h:.1f}" width="{w:.1f}" height="{h:.1f}" {extra}/>'

def catmull(pts, closed):
    n = len(pts)
    if n < 3:
        return "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    d = f"M{pts[0][0]:.1f},{pts[0][1]:.1f}"
    rng = range(n if closed else n - 1)
    for i in rng:
        p0 = pts[(i - 1) % n] if (closed or i > 0) else pts[i]
        p1 = pts[i]; p2 = pts[(i + 1) % n]
        p3 = pts[(i + 2) % n] if (closed or i + 2 < n) else p2
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        d += f" C{c1[0]:.1f},{c1[1]:.1f} {c2[0]:.1f},{c2[1]:.1f} {p2[0]:.1f},{p2[1]:.1f}"
    return d + (" Z" if closed else "")

def wob(points, closed=True, amp=1.6, seed=1, step=14):
    """hand-wobbly path through a polygon/polyline"""
    r = random.Random(seed)
    ph = [r.random() * 6.28 for _ in range(3)]
    out = []
    segs = len(points) if closed else len(points) - 1
    t = 0.0
    for i in range(segs):
        (x0, y0), (x1, y1) = points[i], points[(i + 1) % len(points)]
        L = math.hypot(x1 - x0, y1 - y0) or 1
        k = max(1, int(L / step))
        nx, ny = -(y1 - y0) / L, (x1 - x0) / L
        for j in range(k):
            u = j / k; t += L / k
            o = amp * (math.sin(t * 0.07 + ph[0]) * 0.6 + math.sin(t * 0.19 + ph[1]) * 0.3 + (r.random() - 0.5) * 0.4)
            out.append((x0 + (x1 - x0) * u + nx * o, y0 + (y1 - y0) * u + ny * o))
    if not closed:
        out.append(points[-1])
    return catmull(out, closed)

def ell(cx, cy, rx, ry, n=18, jitter=0.0, seed=0):
    r = random.Random(seed)
    return [(cx + rx * (1 + (r.random() - .5) * jitter) * math.cos(a), cy + ry * (1 + (r.random() - .5) * jitter) * math.sin(a))
            for a in [i * 2 * math.pi / n for i in range(n)]]

def heart_pts(cx, cy, s):
    pts = []
    for i in range(28):
        t = i / 28 * 2 * math.pi
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * s / 32, cy + y * s / 32))
    return pts

def P(d, fill="none", stroke=INK, sw=4, extra=""):
    return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round" stroke-linecap="round" {extra}/>'

def T(x, y, s, txt, fill=INK, size=20, anchor="middle", weight=800, extra=""):
    return f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" class="{s}" {extra}>{txt}</text>'

# PlayStation face-button badges, drawn (not glyphs, so they render everywhere)
def ps_badge(kind, cx, cy, r=13, bg="#ffffff", ring=INK):
    col = {"x": "#5b8fd6", "o": "#e2574c", "t": "#2fae8f", "s": "#cf6fc9"}[kind]
    g = f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{bg}" stroke="{ring}" stroke-width="2.5"/>'
    k = r * 0.48
    if kind == "x":
        g += P(f"M{cx-k},{cy-k} L{cx+k},{cy+k} M{cx+k},{cy-k} L{cx-k},{cy+k}", stroke=col, sw=3.5)
    elif kind == "o":
        g += f'<circle cx="{cx}" cy="{cy}" r="{k}" fill="none" stroke="{col}" stroke-width="3.5"/>'
    elif kind == "t":
        g += P(f"M{cx},{cy-k*1.1} L{cx+k},{cy+k*.75} L{cx-k},{cy+k*.75} Z", stroke=col, sw=3.2)
    else:
        g += P(f"M{cx-k},{cy-k} h{2*k} v{2*k} h{-2*k} Z", stroke=col, sw=3.2)
    return g

# move icons, all drawn in a 40x40 box at (x,y), ink + one marker colour
def icon(kind, x, y, s=1.0, ink=INK, seed=3):
    g = f'<g transform="translate({x},{y}) scale({s})">'
    if kind == "hide":   # folded sheet = protected
        g += P(wob([(6, 6), (28, 6), (34, 12), (34, 34), (6, 34)], seed=seed, amp=.6), fill="#f3d36a", stroke=ink, sw=3.2)
        g += P(wob([(28, 6), (28, 12), (34, 12)], closed=False, seed=seed, amp=.3), stroke=ink, sw=3)
        g += P(wob([(6, 20), (34, 20)], closed=False, seed=seed + 1, amp=.6), stroke=ink, sw=2.5, extra='stroke-dasharray="4 4"')
    elif kind == "chomp":  # zigzag teeth
        g += P(wob(ell(20, 20, 16, 14, 16), seed=seed, amp=.6), fill="#e8921c", stroke=ink, sw=3.2)
        g += P("M6,20 L11,14 L15,22 L20,14 L25,22 L29,14 L34,20", fill="#fbf8f0", stroke=ink, sw=2.6)
    elif kind == "open":  # unfold: sheet opening with burst
        g += P(wob([(4, 10), (18, 6), (18, 34), (4, 30)], seed=seed, amp=.5), fill="#e99dbb", stroke=ink, sw=3)
        g += P(wob([(22, 6), (36, 10), (36, 30), (22, 34)], seed=seed + 2, amp=.5), fill="#e99dbb", stroke=ink, sw=3)
        g += P("M20,1 L20,4 M10,2 L12,4 M30,2 L28,4", stroke=ink, sw=2.5)
    elif kind == "stack":
        for i, c in enumerate(["#0e6e74", "#fbf8f0", "#d03c30"]):
            g += P(wob(ell(20, 32 - i * 11, 11, 7, 12), seed=seed + i, amp=.4), fill=c, stroke=ink, sw=2.8)
    elif kind == "swoop":  # bat wing swoop
        g += P(wob([(4, 22), (12, 12), (16, 18), (20, 10), (24, 18), (28, 12), (36, 22), (20, 28)], seed=seed, amp=.5), fill="#8f8aa6", stroke=ink, sw=3)
        g += P("M8,34 Q20,40 34,32", stroke=ink, sw=2.6, extra='stroke-dasharray="3 4"')
    elif kind == "web":
        g += P("M20,4 L20,36 M4,20 L36,20 M8,8 L32,32 M32,8 L8,32", stroke=ink, sw=2.2)
        g += P(wob(ell(20, 20, 9, 9, 8), seed=seed, amp=.3), stroke=ink, sw=2.2)
        g += P(wob(ell(20, 20, 15, 15, 8), seed=seed + 1, amp=.3), stroke=ink, sw=2.2)
    elif kind == "splash":
        g += P(wob([(20, 4), (30, 22), (28, 32), (20, 36), (12, 32), (10, 22)], seed=seed, amp=.5), fill="#8cc8dc", stroke=ink, sw=3)
    elif kind == "boo":
        g += P(wob([(8, 36), (8, 16), (14, 6), (26, 6), (32, 16), (32, 36), (26, 31), (20, 36), (14, 31)], seed=seed, amp=.5), fill="#fbf8f0", stroke=ink, sw=3)
        g += '<circle cx="16" cy="17" r="2.6" fill="#1a1a1a"/><circle cx="24" cy="17" r="2.6" fill="#1a1a1a"/>'
    return g + "</g>"

def pips(n, x, y, col="#d03c30", ink=INK, r=4.5, gap=12):
    """hit count as little star-bursts (1-3)"""
    g = ""
    for i in range(n):
        cx = x + i * gap
        pts = []
        for k in range(10):
            rr = r * 1.5 if k % 2 == 0 else r * 0.7
            a = -math.pi / 2 + k * math.pi / 5
            pts.append((cx + rr * math.cos(a), y + rr * math.sin(a)))
        g += P("M" + " L".join(f"{a:.1f},{b:.1f}" for a, b in pts) + " Z", fill=col, stroke=ink, sw=1.8)
    return g

def hearts(n, full, x, y, s=18, gap=22, fill="#d03c30", empty="none", ink=INK, sw=2.6, seed=0):
    g = ""
    for i in range(n):
        g += P(wob(heart_pts(x + i * gap, y, s), seed=seed + i, amp=.5, step=6), fill=fill if i < full else empty, stroke=ink, sw=sw)
    return g

# ------------------------------------------------ clean flat-vector stand-ins
# Quick redraws in the target style (thick wobbly #1a1a1a outline, flat marker fills)
def sym_icecream():
    s = '<symbol id="v-icecream" viewBox="-6 -4 112 128">'
    s += P("M50,30 L50,8 M50,22 L28,12 M50,22 L74,12", stroke=INK, sw=10)
    s += P("M50,30 L50,8 M50,22 L28,12 M50,22 L74,12", stroke="#9a5a2e", sw=5)
    s += P(wob(ell(24, 11, 11, 9, 12), seed=4, amp=.8), fill="#d03c30", sw=4)
    s += P(wob(ell(77, 12, 11, 9, 12), seed=5, amp=.8), fill="#d03c30", sw=4)
    s += P(wob([(16, 70), (84, 70), (50, 119)], seed=6, amp=.9), fill="#8b4a22", sw=4.5)
    s += P("M27,74 L52,112 M40,72 L60,101 M55,72 L69,88 M73,74 L48,112 M60,72 L40,100 M45,72 L31,88", stroke="#3b1a0c", sw=2.5)
    s += P(wob([(12, 63), (88, 63), (85, 72), (62, 75), (38, 75), (15, 72)], seed=7, amp=.7), fill="#0e6e74", sw=4)
    s += P(wob([(12, 64)] + [(50 + 38 * math.cos(a), 64 - 46 * math.sin(a)) for a in [i * math.pi / 10 for i in range(1, 10)]] + [(88, 64)], seed=8, amp=.9), fill="#d03c30", sw=4.5)
    for ex in (35, 65):
        s += f'<ellipse cx="{ex}" cy="42" rx="9" ry="10" fill="{INK}"/><circle cx="{ex-3}" cy="38" r="3.4" fill="#fff"/>'
    s += P("M25,28 L41,33 M75,28 L59,33", sw=3.5)
    s += P("M42,55 L45,51 L48,56 L51,51 L54,56 L57,51", sw=2.6)
    s += P("M2,52 L-4,48 M98,52 L104,48 M4,84 L-2,90 M96,84 L102,90", sw=3)
    return s + "</symbol>"

def sym_fish():
    s = '<symbol id="v-fish" viewBox="-14 -12 132 128">'
    s += P("M-8,10 L36,40 M-10,96 L36,64 M8,40 L-6,50 M12,72 L-4,74 M58,6 L66,-8 M58,98 L68,110", sw=3.4)
    body = [(30, 52), (52, 22), (66, 10), (84, 8), (100, 18), (104, 34), (96, 46), (76, 52), (96, 58), (104, 72), (100, 88), (84, 98), (66, 96), (52, 84)]
    s += P(wob(body, seed=9, amp=1.0), fill="#e99dbb", sw=4.5)
    s += P(wob([(30, 52), (52, 22), (66, 10), (66, 96), (52, 84)], seed=10, amp=.6), fill="#fbf8f0", stroke="none", sw=0)
    s += P(wob(body, seed=9, amp=1.0), sw=4.5)
    s += P("M66,12 L66,94", sw=2, stroke="#b8667f", extra='stroke-dasharray="5 5"')
    s += f'<ellipse cx="88" cy="28" rx="5" ry="3.6" fill="{INK}"/><ellipse cx="88" cy="80" rx="5" ry="3.6" fill="{INK}"/>'
    s += P("M76,52 Q68,46 70,38 M76,52 Q70,58 72,66", sw=3)
    return s + "</symbol>"

# --------------------------------------------------------- shared bits
def touch_overlay(col="#1a1a1a", op=0.18):
    g = f'<g opacity="{op}">'
    g += f'<circle cx="74" cy="318" r="46" fill="none" stroke="{col}" stroke-width="3"/><circle cx="74" cy="318" r="18" fill="{col}"/>'
    g += f'<circle cx="786" cy="300" r="26" fill="none" stroke="{col}" stroke-width="3"/><circle cx="736" cy="340" r="22" fill="none" stroke="{col}" stroke-width="3"/>'
    return g + "</g>"

FONT = "ui"

# ======================================================== DIRECTION A: PAPER PAGE
def A_world():
    PEN = "#a39c8e"   # pencil scenery line
    g = ['<rect width="844" height="390" fill="#fbf8f0"/>']
    # faint fold creases: the page has been folded too
    g.append('<path d="M0,196 L844,196" stroke="#e6dfcf" stroke-width="2"/><path d="M0,198 L844,198" stroke="#fffefa" stroke-width="2"/>')
    g.append('<path d="M422,0 L422,390" stroke="#ece6d8" stroke-width="2"/>')
    # path (tan marker, pencil edge)
    g.append(P(wob([(0, 250), (180, 236), (330, 246), (470, 232), (520, 236), (520, 290), (470, 300), (330, 296), (180, 300), (0, 296)], seed=11, amp=2), fill="#f2e2bd", stroke=PEN, sw=2))
    g.append(P(wob([(620, 238), (844, 226), (844, 290), (620, 292)], seed=12, amp=2), fill="#f2e2bd", stroke=PEN, sw=2))
    # water (interactive obstacle: full ink)
    g.append(P(wob([(540, 0), (600, 0), (606, 120), (598, 260), (604, 390), (540, 390), (532, 250), (546, 120)], seed=13, amp=2.5), fill="#8cc8dc", sw=4.5))
    for yy in (40, 110, 180, 300, 350):
        g.append(P(f"M552,{yy} q8,-6 16,0 t16,0", stroke="#3f86a6", sw=2.5))
    # dotted 'something fits here' outline over the gap = fish-bridge spot
    g.append(P(wob([(520, 252), (622, 248), (626, 276), (520, 280)], seed=14, amp=1), fill="#ffffff", stroke=INK, sw=3, extra='fill-opacity=".55" stroke-dasharray="7 7"'))
    g.append(icon("open", 553, 244, 0.9))
    # scenery: pale pencil pumpkins and vines (not interactive)
    for i, (x, y, s) in enumerate([(80, 120, 1), (200, 70, .8), (330, 120, 1.1), (700, 90, .9), (760, 170, .7), (120, 360, .9), (420, 360, 1), (720, 360, .8), (40, 200, .6)]):
        g.append(P(wob(ell(x, y, 30 * s, 22 * s, 14), seed=20 + i, amp=1.2), fill="#f8d9b4", stroke=PEN, sw=2))
        g.append(P(f"M{x-8*s:.0f},{y-20*s:.0f} Q{x:.0f},{y:.0f} {x-8*s:.0f},{y+20*s:.0f} M{x+8*s:.0f},{y-20*s:.0f} Q{x:.0f},{y:.0f} {x+8*s:.0f},{y+20*s:.0f}", stroke=PEN, sw=1.6))
        g.append(P(f"M{x:.0f},{y-21*s:.0f} l3,-9", stroke="#b7a98c", sw=3))
    for i in range(16):
        r = random.Random(i)
        x, y = r.randint(20, 820), r.randint(20, 380)
        if 500 < x < 640 or 225 < y < 305: continue
        g.append(P(f"M{x},{y} l4,-8 l4,8 l4,-8 l4,8", stroke="#b7cf9b", sw=2))
    # wandering bat (child's drawing) with dotted path it is following
    g.append(P("M640,150 C690,110 740,150 790,110", stroke="#c9c1b0", sw=2.5, extra='stroke-dasharray="2 8"'))
    g.append('<ellipse cx="700" cy="168" rx="24" ry="5" fill="#e3dccb"/>')
    g.append(use("bat", 700, 150, 76))
    # candy pickup (child's wrapped candy) with soft static ring
    g.append('<circle cx="440" cy="166" r="30" fill="#fff4b8"/>')
    g.append(P(wob(ell(440, 166, 30, 30, 16), seed=40, amp=.8), stroke="#e8c94a", sw=2.5))
    g.append(use("candy", 440, 180, 28))
    # follower + lead, with marker-grey shadows
    g.append('<ellipse cx="200" cy="286" rx="30" ry="7" fill="#e3dccb"/>' + use("juice", 200, 286, 70))
    g.append('<ellipse cx="300" cy="280" rx="34" ry="7" fill="#e3dccb"/>')
    g.append('<use href="#v-icecream" x="262" y="190" width="76" height="92"/>')
    # HUD: hearts + candy count, on the page itself
    g.append(hearts(6, 5, 30, 30, s=20, gap=26))
    g.append(use("candy", 742, 44, 22) + T(800, 42, FONT, "3", size=26))
    g.append(touch_overlay())
    return "".join(g)

def move_card_A(x, y, ic, word, badge, hits, active=False, seed=0):
    g = P(wob([(x, y), (x + 150, y), (x + 150, y + 64), (x, y + 64)], seed=seed, amp=1.2), fill="#fffdf6" if not active else "#fff1a8", sw=4 if active else 3)
    g += icon(ic, x + 10, y + 12)
    g += T(x + 56, y + 32, FONT, word, size=21 if len(word) <= 5 else 17, anchor="start")
    g += pips(hits, x + 64, y + 48)
    g += ps_badge(badge, x + 150, y, r=13)
    return g

def A_battle():
    PEN = "#a39c8e"
    g = ['<rect width="844" height="390" fill="#fbf8f0"/>']
    g.append('<path d="M0,196 L844,196" stroke="#e6dfcf" stroke-width="2"/><path d="M422,0 L422,390" stroke="#ece6d8" stroke-width="2"/>')
    g.append(P(wob([(0, 150), (300, 140), (560, 152), (844, 138)], closed=False, seed=50, amp=2), stroke=PEN, sw=2))
    g.append(P(wob(ell(620, 160, 110, 22, 18), seed=51, amp=1.5), fill="#e5efcf", stroke=PEN, sw=2))
    g.append(P(wob(ell(190, 300, 130, 26, 18), seed=52, amp=1.5), fill="#e5efcf", stroke=PEN, sw=2))
    # enemy bat + its next move bubble
    g.append(use("bat", 620, 152, 100))
    g.append(P(wob([(414, 30), (566, 30), (566, 96), (470, 96), (456, 112), (458, 96), (414, 96)], seed=53, amp=1), fill="#ffffff", sw=3.5))
    g.append(icon("swoop", 428, 42, 1.0))
    g.append(T(470, 64, FONT, "SWOOP", size=19, anchor="start") + pips(2, 478, 82))
    g.append(T(490, 22, FONT, "next:", size=13, weight=600, fill="#6b655b"))
    g.append(hearts(5, 4, 690, 34, s=17, gap=22))
    # player ice cream (clean redraw stand-in), folded form
    g.append('<use href="#v-icecream" x="128" y="150" width="124" height="150"/>')
    g.append(hearts(8, 6, 30, 30, s=18, gap=23))
    # moves
    g.append(move_card_A(330, 250, "hide", "HIDE", "x", 0, seed=60))
    g.append(move_card_A(500, 250, "chomp", "BONK", "o", 1, active=True, seed=61))
    g.append(move_card_A(670, 250, "stack", "STACK", "t", 3, seed=62))
    g.append(T(745, 336, FONT, "unfolds!", size=13, weight=600, fill="#6b655b"))
    return "".join(g)

# ======================================================== DIRECTION B: POP-UP CRAFT
def drop(id_, dy=3, blur=1.6, op=.35):
    return f'<filter id="{id_}" x="-10%" y="-10%" width="120%" height="130%"><feDropShadow dx="0" dy="{dy}" stdDeviation="{blur}" flood-color="#3a2410" flood-opacity="{op}"/></filter>'

def B_defs():
    return "<defs>" + drop("shB", 3, 1.6, .35) + drop("shB2", 5, 2.5, .4) + \
        '<pattern id="fibre" width="6" height="6" patternUnits="userSpaceOnUse"><rect width="6" height="6" fill="none"/><circle cx="1" cy="2" r=".6" fill="#000" opacity=".06"/><circle cx="4" cy="5" r=".5" fill="#fff" opacity=".08"/></pattern></defs>'

def standee(inner, filt="shB2"):
    """interactive things stand up: white die-cut edge + cast shadow"""
    return f'<g filter="url(#{filt})">{inner}</g>'

def B_world():
    g = [B_defs(), '<rect width="844" height="390" fill="#e7b85b"/>']
    # back paper layers: sky, hills; each layer cast a shadow, edges cut slightly irregular
    g.append('<rect width="844" height="120" fill="#9fc3b5"/>')
    g.append(f'<g filter="url(#shB)"><path d="{wob([(0,70),(140,40),(300,78),(470,36),(640,74),(844,44),(844,140),(0,140)], seed=70, amp=1.2, step=30)}" fill="#6f8f3e"/></g>')
    g.append(f'<g filter="url(#shB)"><path d="{wob([(0,130),(200,108),(420,132),(640,104),(844,128),(844,390),(0,390)], seed=71, amp=1.2, step=30)}" fill="#d9a24e"/></g>')
    # path strip (lighter kraft)
    g.append(f'<g filter="url(#shB)"><path d="{wob([(0,236),(500,228),(500,300),(0,304)], seed=72, amp=1, step=40)}" fill="#f0d39a"/></g>')
    g.append(f'<g filter="url(#shB)"><path d="{wob([(590,226),(844,220),(844,296),(590,300)], seed=73, amp=1, step=40)}" fill="#f0d39a"/></g>')
    g.append('<rect width="844" height="390" fill="url(#fibre)"/>')
    # glued-flat scenery: pumpkins as flat paper shapes (no ink, no die-cut edge)
    for i, (x, y, s) in enumerate([(70, 170, 1), (210, 150, .8), (360, 180, 1.1), (700, 160, .9), (120, 350, .9), (430, 356, 1), (760, 350, .8)]):
        g.append(f'<path d="{wob(ell(x, y, 30*s, 21*s, 14), seed=80+i, amp=.8)}" fill="#d9772a"/>')
        g.append(f'<path d="M{x-9*s:.0f},{y-19*s:.0f} Q{x:.0f},{y:.0f} {x-9*s:.0f},{y+19*s:.0f} M{x+9*s:.0f},{y-19*s:.0f} Q{x:.0f},{y:.0f} {x+9*s:.0f},{y+19*s:.0f}" stroke="#b85f1d" stroke-width="2.5" fill="none"/>')
        g.append(f'<rect x="{x-3}" y="{y-28*s:.0f}" width="6" height="{10*s:.0f}" fill="#6f8f3e"/>')
    # stream: blue paper strip with layered lighter ripples
    g.append(f'<g filter="url(#shB)"><path d="{wob([(500,140),(590,140),(594,390),(498,390)], seed=74, amp=1.2, step=30)}" fill="#4f8fb0"/></g>')
    for yy in (180, 330, 370):
        g.append(f'<path d="M515,{yy} q10,-6 20,0 t20,0 t20,0" stroke="#9cc9de" stroke-width="5" fill="none" stroke-linecap="round"/>')
    # boulder blocking the far path: interactive, so it stands up (die-cut + shadow + ink)
    bould = wob(ell(700, 250, 44, 36, 12, jitter=.15, seed=3), seed=75, amp=1.2)
    g.append(standee(f'<path d="{bould}" fill="#fff" stroke="#fff" stroke-width="12" stroke-linejoin="round"/>'
                     f'<path d="{bould}" fill="#9a958a" stroke="{INK}" stroke-width="4" stroke-linejoin="round"/>'
                     f'<path d="M680,232 l10,12 l-6,10 M716,236 l-8,14" stroke="{INK}" stroke-width="3" fill="none"/>'))
    g.append(f'<g transform="translate(680,170)">' + P(wob(ell(20, 20, 24, 20, 12), seed=76, amp=.6), fill="#fff", sw=3) + icon("chomp", 0, 0) + '</g>')
    # bridge: paper plank slot over water (dashed cut line = something fits here)
    g.append(P(wob([(492, 248), (600, 244), (602, 278), (492, 282)], seed=77, amp=.8), fill="#fff", stroke=INK, sw=3, extra='fill-opacity=".35" stroke-dasharray="8 6"'))
    # spider dangling from a paper branch on a thread (wanders up and down)
    g.append(f'<g filter="url(#shB)"><path d="M300,0 L304,52 L330,40 L310,60 L298,58 Z" fill="#6b3a1c"/></g>')
    g.append('<path d="M305,58 L305,104" stroke="#1a1a1a" stroke-width="2"/>')
    g.append(standee(use("spider", 305, 150, 52)))
    # candy (child's lollipop) as a stand-up paper token
    g.append(standee(use("lollipop", 440, 210, 40)))
    # follower + lead as paper standees with a little stand tab
    for cx, by in ((190, 288), (300, 282)):
        g.append(f'<path d="M{cx-22},{by} L{cx+22},{by} L{cx+30},{by+8} L{cx-30},{by+8} Z" fill="#c99a5e"/>')
    g.append(standee(use("pot_folded", 190, 290, 66)))
    g.append(standee(use("monster_folded_clean", 300, 284, 74), "shB2"))
    # HUD: paper tabs
    g.append(standee(P(wob([(16, 12), (190, 12), (190, 50), (16, 50)], seed=78, amp=.6), fill="#fbf8f0", stroke="none", sw=0), "shB"))
    g.append(hearts(6, 5, 38, 31, s=18, gap=25, sw=2.2))
    g.append(standee(P(wob([(708, 12), (828, 12), (828, 54), (708, 54)], seed=79, amp=.6), fill="#fbf8f0", stroke="none", sw=0), "shB"))
    g.append(use("candy", 742, 46, 22) + T(796, 44, FONT, "3", size=26))
    g.append(touch_overlay("#3a2410", .22))
    return "".join(g)

def move_tab_B(x, y, ic, word, badge, hits, active=False, seed=0):
    col = "#fbf8f0" if not active else "#fff1a8"
    pts = [(x, y), (x + 136, y), (x + 150, y + 14), (x + 150, y + 64), (x, y + 64)]
    g = f'<g filter="url(#shB2)"><path d="{wob(pts, seed=seed, amp=.6)}" fill="{col}"/></g>'
    g += f'<path d="M{x+136},{y} L{x+136},{y+14} L{x+150},{y+14} Z" fill="#d8cbb0"/>'  # folded corner
    if active:
        g += P(wob(pts, seed=seed, amp=.6), stroke=INK, sw=3.5)
    g += icon(ic, x + 10, y + 12) + T(x + 56, y + 32, FONT, word, size=21 if len(word) <= 5 else 17, anchor="start") + pips(hits, x + 64, y + 48)
    g += ps_badge(badge, x + 14, y, r=13)
    return g

def B_battle():
    g = [B_defs(), '<rect width="844" height="390" fill="#2f3f5c"/>']
    # pop-up theatre: stacked backdrops
    g.append(f'<g filter="url(#shB)"><path d="{wob([(0,0),(844,0),(844,200),(0,200)], seed=90, amp=1, step=40)}" fill="#9fc3b5"/></g>')
    g.append(f'<g filter="url(#shB)"><path d="{wob([(0,110),(180,70),(380,120),(600,66),(844,104),(844,230),(0,230)], seed=91, amp=1, step=30)}" fill="#6f8f3e"/></g>')
    g.append(f'<g filter="url(#shB)"><path d="{wob([(0,190),(844,176),(844,390),(0,390)], seed=92, amp=1, step=40)}" fill="#d9a24e"/></g>')
    g.append('<rect width="844" height="390" fill="url(#fibre)"/>')
    # curtains (paper)
    g.append(f'<g filter="url(#shB2)"><path d="M0,0 L54,0 Q40,120 60,240 L0,250 Z" fill="#b8402f"/><path d="M844,0 L790,0 Q804,120 784,240 L844,250 Z" fill="#b8402f"/></g>')
    # platforms
    g.append(f'<g filter="url(#shB2)"><path d="{wob(ell(610,182,96,18,16), seed=93, amp=.8)}" fill="#c99a5e"/><path d="{wob(ell(210,310,120,22,16), seed=94, amp=.8)}" fill="#c99a5e"/></g>')
    # enemy spider on its thread + next move flag on a stick
    g.append('<path d="M610,0 L610,90" stroke="#1a1a1a" stroke-width="2"/>')
    g.append(standee(use("spider", 610, 180, 100)))
    g.append('<path d="M410,170 L410,40" stroke="#6b3a1c" stroke-width="5" stroke-linecap="round"/>')
    g.append(f'<g filter="url(#shB2)"><path d="{wob([(410,26),(546,26),(530,62),(546,98),(410,98)], seed=95, amp=.6)}" fill="#fbf8f0"/></g>')
    g.append(icon("web", 418, 42) + T(462, 64, FONT, "WEB", size=21, anchor="start") + pips(1, 468, 82))
    g.append(T(478, 20, FONT, "next", size=13, weight=700, fill="#1a1a1a"))
    g.append(standee(P(wob([(680, 14), (820, 14), (820, 50), (680, 50)], seed=96, amp=.5), fill="#fbf8f0", stroke="none", sw=0), "shB"))
    g.append(hearts(5, 3, 700, 33, s=17, gap=24, sw=2.2))
    # player monster (posterised stand-in)
    g.append(standee(use("monster_folded_clean", 210, 312, 130)))
    g.append(standee(P(wob([(60, 14), (300, 14), (300, 50), (60, 50)], seed=97, amp=.5), fill="#fbf8f0", stroke="none", sw=0), "shB"))
    g.append(hearts(8, 7, 82, 33, s=17, gap=27, sw=2.2))
    g.append(move_tab_B(340, 266, "hide", "HIDE", "x", 0, seed=98))
    g.append(move_tab_B(504, 266, "chomp", "CHOMP", "o", 2, active=True, seed=99))
    g.append(move_tab_B(668, 266, "open", "GULP", "t", 3, seed=100))
    return "".join(g)

# ======================================================== DIRECTION C: LANTERN NIGHT
def C_defs():
    return ('<defs><radialGradient id="glowW"><stop offset="0" stop-color="#fff3c4" stop-opacity=".55"/><stop offset=".6" stop-color="#ffd27a" stop-opacity=".18"/><stop offset="1" stop-color="#ffd27a" stop-opacity="0"/></radialGradient>'
            '<radialGradient id="glowB"><stop offset="0" stop-color="#bfe8ff" stop-opacity=".45"/><stop offset="1" stop-color="#bfe8ff" stop-opacity="0"/></radialGradient>'
            '<linearGradient id="skyC" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#191b38"/><stop offset="1" stop-color="#2a2d57"/></linearGradient>'
            '<filter id="rim" x="-20%" y="-20%" width="140%" height="140%"><feMorphology in="SourceAlpha" operator="dilate" radius="3" result="d"/><feFlood flood-color="#fffbe9"/><feComposite in2="d" operator="in" result="r"/><feMerge><feMergeNode in="r"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>')

def glow(cx, cy, r, which="glowW"):
    return f'<ellipse cx="{cx}" cy="{cy}" rx="{r}" ry="{r*0.8:.0f}" fill="url(#{which})"/>'

def C_world():
    LINE = "#5d6299"
    g = [C_defs(), '<rect width="844" height="390" fill="url(#skyC)"/>']
    g.append('<circle cx="640" cy="50" r="24" fill="#f4ecc8"/><circle cx="651" cy="43" r="22" fill="#1b1d3c"/>')
    for i in range(14):
        r = random.Random(100 + i); x, y = r.randint(20, 700), r.randint(10, 80)
        g.append(f'<circle cx="{x}" cy="{y}" r="1.6" fill="#c9c6e8" opacity=".7"/>')
    g.append(P(wob([(0, 110), (844, 96), (844, 390), (0, 390)], seed=110, amp=2), fill="#2c3160", stroke=LINE, sw=2))
    g.append(P(wob([(0, 236), (500, 228), (500, 300), (0, 304)], seed=111, amp=2), fill="#3a4078", stroke=LINE, sw=2))
    g.append(P(wob([(600, 228), (844, 220), (844, 296), (600, 300)], seed=112, amp=2), fill="#3a4078", stroke=LINE, sw=2))
    # unlit background pumpkins: dim, soft lilac outline
    for i, (x, y, s) in enumerate([(70, 160, 1), (210, 140, .8), (350, 170, 1.1), (700, 150, .9), (120, 352, .9), (430, 356, 1), (760, 350, .8)]):
        g.append(P(wob(ell(x, y, 30 * s, 21 * s, 14), seed=120 + i, amp=1), fill="#5a3b45", stroke=LINE, sw=2))
        g.append(P(f"M{x:.0f},{y-21*s:.0f} l3,-8", stroke=LINE, sw=3))
    # river with moon reflections
    g.append(P(wob([(510, 96), (590, 96), (596, 390), (506, 390)], seed=113, amp=2), fill="#1d4660", stroke="#8cc8dc", sw=3))
    for yy in (150, 200, 330, 362):
        g.append(f'<path d="M530,{yy} h24 M548,{yy+8} h16" stroke="#8cc8dc" stroke-width="2.5" stroke-linecap="round" opacity=".6"/>')
    # glowing dotted outline: where a power fits
    g.append(glow(552, 264, 70, "glowB"))
    g.append(P(wob([(496, 250), (608, 246), (610, 280), (496, 284)], seed=114, amp=1), fill="#bfe8ff", stroke="#e7f6ff", sw=3, extra='fill-opacity=".18" stroke-dasharray="8 7"'))
    g.append(f'<g transform="translate(534,236)">' + P(wob(ell(20, 20, 23, 20, 12), seed=115, amp=.6), fill="#fffbe9", sw=0, stroke="none") + icon("open", 0, 0) + "</g>")
    # lantern on post lights the path (light = where to go)
    g.append(P("M640,226 L640,150", stroke="#7b5a3a", sw=5))
    g.append(glow(652, 150, 60) + P(wob([(644, 140), (660, 140), (662, 162), (642, 162)], seed=116, amp=.5), fill="#ffd27a", sw=3))
    # ghost wandering (child's ghost) - lit pale, soft blue glow
    g.append(glow(720, 150, 54, "glowB") + f'<g filter="url(#rim)">{use("ghost", 720, 176, 56)}</g>')
    g.append(P("M760,180 C790,200 800,170 830,190", stroke="#8f95cf", sw=2.5, extra='stroke-dasharray="2 8"'))
    # candy pickup glowing
    g.append(glow(440, 190, 46) + f'<g filter="url(#rim)">{use("candy", 440, 202, 30)}</g>')
    # follower pumpkin + lead fish (vector stand-in), lit by their own glow
    g.append(glow(195, 260, 70) + f'<g filter="url(#rim)">{use("pumpkin_folded", 195, 292, 60)}</g>')
    g.append(glow(305, 250, 80))
    g.append('<g filter="url(#rim)"><use href="#v-fish" x="262" y="200" width="88" height="86"/></g>')
    # HUD
    g.append(f'<rect x="14" y="12" width="176" height="40" rx="20" fill="#141631" stroke="#5d6299" stroke-width="2"/>')
    g.append(hearts(6, 5, 38, 32, s=18, gap=26, fill="#ff6b5a", empty="#2c3160", ink="#fffbe9", sw=2.4))
    g.append(f'<rect x="706" y="12" width="120" height="44" rx="22" fill="#141631" stroke="#5d6299" stroke-width="2"/>')
    g.append(f'<g filter="url(#rim)">{use("candy", 740, 44, 22)}</g>' + T(796, 44, FONT, "3", size=26, fill="#fffbe9"))
    g.append(touch_overlay("#fffbe9", .2))
    return "".join(g)

def move_card_C(x, y, ic, word, badge, hits, active=False):
    g = ""
    if active:
        g += f'<rect x="{x-8}" y="{y-8}" width="166" height="80" rx="22" fill="#ffd27a" opacity=".22"/>'
    g += f'<rect x="{x}" y="{y}" width="150" height="64" rx="16" fill="{"#fffbe9" if active else "#e9e6f7"}" stroke="{"#ffd27a" if active else "#8f95cf"}" stroke-width="{4 if active else 2.5}"/>'
    g += icon(ic, x + 10, y + 12) + T(x + 56, y + 32, FONT, word, size=21 if len(word) <= 5 else 17, anchor="start") + pips(hits, x + 64, y + 48)
    g += ps_badge(badge, x + 150, y, r=13, bg="#141631", ring="#fffbe9")
    return g

def C_battle():
    g = [C_defs(), '<rect width="844" height="390" fill="url(#skyC)"/>']
    g.append('<circle cx="420" cy="70" r="34" fill="#f4ecc8" opacity=".9"/>')
    g.append(P(wob([(0, 170), (300, 150), (560, 166), (844, 146), (844, 390), (0, 390)], seed=130, amp=2), fill="#2c3160", stroke="#5d6299", sw=2))
    # spotlight pools
    g.append('<ellipse cx="620" cy="178" rx="110" ry="24" fill="#ffd27a" opacity=".16"/><ellipse cx="200" cy="310" rx="140" ry="28" fill="#ffd27a" opacity=".18"/>')
    g.append(glow(620, 120, 90, "glowB") + f'<g filter="url(#rim)">{use("bat", 620, 172, 96)}</g>')
    # next move bubble
    g.append(f'<rect x="396" y="132" width="152" height="70" rx="20" fill="#fffbe9" stroke="#8f95cf" stroke-width="3"/><path d="M530,150 L560,142 L540,168 Z" fill="#fffbe9"/>')
    g.append(T(473, 124, FONT, "next", size=14, weight=700, fill="#c9c6e8"))
    g.append(icon("swoop", 410, 146) + T(456, 170, FONT, "SWOOP", size=19, anchor="start") + pips(2, 464, 188))
    g.append(f'<rect x="660" y="14" width="168" height="40" rx="20" fill="#141631" stroke="#5d6299" stroke-width="2"/>')
    g.append(hearts(5, 4, 684, 34, s=17, gap=30, fill="#ff6b5a", empty="#2c3160", ink="#fffbe9", sw=2.4))
    g.append(glow(200, 240, 120))
    g.append('<g filter="url(#rim)"><use href="#v-fish" x="120" y="170" width="160" height="150"/></g>')
    g.append(f'<rect x="14" y="14" width="232" height="40" rx="20" fill="#141631" stroke="#5d6299" stroke-width="2"/>')
    g.append(hearts(8, 6, 38, 34, s=17, gap=27, fill="#ff6b5a", empty="#2c3160", ink="#fffbe9", sw=2.4))
    g.append(move_card_C(330, 262, "hide", "HIDE", "x", 0))
    g.append(move_card_C(500, 262, "splash", "SPLASH", "o", 1, active=True))
    g.append(move_card_C(670, 262, "open", "LONG", "t", 3))
    return "".join(g)

# ======================================================== page
for n, px in [("bat", 220), ("candy", 120), ("juice", 200), ("spider", 220), ("lollipop", 120),
              ("pot_folded", 200), ("monster_folded_clean", 300), ("ghost", 160), ("pumpkin_folded", 200)]:
    img_symbol(n, px)

def frame(content, label):
    return f'<figure><svg viewBox="0 0 844 390" role="img" aria-label="{label}">{content}</svg><figcaption>{label}</figcaption></figure>'

DIRS = [
    ("A", "#e8921c", "Paper Page", "paper",
     "The whole world is drawn on the same white printer paper as his characters, with the same black marker. "
     "One simple rule keeps it calm: things you can touch, fight or use are drawn in thick black marker with full colour; scenery is drawn in light grey pencil with pale colour. "
     "His characters look like they were always part of the page.",
     A_world(), A_battle()),
    ("B", "#6f8f3e", "Pop-Up Paper", "craft",
     "A pop-up book made of construction paper: flat coloured paper layers glued down for the ground, hills and sky. "
     "Anything you can use stands up out of the page with a white cut edge and a shadow, like a paper puppet. "
     "Folding and unfolding fits right in: the characters are paper too.",
     B_world(), B_battle()),
    ("C", "#5d4fa8", "Lantern Night", "night",
     "Halloween night in deep blue. The world is soft and dim, and only the things that matter are lit up: his characters, candy, and the places where a power can be used. "
     "Very easy to read on a TV across the room, and spooky-cosy rather than scary.",
     C_world(), C_battle()),
]

CSS = """
:root{color-scheme:light}
*{box-sizing:border-box}
body{margin:0;background:#efe9dc;font-family:Andika,"Avenir Next Rounded","Arial Rounded MT Bold",Verdana,"DejaVu Sans",sans-serif;color:#1a1a1a}
header{padding:28px 32px 8px;max-width:1800px;margin:auto}
header h1{margin:0 0 6px;font-size:30px}
header p{margin:0;max-width:900px;line-height:1.45;font-size:16px}
.picker{display:flex;gap:18px;margin:18px 0 6px}
.picker a{display:flex;align-items:center;gap:10px;text-decoration:none;color:#1a1a1a;font-weight:800;font-size:20px;background:#fff;border:3px solid #1a1a1a;border-radius:18px;padding:8px 16px 8px 8px}
.chip{width:56px;height:56px;border-radius:14px;border:3px solid #1a1a1a;display:grid;place-items:center;font-size:36px;font-weight:900;color:#fff;text-shadow:0 2px 0 #1a1a1a}
section{max-width:1800px;margin:26px auto;padding:22px 32px 28px;background:#fffdf7;border:3px solid #1a1a1a;border-radius:24px}
section .head{display:flex;align-items:center;gap:18px;margin-bottom:12px}
section .head .chip{width:96px;height:96px;font-size:64px;border-radius:22px;flex:none}
section h2{margin:0;font-size:34px}
section p.idea{margin:6px 0 0;max-width:1000px;line-height:1.45;font-size:17px}
.frames{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:16px}
figure{margin:0}
figure svg{display:block;width:100%;height:auto;border-radius:14px;border:3px solid #1a1a1a;background:#fff}
figcaption{margin-top:6px;font-size:14px;color:#5b554b}
text.ui{font-family:Andika,"Avenir Next Rounded","Arial Rounded MT Bold",Verdana,"DejaVu Sans",sans-serif;letter-spacing:.5px}
footer{max-width:1800px;margin:10px auto 40px;padding:0 32px;font-size:14px;color:#5b554b;line-height:1.5}
@media (max-width:1100px){.frames{grid-template-columns:1fr}}
"""

html = ['<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
        '<title>Pumpkin Patch game: pick a look</title><style>', CSS, '</style></head><body>',
        '<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>', "".join(SYMBOLS), sym_icecream(), sym_fish(), '</defs></svg>',
        '<header><h1>Pick a look for the Pumpkin Patch</h1>',
        '<p>Three ways the world around the characters could look. Each one shows walking around (left) and a battle (right). '
        'Point at the big letter you like best.</p><div class="picker">']
for L, col, name, _, *_ in DIRS:
    html.append(f'<a href="#dir-{L}"><span class="chip" style="background:{col}">{L}</span>{name}</a>')
html.append('</div></header>')
for L, col, name, key, idea, world, battle in DIRS:
    html.append(f'<section id="dir-{L}"><div class="head"><span class="chip" style="background:{col}">{L}</span><div><h2>{name}</h2>'
                f'<p class="idea">{idea}</p></div></div><div class="frames">'
                + frame(world, f"{L}: walking in the Pumpkin Patch") + frame(battle, f"{L}: battle") + '</div></section>')
html.append('<footer>Mockup notes: characters are stand-ins made from photos of the drawings (rough cut-outs; the clean SVG redraws will replace them). '
            'The ice cream (A) and fish (C) are quick vector redraws and the monster (B) is a posterised version, to show how clean flat characters sit in each world. '
            'Faint circles bottom-left and bottom-right are the touch-control fallback, hidden when a controller is connected. '
            'Coloured shapes on move buttons are the matching PlayStation buttons (cross, circle, triangle); stars under a move show how many hits it does.</footer>')
html.append('</body></html>')
open(OUT, "w").write("".join(html))
print("wrote", OUT, os.path.getsize(OUT) // 1024, "KB")

# standalone frames for screenshots (one 844x390 page per mockup)
if len(sys.argv) > 3:
    fd = sys.argv[3]; os.makedirs(fd, exist_ok=True)
    defs = '<svg width="0" height="0" style="position:absolute"><defs>' + "".join(SYMBOLS) + sym_icecream() + sym_fish() + '</defs></svg>'
    for L, col, name, key, idea, world, battle in DIRS:
        for kind, content in (("overworld", world), ("battle", battle)):
            open(os.path.join(fd, f"{L}-{kind}.html"), "w").write(
                '<!DOCTYPE html><html><head><meta charset="utf-8"><style>' + CSS +
                'html,body{margin:0;background:#fff}svg.f{display:block;width:844px;height:390px}</style></head><body>' + defs +
                f'<svg class="f" viewBox="0 0 844 390">{content}</svg></body></html>')
