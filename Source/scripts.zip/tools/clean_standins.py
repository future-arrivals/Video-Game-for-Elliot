"""Posterise rough cut-outs into an approximation of the clean flat-vector redraws:
flat marker-palette fills (scribbles smoothed out), solid thick #1a1a1a outline, no paper border.
Usage: python3 clean_standins.py <crops_dir> name [name ...]  -> writes <name>_clean.png"""
import sys, os, numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage as ndi

PAL = np.array([
    (0xFB, 0xF8, 0xF0),  # paper white
    (0xE8, 0x92, 0x1C),  # pumpkin orange
    (0xEE, 0xB2, 0x3E),  # marigold
    (0xD0, 0x3C, 0x30),  # tomato red
    (0xC9, 0x63, 0x3A),  # brick
    (0x5E, 0x2C, 0x17),  # dark brown
    (0xD6, 0xDA, 0x55),  # highlighter yellow
    (0xE9, 0x9D, 0xBB),  # pink
    (0x2A, 0x7A, 0x3A),  # vine green
    (0x82, 0xA8, 0x36),  # leaf green
    (0x0E, 0x6E, 0x74),  # teal
    (0x46, 0x99, 0x7E),  # light teal
    (0x16, 0x3A, 0x86),  # navy
    (0x8C, 0xC8, 0xDC),  # sky
], np.float32)

d, names = sys.argv[1], sys.argv[2:]
for spec in names:
    n, _, allow = spec.partition(":")
    allowed = [int(v) for v in allow.split(",")] if allow else list(range(1, len(PAL)))
    im = Image.open(os.path.join(d, n + ".png")).convert("RGBA")
    a = np.asarray(im).astype(np.float32)
    rgb, al = a[..., :3], a[..., 3] > 128
    lum = rgb.mean(2)
    mx, mn = rgb.max(2), rgb.min(2)
    sat = (mx - mn) / np.maximum(mx, 1)
    ink = ((lum < 58) | ((lum < 85) & (sat < 0.45))) & al
    ink = ndi.binary_closing(ink, iterations=1)
    # colour classification: low saturation -> white, else nearest marker colour (by hue-ish distance)
    # boost photo colours before matching (photos are under-exposed)
    boosted = np.clip((rgb - rgb.mean(2, keepdims=True)) * 1.25 + rgb.mean(2, keepdims=True) * 1.15, 0, 255)
    dist = ((boosted[..., None, :] - PAL[None, None]) ** 2).sum(-1)
    allowed_a = np.array(allowed)
    idx = allowed_a[dist[..., allowed_a].argmin(-1)]
    idx = np.where(sat < 0.16, 0, idx)
    # smooth scribbles: majority filter on the index map
    idx_img = Image.fromarray(idx.astype(np.uint8))
    for _ in range(4):
        idx_img = idx_img.filter(ImageFilter.ModeFilter(11))
    idx = np.asarray(idx_img)
    out = PAL[idx]
    # silhouette: drawing area without the white sticker margin
    body = ndi.binary_fill_holes(ndi.binary_closing(ink | ((sat > 0.2) & al), iterations=4))
    body = ndi.binary_dilation(body, iterations=1) & al
    # thicker, smoother outline
    line = ndi.binary_dilation(ink, iterations=1)
    line = np.asarray(Image.fromarray((line * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.0))) > 100
    outline = body & ~ndi.binary_erosion(body, iterations=3)
    line |= outline
    out[line] = (0x1A, 0x1A, 0x1A)
    alpha = np.asarray(Image.fromarray((body * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.8)))
    res = Image.fromarray(np.dstack([out.astype(np.uint8), alpha]), "RGBA")
    res.save(os.path.join(d, n + "_clean.png"))
    print(n, res.size)
